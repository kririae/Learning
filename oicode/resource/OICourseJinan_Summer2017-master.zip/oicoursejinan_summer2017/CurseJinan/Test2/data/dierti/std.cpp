#include<bits/stdc++.h>
#define mod 1000000007 
#define N 100010
using namespace std;
int T,n,i,a[N],g[N],f[N],sum,sum1;
int powmod(int x,int y){
	int ans=1;
	for(;y;y>>=1,x=1ll*x*x%mod)
		if(y&1)ans=1ll*ans*x%mod;
	return ans;
}
int main(){
	scanf("%d",&n);
	sum=0;sum1=g[0]=1;
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
		g[i]=1ll*g[i-1]*a[i]%mod;
		f[i]=(sum+1ll*g[i]*sum1)%mod;
		sum=(sum+f[i])%mod;
		sum1=(sum1+1ll*powmod(2,(i-1))*powmod(g[i],mod-2))%mod;
	}
	printf("%d\n",f[n]);
}
