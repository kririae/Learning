#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
const int N[]={10,10,10,1000,1000,1000,1000,1000,1000,100000};
const int M[]={10,10,10,1,1,1,100000,100000,100000,1000000000};
int n,m,s,a[100010],t,i;
char s1[101],s2[100];
int main()
{
	srand(GetTickCount());
	strcpy(s1,"dierti0.in");
	strcpy(s2,"std <dierti0.in >dierti0.out");
	for(int _=0;_<10;_++)
	{
		s1[6]=_+'0';
		s2[11]=_+'0';
		s2[23]=_+'0';
		freopen(s1,"w",stdout);
		printf("%d\n",n=(rand()<<15|rand())%(N[_]/2)+N[_]/2+1);
		while(n--)printf("%d ",(rand()<<15|rand())%M[_]+1);
		fclose(stdout);
		system(s2);
	}
}
