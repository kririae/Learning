#include<bits/stdc++.h>
using namespace std;
int n,m,i,x,A[1100],B[1100],C[1100000],ans,j,k,SS[1100000],TT[1100000];
pair<int,int>a[1100000];
int main(){
	scanf("%d",&n);
	m=n*n;
	ans=n*2-1;
	for(i=0;i<m;i++)
		scanf("%d",&a[i].first),a[i].second=i;
	sort(a,a+m);
	for(i=0;i<m;i=j){
		TT[i]=TT[i-1];
		for(j=i;a[j].first==a[i].first&&j<m;j++){
			x=a[j].second;
			B[x%n]++;
			TT[i]=max(TT[i],B[x%n]);
		}
		for(k=i;k<j;k++)TT[k]=TT[i];
	}
	memset(A,0,sizeof(A));
	for(i=m-1;i>=0;i=j){
		SS[i]=SS[i+1];
		for(j=i;a[j].first==a[i].first&&j>=0;j--){
			x=a[j].second;
			A[x/n]++;
			SS[i]=max(SS[i],A[x/n]);
		}
		for(k=i;k>j;k--)SS[k]=SS[i];
	}
	for(i=0;i<m;i++)
		if(n-SS[i]+n-TT[i]<ans)ans=n-SS[i]+n-TT[i];
	printf("%d\n",ans);
}
