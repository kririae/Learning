#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
const int N[]={10,10,10,100,100,100,100,100,100,1000};
const int M[]={10,10,10,3,3,3,100000,100000,100000,1000000000};
int n,m,s,a[100010],t,i;
char s1[101],s2[100];
int main()
{
	srand(GetTickCount());
	strcpy(s1,"disanti0.in");
	strcpy(s2,"std <disanti0.in >disanti0.out");
	for(int _=0;_<10;_++)
	{
		s1[7]=_+'0';
		s2[12]=_+'0';
		s2[25]=_+'0';
		freopen(s1,"w",stdout);
		printf("%d\n",n=(rand()<<15|rand())%(N[_]/2)+N[_]/2+1);
		for(i=1;i<=n;i++,puts(""))
			for(int j=1;j<=n;j++)
				printf("%d ",(rand()<<15|rand())%(M[_])+1);;
		fclose(stdout);
		system(s2);
	}
}
