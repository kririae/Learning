#include<bits/stdc++.h>
using namespace std;
int T,n,m,S,a[100010],p[5],ans;
int main(){
	freopen("diyiti3.in","r",stdin);
	freopen("diyiti3.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(p,0,sizeof(p));
		ans=0;
		scanf("%d%d%d",&n,&m,&S);
		for(int i=1;i<=S;i++){
			scanf("%d",&a[i]);
			p[a[i]%m]++;
			if(a[i]>=m)ans+=(a[i]/m*(2*m-1)-m+a[i]%m+max(0,a[i]%m-1));
			else ans+=a[i]-1;
		}
		if(m==3){
			if(p[2]>p[1])ans-=(p[2]-p[1])/3;
		}else if(m==4){
			if(p[3]>p[1])ans-=(p[3]-p[1])/2;
		}
		printf("%d\n",ans);
	}
}
