#include<bits/stdc++.h>
#include<ctime>
using namespace std;
const int N[]={10,10,10,10,10,10,1000,1000,1000,100000};
const int M[]={1,1,1,2,2,2,3,3,3,4};
const int S[]={10,10,10,10,10,10,1000,1000,1000,100000};
const int T[]={10,10,10,10,10,10,10,10,10,10};
int n,m,s,a[100010],t,i;
char s1[101],s2[100];
int main()
{
	srand(time(0));
	strcpy(s1,"diyiti0.in");
	strcpy(s2,"std <diyiti0.in >diyiti0.out");
	for(int _=0;_<10;_++)
	{
		s1[6]=_+'0';
		s2[11]=_+'0';
		s2[23]=_+'0';
		freopen(s1,"w",stdout);
		printf("%d\n",t=rand()%T[_]+1);
		while(t--){
			n=(rand()<<15|rand())%N[_]+1;
			m=(rand()<<15|rand())%M[_]+1;
			s=(rand()<<15|rand())%min(n*m,S[_])+1;
			printf("%d %d %d\n",n,m,s);
			for(i=1;i<s;i++)a[i]=(rand()<<15|rand())%(n*m-s+1);
			a[s]=n*m-s;
			sort(a+1,a+s+1);
			for(i=1;i<=s;i++)printf("%d ",a[i]-a[i-1]+1);
			puts("");
		}
		fclose(stdout);
		system(s2);
	}
}
