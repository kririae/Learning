// HDU 1698
// 区间标记 / 懒标记 

#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 4e5 + 6;

int n, q;
int f[N], size[N], tag[N];

int opl, opr, opx;

void build(int x, int l, int r)
{
	f[x] = size[x] = r-l+1, tag[x] = 0;
	if(l==r) return;
	int mid = (l+r) >> 1;
	build(x+x, l, mid), build(x+x+1, mid+1, r);
}

void set(int x, int d) {f[x]=size[x]*d, tag[x]=d;} // 整个区间x染色
void up(int x) {f[x] = f[x+x] + f[x+x+1];} // 合并信息（区间信息更新）
void down(int x) // 区间标记下传
{
	if(tag[x]) set(x+x, tag[x]), set(x+x+1, tag[x]), tag[x]=0;
}

void calc(int x, int l, int r)
{
	if(opl<=l && r<=opr)
	{
		set(x, opx); // 修改区间颜色
		return;
	}
	
	int mid=(l+r)>>1;
	
	down(x); // 下传标记
	if(opl<=mid) calc(x+x, l, mid);
	if(opr>mid) calc(x+x+1, mid+1, r);
	up(x); // 合并信息
}

void work(int id)
{
	scanf("%d%d", &n, &q);
	build(1, 1, n);
	for(int i=1; i<=q; i++)
		scanf("%d%d%d", &opl, &opr, &opx), calc(1,1,n);
	printf("Case %d: The total value of the hook is %d.\n", id, f[1]);
}

int main()
{
	freopen("seg3.in", "r", stdin);
	freopen("seg3.out", "w", stdout);
	
	int T;
	scanf("%d", &T);
	
	for(int i=1; i<=T; i++) work(i);
	
	return 0;
}

/*
一般的线段树模板：
void calc(x,l,r)
	若区间[l,r]在区间[opl,opr]中：
		对区间[l,r]进行操作（查询/修改）
		返回
		
	下传标记
	如果区间[l,mid]的一部分在区间[opl,opr]中，calc(x+x,l,mid)
	如果区间[mid+1,r]的一部分在区间[opl,opr]中，calc(x+x+1,mid+1,r)
	合并信息（如果是修改操作）
*/
