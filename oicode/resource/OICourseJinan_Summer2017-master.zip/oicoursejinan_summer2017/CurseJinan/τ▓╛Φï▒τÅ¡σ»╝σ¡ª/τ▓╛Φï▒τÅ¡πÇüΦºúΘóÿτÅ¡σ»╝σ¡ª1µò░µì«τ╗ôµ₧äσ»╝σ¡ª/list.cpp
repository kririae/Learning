// 链表的两种实现方式
// 问题，读入N个数，并倒序输出
// 链表的构成：链表头(head), 链表尾(tail), 存储的数据(a), 指向下个位置的“指针”(p)

#include <cstdio>
#include <cstring>
using namespace std;

void array()
{
	int head, tail, cnt; // 定义头、尾、计数器
	int a[1000], p[1000]; 
	
	head = tail = 0;
	
	int n, x;
	scanf("%d", &n);
	scanf("%d", &x);
	
	head = tail = cnt = 1; // 头、尾、计数器赋初值
	a[cnt] = x, p[cnt] = -1; // 建立第一个结点
	
	for(int i=2; i<=n; i++)
	{
		scanf("%d", &x);
		// 在头部后插入一个结点
		++cnt; // 新建结点
		a[cnt] = x, p[cnt] = head, head = cnt; // “插队”
	}
	
	for(int i=head; i>0; i=p[i]) printf("%d\n", a[i]);
}

void stru() // 使用虚拟指针池
{
	struct rec {int a; rec *p;}; // 定义结构
	rec nil[1000], *head, *tail, *cnt; // 定义头、尾、计数器（和上面的cnt类似，新增的时候计数器+1）
	
	int n, x;
	scanf("%d", &n);
	scanf("%d", &x);
	
	// nil代表空结点，与上面的“-1”类似
	cnt = nil + 1, head = tail = cnt; // 头、尾、计数器赋初值
	head->a = x, head->p = nil; // 建立第一个结点
	
	for(int i=2; i<=n; i++)
	{
		scanf("%d", &x);
		
		++cnt, cnt->a = x; // 在头部后插入一个结点
		cnt->p = head, head = cnt; // “插队”
	}
	
	for(rec *i=head; i!=nil; i=i->p) printf("%d\n", i->a);
}

int main()
{
	stru();
}
