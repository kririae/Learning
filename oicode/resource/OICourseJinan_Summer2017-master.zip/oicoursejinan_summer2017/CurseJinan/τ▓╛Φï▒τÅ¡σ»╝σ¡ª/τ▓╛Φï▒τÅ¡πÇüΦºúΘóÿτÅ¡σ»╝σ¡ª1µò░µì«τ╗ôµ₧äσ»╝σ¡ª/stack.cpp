#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int st[1000]; // 栈内元素
int tp; // 栈顶元素的指针

void push(int x) {st[tp++]=x;} // 栈顶放入一个元素
void pop() {--tp;} // 从栈顶弹出一个元素（修改栈顶指针即可）
int top() {return st[tp-1];} // 查询栈顶（注意，0-tp-1才开区间）

void stack()
{
	tp=0;
	push(1), push(2), push(3);
	printf("%d\n", top());
	pop(), pop();
	printf("%d\n", top());
	push(4);
	printf("%d\n", top());
}

int main()
{
	stack();
}
