#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int q[1000]; // 队列元素
int head, tail; // 头、尾指针

void push(int x) {q[tail++]=x;} // 队尾插入一个元素
void pop() {++head;} // 队首出列
int front() {return q[head];} // 查询队首

void queue()
{
	head=tail=0;
	push(1), push(2), push(3);
	printf("%d\n", front());
	pop(), push(4), pop();
	printf("%d\n", front());
}

int main()
{
	queue();
}
