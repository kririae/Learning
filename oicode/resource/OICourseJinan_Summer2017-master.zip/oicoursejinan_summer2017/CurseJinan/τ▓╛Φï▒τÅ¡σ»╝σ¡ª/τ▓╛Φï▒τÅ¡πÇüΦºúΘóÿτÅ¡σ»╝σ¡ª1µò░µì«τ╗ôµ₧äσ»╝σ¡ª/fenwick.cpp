// 树状数组：Binary Index Tree / Fenwick Tree
// 读入N个数与Q个操作，对于操作0 x y,把位置x上的数增加y；对于操作1 x y,对区间[x,y]求和。
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1e5+5;

int n, q;
int T[N];

void modify(int x, int y)
{
	for(; x<=n; x+=x&(-x)) T[x]+=y;
}

int query(int x)
{
	int ret=0;
	for(; x; x-=x&(-x)) ret+=T[x];
	return ret;
}

int main()
{
	freopen("fenwick.in", "r", stdin);
	freopen("fenwick.out", "w", stdout);
	
	scanf("%d%d", &n, &q);
	for(int i=1, t, x, y; i<=q; i++)
	{
		scanf("%d%d%d", &t, &x, &y);
		if(!t) modify(x, y);
		else printf("%d\n", query(y) - query(x-1));
	}
	
	return 0;
}
