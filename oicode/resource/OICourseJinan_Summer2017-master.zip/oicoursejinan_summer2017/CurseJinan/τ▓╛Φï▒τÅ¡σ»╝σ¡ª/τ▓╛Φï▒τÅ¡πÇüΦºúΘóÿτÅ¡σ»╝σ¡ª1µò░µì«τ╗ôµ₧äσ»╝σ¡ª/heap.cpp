#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int tot;
int key[1000];

void up(int x) //将一个结点“上浮”
{
	for(; x>1; x/=2) //没有上浮到最顶层
	{
		if(key[x]>key[x/2]) break; //如果上方的结点小于此节点，则暂停上浮
		swap(key[x], key[x/2]); //交换上方结点与此结点
	}
}

void down(int x) //将一个节点“下沉”
{
	for(int y; x<=tot; ) 
	{
		y=x+x; // y是x的左儿子
		if(y>tot) break; // x已经沉到底部
		if(y<tot && key[y+1]<key[y]) y++; // 如果x存在右儿子，且右儿子比左儿子小，则将y赋值到右儿子
		if(key[x]<=key[y]) break; // 若两个儿子中的较小值仍然比x大，则停止下沉
		swap(key[x], key[y]); // 下沉
		x=y;
	}
}

void insert(int x) // 插入一个结点
{
	key[++tot] = x; // 在尾部插入一个结点
	up(tot); // “上浮”这个结点
}

int top(){return key[1];} // 最小值即是顶部的值

void pop() // 删除一个结点
{
	swap(key[1], key[tot]); // 将最后的结点（保证其没有儿子）与最顶端交换 
	--tot;
	down(1); // 下沉顶端
}


int main()
{
	tot = 0;
	for(int i=9; i; i--) insert(i);
	for(int i=9; i; i--) printf("%d\n", top()), pop();
}