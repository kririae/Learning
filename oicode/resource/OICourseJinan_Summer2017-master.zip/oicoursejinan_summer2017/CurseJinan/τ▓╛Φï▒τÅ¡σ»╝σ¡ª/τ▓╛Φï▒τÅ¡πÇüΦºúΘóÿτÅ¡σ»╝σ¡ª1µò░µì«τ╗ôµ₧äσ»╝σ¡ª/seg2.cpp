void calc(int x, int l, int r)
{
	if(opl<=l && r<=opr)
	{
		if(opty==0) ans=min(ans,f[x]);
		else f[x]=opx;
		return;
	}
	int mid=(l+r)>>1;
	if(opl<=mid) calc(x+x, l, mid);
	if(opr>mid) calc(x+x+1, mid+1, r);
	f[x]=min(f[x+x], f[x+x+1]);
}

void modify(int x, int p) // 修改，令位置x的数等于p
{
	opty = 1, opl = opr = x, opx = p;
	calc(1, 1, n);
}

// 由于修改操作和询问操作十分类似，可以将两者合二为一
// 通过全局变量opty来区分是哪一种操作