#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
using namespace std;
int m, n;
int g[30][510], sum[30][510], bak[30][510];
int ans = -1e9;
void fold(int pos, int isx, int x, int y)// isx == 0 : Y ; isx == 1 : X ;
{ 
    if(isx)
    { 
        for (int i = 1, j = pos + 1; j <= x; ++i, ++j)
            for (int k = 1; k <= y; ++k)
                sum[i][k] += sum[j][k];
    }
    else
    { 
        for(int i = 1; i <= x; ++i)
            for (int j = 1, k = pos + 1; k <= y; ++j, ++k)
                sum[i][j] += sum[i][k];
    }
}
void resv(int pos, int isx, int x, int y)
{ 
    if(isx)
    { 
        for (int i = 1, j = pos + 1; j <= x; ++i, ++j)
            for (int k = 1; k <= y; ++k)
                sum[i][k] -= sum[j][k];
    }
    else
    { 
        for(int i = 1; i <= x; ++i)
            for (int j = 1, k = pos + 1; k <= y; ++j, ++k)
                sum[i][j] -= sum[i][k];
    }
}
int getans(int bx, int by)
{ 
    int s = -1e9;
    for (int i = 1; i <= bx; ++i)
        for (int j = 1; j <= by; ++j)
            s = max(s, sum[i][j]);
    return s;
}
void dfs(int bx, int by)
{ 
    if (bx == by && by == 1)
        return;
    for (int i = ceil((double)bx / 2); i < bx; ++i)
    { 
        fold(i, 1, bx, by);
        ans = max(getans(i, by), ans);
        dfs(i, by);
        resv(i, 1, bx, by);
    }
    for (int i = ceil((double)by / 2); i < by; ++i)
    { 
        fold(i, 0, bx, by);
        ans = max(getans(bx, i), ans);
        dfs(bx, i);
        resv(i, 0, bx, by);
    }
}
int main()
{ 
    freopen("cfyw.in", "r", stdin);
    freopen("cfyw.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            cin >> sum[i][j];
    dfs(n, m);
    cout << ans << endl;
}
