#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
using namespace std;
typedef long long ll;
const ll mod = 998244353;
ll gcd(ll a, ll b)
{ 
    if (a < b) swap(a,b);
    if (a % b == 0) return min(a, b);
    return gcd(a % b, b);
}
int main()
{ 
    ll ans = 0;
    freopen("hoip.in", "r", stdin);
    freopen("hoip.out", "w", stdout);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
    { 
        for (int j = 1; j <= m; ++j)
            ans += gcd(i ,j), ans %= mod;
    }
    cout << ans % mod << endl;
}
