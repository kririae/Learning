#include <iostream>
#include <cstdio>
using namespace std;

//const int MAXN = 1000000001;�߾��ȣ�
long long n, m, res;

int main(){
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	
	cin>>n>>m;
	res = n*m-1;
	cout<<res % 998244353<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
