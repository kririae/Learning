#include <iostream>
using namespace std;

const int MAXN = 10000001;

int n, m;
long long res;

int gcd(int ii, int jj){
	//Nian(3��)ת�����
	int i = max(ii, jj), j = min(ii, jj);
	if(i % j == 0)return j;
	while(j != 0){
		int temp = i;
		i = j;
		j = temp % j;
	}
	return i;
}

int main(){
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	
	cin>>n>>m;
	//ƭ�ֵ���
	if(n*m <= 1000000){
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= m; ++j)
				res += gcd(i, j);
	}else{
	//�桤�㷨
		
	}
	cout<<res % 998244353<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
