#include <iostream>
using namespace std;

long long n, m, res, a;

int main(){
	//������
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	cin>>n>>m;
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j){
			cin>>a;if(a>0)res+=a;
		}
	cout<<res % 998244353<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
