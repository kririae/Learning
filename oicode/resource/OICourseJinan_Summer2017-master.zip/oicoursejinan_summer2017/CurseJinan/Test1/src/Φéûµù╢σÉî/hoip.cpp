#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
long long m,n;
bool sushu[10000005]={0};
int M=998244353;
int gcd(long long a,long long b)
{
	return (b==0)?a:gcd(b,a%b);
}

void pd(long long x)
{
	int signal=1;

	for(int i=2;i<=floor(sqrt(x))&&signal==1;i++)
	if(x%i==0)
	signal=0;
	
	if(signal==1)
	sushu[x]=1;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);	
	long long tot=0;
	cin>>m>>n;
	for(long long j=1;j<=m;j++){
		pd(j);
	}
	for (long long k=1;k<=m;k++)
	  for (long long l=1;l<=n;l++)
	  {
	  	if (sushu[k])
	  	if (l%k==0)
	  	tot+=k%M;
	  	else tot+=1;
	  	else tot+=gcd(k,l)%M;
	  }
	cout<<tot;
	return 0;
}
