#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
int M=998244353;
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long  ans,m,n;
	cin>>n>>m;
	m=m%M;
	n=n%M;
	cout<<(m*n)%M-1;
	return 0;
}

