#include <iostream>
using namespace std;
#define ll long long 
#define P 998244353
ll n,m,t, a[10000][10000], ans;
ll gcd(ll a,ll b){
    return b==0? a:gcd(b,a%b);
}
int main(){
	cin >> n >> m;
	if (n<m){
		t=n;n=m;m=t;
	}
	for (ll i=1;i<=m;i++){
		for (ll j=1;j<=i;j++){
			a[i][j]=gcd(i,j);
		}
	}
	for (ll i=1;i<=m;i++){
		for (ll j=1;j<=n;j++){
			ans+=a[j][i%j];
			ans%=P;
		}
	}
	cout << ans;
}
