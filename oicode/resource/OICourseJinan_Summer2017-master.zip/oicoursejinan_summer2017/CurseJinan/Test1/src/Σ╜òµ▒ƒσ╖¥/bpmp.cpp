#include<cstdio>
#include<iostream>
using namespace std;
long long m,n,ans;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	
	scanf("%d%d",&n,&m);
	
	ans=m*n-1;
	
	ans=ans%998244353;
	
	printf("%lld",ans);
	
	return 0;
}
