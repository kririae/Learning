#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>

using namespace std;
int m,n,i,j,k,l,ans,an;
long long sum;
int gcd(int a,int b)
{

	m=max(a,b);
	n=min(a,b);	
	an=m%n;
	if(an==0)
	{
		ans=n;
	}
	else
	gcd(n,an);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>i>>j;
	
	for(k=1;k<=i;k++)
	{
		for(l=1;l<=j;l++)
		{
			gcd(k,l);sum+=ans;
		}
		
	}	
	

	printf("%d",sum);
	return 0;
}

