#include<cstdio>
#include<iostream>
using namespace std;
int a[22][505];
int b[22]={0};
int c[22]={0};
int i,j,m,n;
long long ans,an;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	
	ans=0;
	an=0;
	
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	{
			for(j=1;j<=m;j++)
		{
			scanf("%d",&a[n][m]);
			if(a[n][m]>0)ans+=a[n][m];
		
		}
	}		


	ans=ans%998244353;
	
	printf("%lld",ans);
	
	
	return 0;
}
/*	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
	{
		b[n]+=a[n][m];
	}
	}
	for(i=1;i<=m;i++)
	{
		for(j=1;j<=n;j++)
	{
		c[n]+=a[m][n];
	}
	}
	
	for(i=1;i<=n;i++)
	
		{	
			if(c[n]>0)
			an+=c[n];
			if(b[n]>0)
			ans+=b[n];
		}
	if(an>ans)ans=an;*/
	
