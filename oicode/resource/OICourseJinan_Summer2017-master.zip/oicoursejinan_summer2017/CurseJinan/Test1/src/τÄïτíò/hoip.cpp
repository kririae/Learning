#include<cstdio>
#include<iostream>
using namespace std;
#include<algorithm>
long long n,m,ans;

	

inline int gcd(int a, int b)

{

    if(a == 0) return b;

    if(b == 0) return a;

    if(a % 2 == 0 && b % 2 == 0) return 2 * gcd(a >> 1, b >> 1);

    else if(a % 2 == 0)  return gcd(a >> 1, b);

    else if(b % 2 == 0) return gcd(a, b >> 1);

    else return gcd(abs(a - b), min(a, b));


}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			ans+=gcd(i,j)%998244353;
		}
	}
	cout<<ans%998244353;
	return 0;
}
