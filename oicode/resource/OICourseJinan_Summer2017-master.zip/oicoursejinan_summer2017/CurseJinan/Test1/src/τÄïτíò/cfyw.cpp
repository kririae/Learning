#include<cstdio>
#include<iostream>
using namespace std;
#include<algorithm>
long long n,m,a[501][501],ans;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			if(a[i][j]>0)
			{
				ans+=a[i][j];
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
