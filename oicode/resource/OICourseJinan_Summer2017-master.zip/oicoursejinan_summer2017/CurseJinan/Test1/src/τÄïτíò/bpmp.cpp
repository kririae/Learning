#include<cstdio>
#include<iostream>
using namespace std;
long long n,m,ans=998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	if(n%ans==0||m%ans==0)
	{
		cout<<ans-1;
	}
	else
	cout<<((n%ans)*(m%ans)-1)%ans;
	return 0;
}
