#include<iostream>
#include<cstdio>
#define maxn 21
#define maxm 501
#define INF 10000000
#define ll long long
int n,m;
ll ans=-INF,max1,map[maxn][maxm],sum[maxn][maxm][maxn][maxm];
using namespace std;
void dfs(int i1,int j1,int i2,int j2,ll max1){
	if(i1==i2-1 && j1==j2-1)
		sum[i1][j1][i2][j2]=map[i1][j1],ans=max(ans,map[i1][j1]);	
	if(sum[i1][j1][i2][j2])return ;
	for(int i=i1+1;i<=i2-1;i++)
		if(i<=(i1+i2)/2){
			max1=-INF;
			for(int j=i,q=1;j<=2*i-i1-1;j++,q++)
				for(int k=j1;k<=j2-1;k++)
					map[j][k]+=map[i-q][k],max1=max(map[j][k],max1);
			dfs(i,j1,i2,j2,-INF);
			ans=max(ans,max1);
			sum[i][j1][i2][j2]=max1;
			for(int j=i,q=1;j<=2*i-i1-1;j++,q++)
				for(int k=j1;k<=j2-1;k++)
					map[j][k]-=map[i-q][k];
		}
		else{
			max1=-INF;
			for(int j=i*2-i2,q=1;j<=i-1;j++,q++)
				for(int k=j1;k<=j2-1;k++)
					map[j][k]+=map[i2-q][k],max1=max(map[j][k],max1);
			dfs(i1,j1,i,j2,-INF);
			ans=max(ans,max1);
			sum[i1][j1][i][j2]=max1;
			for(int j=i*2-i2,q=1;j<=i-1;j++,q++)
				for(int k=j1;k<=j2-1;k++)
					map[j][k]-=map[i2-q][k];
		}
	for(int i=j1+1;i<=j2-1;i++){
		if(i<=(j1+j2)/2){
			max1=-INF;
			for(int j=i1;j<=i2-1;j++)
				for(int k=i,q=1;k<=2*i-j1-1;k++,q++)
					map[j][k]+=map[j][i-q],max1=max(max1,map[j][k]);
			dfs(i1,i,i2,j2,-INF);
			ans=max(ans,max1);
			sum[i1][i][i2][j2]=max1;
			for(int j=i1;j<=i2-1;j++)
				for(int k=i,q=1;k<=2*i-j1-1;k++,q++)
					map[j][k]-=map[j][i-q];
		}
		else{
			max1=-INF;
			for(int j=i1;j<=i2-1;j++)
				for(int k=i*2-j2,q=1;k<=i-1;k++,q++)
					map[j][k]+=map[j][j2-q],max1=max(max1,map[j][k]);
			dfs(i1,j1,i2,i,-INF);
			ans=max(ans,max1);
			sum[i1][j1][i2][i]=max1;
			for(int j=i1;j<=i2-1;j++)
				for(int k=i*2-j2,q=1;k<=i-1;k++,q++)
					map[j][k]-=map[j][j2-q];
		}
	}
}
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%lld",&map[i][j]);
	dfs(1,1,n+1,m+1,-INF);
	cout<<ans;
	return 0;
}
