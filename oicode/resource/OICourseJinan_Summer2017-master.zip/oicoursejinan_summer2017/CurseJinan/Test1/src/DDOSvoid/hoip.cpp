#include<iostream>
#include<cstdio> 
#define mod 998244353
#define ll long long
using namespace std;
int n,m;
ll ans;
int gcd(int x,int y){
	return (y==0?x:gcd(y,x%y));
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	ans=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			ans+=gcd(i,j),ans%=mod;
	printf("%d\n",ans%mod);
	return 0;
}
