#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn = 502;
int arr[maxn];
int mat[maxn][maxn];
int N, M;
int sum[maxn][maxn];

int dp() {
    int b = 0, sum = 0;
    for ( int i = 1; i <= N; i++ ) {
        if ( b > 0 )
            b += arr[i];
        else
            b = arr[i];
        if ( b > sum )
            sum = b;
    }
    return sum;
}
int main() {
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
    int i, j, k;
    int max;
    while ( cin >> N >> M) {

        for ( i = 1; i <= N; i++ )
            for ( j = 1; j <= M; j++ ) {
                scanf( "%d", &mat[i][j] );
            }
        N = N > M ? N : M;
        memset( sum, 0, sizeof( sum ) );
        for ( j = 1; j < N; j++ )
            for ( i = 1; i <= N; i++ )
                sum[i][j] = sum[i - 1][j] + mat[i][j];
        max = 0;
        int temp;
        for ( i = 1; i <= N; i++ )
            for ( j = i; j <= N; j++ ) {
                for ( k = 1; k <= N; k++ ) arr[k] = sum[j][k] - sum[i - 1][k];
                temp = dp();
                if ( max < temp ) max = temp;
            }
        cout << max << endl;
    }
}
