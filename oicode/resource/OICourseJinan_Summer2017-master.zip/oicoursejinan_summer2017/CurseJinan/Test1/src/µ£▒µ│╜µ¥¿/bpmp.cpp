#include<iostream>
using namespace std;
long long n,m,van;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	van=n*m;
	van=van-1;
	cout<<van%1998244353<<endl;
	return 0;
}
