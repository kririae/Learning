#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

long long int a,m,n,cnt;
void dfs();

int main(){
	freopen("cfyw","r",stdin);
	freopen("cfyw","w",stdout);
	cin>>n>>m;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			if((cin>>a) > 0) cnt += a;
		}
	}
	printf("%d",cnt);
	return 0;	
}
