//ֻ�ܴ���nm����ż�� 
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>

using namespace std;

const int N = 10010;

int m,n,column,line,cnt = 0,total;
double layer = 0.5;
void dfs();

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d %d",&n,&m);
	if(n = 1){
		printf("%d",m-1);
	    return 0;
	}
	total = (n - 1)*m + (m - 1)*n;
	column = m;line = n;
	dfs();
	printf("%d",cnt);
	return 0;
}

void dfs(){
	//int maxn = max(column,line); 
	layer = layer * 2;
	if(column > line) {
		total = total - column*layer;
		column = column / 2;
		dfs();
		cnt += layer;
		//cnt = cnt % 998244353;
		if(total) return; 
	}
	else{
		total = total - line*layer;
		line = line / 2;
		dfs();
		cnt += layer;
		//cnt = cnt % 998244353;
		if(total) return; 
	}
}
