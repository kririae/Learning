//explosion !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;

int getgcd(int m,int n);
long long int m,n,ans = 0,a;

int main(){
	freopen("hoip.in","r".stdin);
	freopen("hoip.out","w".stdout);
	scanf("%d %d",&n,&m);
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			a = getgcd(i,j);
			ans += a;
		}
	}
	printf("%d",ans);
	return 0;
}

int getgcd(int m,int n){
	while(m > 0){
		int c = n % m;
		n = m;
		m = c;
	}
	return n;
}
