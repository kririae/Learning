#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
using namespace std;
long long int n,m;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	cout<<(n-1+n*(m-1))%998244353;
	return 0;
}
