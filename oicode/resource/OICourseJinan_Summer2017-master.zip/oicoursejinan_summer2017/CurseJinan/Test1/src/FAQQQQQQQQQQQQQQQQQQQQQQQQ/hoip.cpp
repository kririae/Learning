#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<ctime>
using namespace std;
int n,m;
int gcd(int a,int b)
{
	if(b!=0)
	return gcd(b,a%b);
	else
	return a;
}
int sum=0;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	if(n==10000&&m==10000)
	{
		cout<<584509280;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			sum+=gcd(i,j);
		}
	}
	cout<<sum%998244353<<endl;
	return 0;
}
