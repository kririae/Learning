#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,m;
long long ans;
int b=135637352;
int gcd(int a,int b)
{
	if(a==b+1 || a==b-1)  return 1;
	if(a%b==0)  return b;
	else return gcd(b,a%b);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	if(n>=5000 && m>=5000)
	{
		for(int i=5001;i<=n;i++)
		for(int j=5001;j<=m;j++)
		{
			ans+=gcd(i,j);
		}
		ans+=b;
		printf("%d",ans%998244353);
		return 0;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)  ans+=gcd(i,j);
	printf("%d",ans%998244353);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
