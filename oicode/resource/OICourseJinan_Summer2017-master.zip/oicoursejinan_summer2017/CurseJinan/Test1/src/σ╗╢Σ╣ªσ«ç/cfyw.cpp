#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,a[25][510];
int ans;
int xmax(int a,int b)
{
	if(a>=b)  return a;
	else return b;
}
void input()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)  cin>>a[i][j];
}
void dfs(int x,int y)
{
	int tot=a[x][y];
	for(int i=x+1;i<=n;i+=2)
		for(int j=y+1;j<=m;j+=2)
		{
			tot+=a[i][j];
			dfs(i,j);
			ans=xmax(ans,tot);
			tot-=a[i][j];
		}
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	input();
	dfs(1,1);
	cout<<ans*2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
