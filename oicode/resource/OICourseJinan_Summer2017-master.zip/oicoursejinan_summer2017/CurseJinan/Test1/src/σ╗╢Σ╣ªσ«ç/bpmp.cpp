#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
long long n,m,ans;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	ans=ans+(m-1);
	ans=ans+m*(n-1);
	cout<<ans%998244353;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
