# include <iostream>
# include <cstdio>
using namespace std;
long long n, m, ck = 998244353;
int main() {
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	cin >> n >> m;
	cout << (m - 1) + (m * (n - 1)) % ck;
	return 0;
}
