# include <cstdio>
# include <iostream>
using namespace std;

inline char getc() {
	static char buf[1 << 18], *fs, *ft;
	return (fs == ft && (ft = (fs = buf) + fread(buf, 1, 1 << 18, stdin)), fs == ft) ? EOF : *fs++;
}

inline int gn() {
	int k = 0, f = 1;
	char c = getc();
	for(; !isdigit(c); c = getc()) if(c == '-') f = -1;
	for(; isdigit(c); c = getc()) k = k * 10 + c - '0';
	return k * f;
}

int n, m, tmp, ans;

int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	n = gn();
	m = gn();
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			tmp = gn();
			if(tmp > 0) ans += tmp;
		}
	}
	printf("%d\n", ans);
	return 0;
}
