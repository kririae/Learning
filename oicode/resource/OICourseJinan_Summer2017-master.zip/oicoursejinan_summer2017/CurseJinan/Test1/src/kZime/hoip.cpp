# include <iostream>
# include <cstdio>
using namespace std;
inline int gcd(int a, int b) { // a > b
    if(a < b) swap(a, b);
    while(a % b) { 
        a = a % b;
        if(a < b) swap(a, b);
    }
    return b;
}
int main() {
    freopen("hoip.in", "r", stdin);
    freopen("hoip.out", "w", stdout);
	int n, m;
	cin >> n >> m;
    if(m > n) swap(m, n);
    int ans = 0;
    for(int i = 1; i <= m; i++) {
        ans += i;
        for(int j = i + 1; j <= m; j++) { 
            ans += gcd(i, j) << 1;
        }
    }
    for(int i = m + 1; i <= n; i++) { 
        for(int j = 1; j <= m; j++) { 
            ans += gcd(i, j);
        }
    }
	cout << ans;
	return 0;
}
