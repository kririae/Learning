#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long n,m,mod=998244353,ans;
	scanf("%lld%lld",&n,&m);
	n%=mod,m%=mod;
	ans=(n*m-1)%mod;
	printf("%lld",ans);
	return 0;
}
