#include<iostream>
#include<cstdio>
using namespace std;
int map[25][505]={0},n,m;
long long ans=0;
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			scanf("%d",&map[i][j]);
			if(map[i][j]>0)ans+=map[i][j];
		}
	printf("%lld",ans);
	return 0;
}
