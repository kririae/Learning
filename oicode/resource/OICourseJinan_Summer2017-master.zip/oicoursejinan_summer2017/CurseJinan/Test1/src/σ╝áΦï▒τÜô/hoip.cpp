#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a,b;
long long ans=0;

inline int gcd(int x,int y) {
	while(x){
		int t=x;
		x=y%x;
		y=t;
	}
	return y;
}

int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&a,&b);
	if(a>b)swap(a,b);
	for(int i=1;i<=a;i++)
		for(int j=i+1;j<=a;j++){
			ans+=gcd(i,j);
		}
	ans*=2;
	for(int i=1;i<=a;i++)
		ans+=i;
	for(int i=1;i<=a;i++)
		for(int j=a+1;j<=b;j++)
			ans+=gcd(i,j);
	printf("%lld",ans);
	return 0;
}
