#include<iostream>
using namespace std;
int n,m;
int a[21][501];
int b[21][21][21][21];
int ans;
void dfs(int x,int y)
{
    
     for(int i=2;i<=x;i++)
       for(int j=1;j<=x-i+1;j++)
         for(int k=1;k<=y;k++)
         {
         	b[x-i+1][y][j][k]=b[x][y][i+j-1][k]+b[x][y][i-j][k];
         	ans=max(ans,b[x-i+1][y][j][k]);
         	
         	dfs(x-i+1,y);
		 }
	 for(int i=2;i<=y;i++)
	   for(int j=1;j<=y-i+1;j++)
	     for(int k=1;k<=x;k++)
	     {
	     	b[x][y-i+1][j][k]=b[x][y][k][i+j-1]+b[x][y][k][i-j];
	     	ans=max(ans,b[x][y-i+1][j][k]);
	     	
	     	dfs(x,y-i+1);
		 }
     	
	 
}
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	  {
	  	cin>>a[i][j];
	  	b[n][m][i][j]=a[i][j];
	  }
	dfs(n,m);
	cout<<ans;
	return 0;
	
	
}
