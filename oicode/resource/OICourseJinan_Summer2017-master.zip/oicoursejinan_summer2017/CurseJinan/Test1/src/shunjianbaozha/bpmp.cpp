#include<iostream>

using namespace std;
int main()
{
	int n,m;
	int x=998244353;
	cin>>n>>m;
    int ans;
    if(n==1)
    {
    	ans=((m%x)-(1%x)+m)%x;
    	cout<<ans;
    	return 0;
	}
    ans=ans%x;
    ans=ans*(m%x);
    ans=ans%x;
    ans=((ans%x)-(1%x)+ans)%x;
    cout<<ans;
	return 0;
}
