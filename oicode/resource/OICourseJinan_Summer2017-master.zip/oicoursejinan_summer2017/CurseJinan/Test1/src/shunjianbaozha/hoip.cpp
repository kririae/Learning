#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,m;
	int ans=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	  ans=ans+__gcd(i,j);
	cout<<ans%998244353;
	return 0;
}
