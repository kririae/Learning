#include <cstdio>
#include <iostream>
using namespace std;
int n,m,a=0;
#define num 998244353
int quick(int x,int y){
	int ans=0;
	while(y){
//	  printf("%d %d\n",x,y);
	  if(y&1) ans=(ans+x)%num;
	  x=(x<<1)%num;
	  y=y>>1;
//	  printf("%d\n",ans);
	}
	return ans;
}
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	a=quick(n,m);
	if( !a ) printf("%d\n",a);
	else printf("%d\n",a-1);
	return 0;
}
