#include <cstdio>
#include <iostream>
#include <cstring>
#define num 998244353
using namespace std;
int n,m,ans=0;
int gcd(int x,int y){
	if(!(x%y)) return y;
	return gcd(y,x%y);
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=2;i<=n;i++)
	  for(int j=i+1;j<=m;j++){
	  	ans=((ans+gcd(i,j)%num)*2)%num;
	  }
	int minn=min(n,m);
	for(int i=2;i<=minn;i++)
	  ans=(ans+i)%num;
	ans=(ans+n+m)%num;
	printf("%d\n",ans);
	return 0;
}
