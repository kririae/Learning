#include <iostream>
#include <cstdio>

#define mod 998244353

using namespace std;

long long n,m;

int main() {
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	n = n % mod;
	m = m % mod;
	printf("%lld", (((n * m) % mod - 1) % mod));
	return 0;
}
