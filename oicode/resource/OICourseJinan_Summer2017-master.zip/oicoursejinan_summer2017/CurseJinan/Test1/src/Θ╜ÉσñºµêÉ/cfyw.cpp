#include <iostream>
#include <cstdio>

using namespace std;

long long n,m;

int map[25][505];

int judge[25][505];

long long ans = -999999999999999;

long long all(int l, int r, int u, int d){
	long long tot = 0;
	for (int i = l; i <= r; i++)
		for (int j = u; j <= d; j++)
			if (map[j][i] > 0)
				tot += map[j][i];
	return tot;
			
}

void dfs(int l, int r, int u, int d){
	if (all(l, r, u, d) < ans)
		return;
	for (int i = l; i < r; i++) {
		if (i - l < r - i) {
			for (int q = u; q <= d; q++)
				for (int j = l; j <= i; j++) {
					map[q][i + i - j + 1] += map[q][j];
					if(map[q][i + i - j + 1] > ans) 
						ans = map[q][i + i - j + 1];
				}
			dfs(i + 1, r, u, d);
			for (int q = u; q <= d; q++)
				for (int j = l; j <= i; j++)
					map[q][i + i - j + 1] -= map[q][j];
		} else {
			for (int q = u; q <= d; q++)
				for (int j = i + 1; j <= r; j++) {
					map[q][i - (j - i) + 1] += map[q][j];
					if (map[q][i - (j - i) + 1] > ans)
						ans = map[q][i - (j - i) + 1];
				}
			dfs(l, i, u, d);
			for (int q = u; q <= d; q++)
				for (int j = i + 1; j <= r; j++) 
					map[q][i - (j - i) + 1] -= map[q][j];
		}
	}
	for (int i = u; i < d; i++) {
		if(i - u < d - i) {
			for (int q = l; q <= r; q++)
				for (int j = u; j <= i; j++) {
					map[i + i - j + 1][q] += map[j][q];
					if(map[i + i - j + 1][q] > ans)
						ans = map[i + i - j + 1][q]; 
				}
			dfs(l, r, i + 1, d);
			for (int q = l; q <= r; q++)
				for (int j = u; j <= i; j++)
					map[i + i - j + 1][q] -= map[j][q];
		} else {
			for (int q = l; q <= r; q++)
				for (int j = i + 1; j <= d; j++) {
					map[i - (j - i) + 1][q] += map[j][q];
					if (map[i - (j - i) + 1][q] > ans)
						ans = map[i - (j - i) + 1][q]; 
				}
			dfs(l, r, u, i);
			for (int q = l; q <= r; q++)
				for (int j = i + 1; j <= d; j++)
					map[i - (j - i) + 1][q] += map[j][q];
		}
	}
}

int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			scanf("%d", &map[i][j]);
			if (map[i][j] > ans)
				ans = map[i][j];
		}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			if (map[i][j] > 0)
				judge[i][j] = judge[i][j - 1] + map[i][j];
			else
				judge[i][j] = judge[i][j - 1];
	dfs(1, m, 1, n);
	printf("%lld", ans);
	return 0;
}
