#include <iostream>
#include <cstdio>
#include <cstring>

#define mod 998244353

using namespace std;

long long n, m;

long long ans = 0;

bool flg[10000000];

int main() {
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	long long s = min(n, m);
	long long b = max(n,m);
	n = s;
	m = b;
	for (long long i = 1; i <= n; i++) {
		memset(flg, 0, sizeof(flg));
		long long tot = 0;
		for (int k = i; k > 1; k--)
			if (i % k == 0) {
				long long a;
				for (int q = 1; (a = k * q) <= m; q++) {
					if (!flg[a]) {
						tot++;
						ans += k;
						if (ans > mod)
							ans = ans % mod;
						flg[a] = true;
					}
				}
			}
		ans += m - tot;
	}
	printf("%lld", ans % mod);
	return 0;
}

