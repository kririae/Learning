#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<math.h>
const int N=998244353;
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long n,m,x;
	cin>>n>>m;
	n=n%N;
	m=m%N;
	x=(n*m-1)%N;
	cout<<x<<endl;
	return 0;	
}
