#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[21][510];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int n,m,x1=0,x2=0,y=-987654321;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			x1+=a[i][j];x2+=a[j][i];
		}
		y=max(y,x1);y=max(y,x2);
		x1=0;x2=0;
	}
	cout<<y<<endl;
	return 0;		
}
