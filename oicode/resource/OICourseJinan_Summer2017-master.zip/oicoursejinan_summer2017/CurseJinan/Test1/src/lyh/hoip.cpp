#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const int N=998244353;
int gcd(int x,int y)
{
	int g;
	if(x<y)
		swap(x,y);
	g=x%y;
	while(g!=0)
	{
		x=y;
		y=g;
		g=x%y;
	}
	return y;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int n,m,p=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			p+=gcd(i,j);
			p=p%N;
		}
	cout<<p<<endl;
	return 0; 
}
