#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
using namespace std;

struct ch{
	int m;
	int n;
};
queue<ch> q;
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	int ans=0;
	ch x;
	cin>>x.m>>x.n;
	if(x.n>x.m){
		int tt=x.m;
		x.m=x.n;
		x.n=tt;
	}
	q.push(x);
	while(!q.empty()){
		ch cur=q.front();
		q.pop();
		ch cur1;
		ch cur2;
		if(cur.n==1){
			ans+=cur.m;
			ans--;
			continue;
		}
		else{
			cur1.m=cur.m/2;
			cur1.n=cur.n;
			cur2.n=cur.n;
			cur2.m=cur.m-cur.m/2;
		    ans++;
		}
		if(cur1.n>cur1.m){
		int tt=cur1.m;
		cur1.m=cur1.n;	
		cur1.n=tt;
	    }
	    if(cur2.n>cur2.m){
		int tt=cur2.m;
		cur2.m=cur2.n;
		cur2.n=tt;
	    }
	    q.push(cur1);
	    q.push(cur2);
	    
	}
	
	cout<<ans;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
