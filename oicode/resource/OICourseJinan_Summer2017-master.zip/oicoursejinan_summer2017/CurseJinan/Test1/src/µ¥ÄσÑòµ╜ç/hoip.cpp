#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
inline int gcd(int a, int b)
{
    if(b == 0)
        return a;
    return gcd(b, a % b);
}

int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int m,n;
	int ans=0;
	scanf("%d%d",&m,&n);
	if(m>=n){
		for(int i=1; i<=n; i++){
		    for(int j=1; j<i; j++){
			    ans+=2*gcd(i,j);
		    }
		}
		for(int i=n+1; i<=m; i++){
			for(int j=1; j<=n; j++)
			ans+=gcd(i,j);
		}
		for(int i=1; i<=n; i++)
	        ans+=i;
	}
	else{
		for(int i=1; i<=m; i++){
		    for(int j=1; j<i; j++){
			    ans+=2*gcd(i,j);
		    }
	    }
	    for(int i=1; i<=m; i++)
	        ans+=i;
	    for(int i=1; i<=m; i++){
			for(int j=m+1; j<=n; j++)
			ans+=gcd(j,i);
		}    
	}
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
}
