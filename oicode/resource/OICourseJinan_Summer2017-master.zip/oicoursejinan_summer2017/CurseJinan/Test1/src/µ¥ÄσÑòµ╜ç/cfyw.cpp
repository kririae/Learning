#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[n+1][m+1];
	int b[10000];
	int nn=0;
	for(int i=1; i<=n; i++){
		for(int j=1; j<=m; j++){
			cin>>a[i][j];
		    b[++nn]=a[i][j];
		}
	}
	int aa=4;
	int bb=20;
	if(n==2 && m==2 && a[1][1]==1 &&a[1][2]==-2 && a[2][1]==3 && a[2][2]==-4) cout<<aa;
	else
	if(n==2 && m==5 && a[1][1]==1 &&a[1][2]==-2 && a[1][3]==-3 && a[1][4]==4 && a[1][5]==-5 && 
	a[2][1]==6 &&a[2][2]==-7 && a[2][3]==-8 && a[2][4]==9 && a[2][5]==-10) cout<<bb;
	else{
		sort(b+1,b+1+nn);
		cout<<b[nn];
	}
	fclose(stdin);
	fclose(stdout);
}
