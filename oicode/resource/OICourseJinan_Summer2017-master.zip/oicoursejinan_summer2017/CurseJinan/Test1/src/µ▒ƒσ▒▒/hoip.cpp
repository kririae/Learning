#include<cstdio>
int n,m,ans;
int ggcd(int x,int y){
	int z=x%y;
	while(z){
		x=y;
		y=z;
		z=x%y;
	}
	return y;
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){
			ans+=ggcd(i,j);
			while(ans>=998244353)
				ans-=998244353;
		}
	printf("%d",ans);
	return 0;
}
