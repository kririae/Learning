#include<cstdio>
#include<iostream>
using namespace std;
int flag,sum[21][501],ans=-4200000,n,m;
int dfs(int x,int y,int la1,int la2,int le1,int le2){
	for(int i=1;i<=x&&flag;++i){
		for(int i1=le1;i1<=le1+i-1;++i1)
			for(int i2=la1;i2<=la2;++i2){
				sum[i2][2*i-i1+2*le1-1]+=sum[i2][i1];
				ans=max(ans,sum[i2][2*i-i1+2*le1-1]);
			}
		dfs(x-i,y,la1,la2,le1+i,le2);
		for(int i1=le1;i1<=le1+i-1;++i1)
			for(int i2=la1;i2<=la2;++i2)
				sum[i2][2*i-i1+2*le1-1]-=sum[i2][i1];
	}
	for(int i=1;i<=y&&flag;++i){
		for(int i1=la1;i1<=la1+i-1;++i1)
			for(int i2=le1;i2<=le2;++i2){
				sum[2*i-i1+2*la1-1][i2]+=sum[i1][i2];
				ans=max(ans,sum[2*i-i1+2*la1-1][i2]);
			}
		dfs(x,y-i,la1+i,la2,le1,le2);
		for(int i1=la1;i1<=la1+i-1;++i1)
			for(int i2=le1;i2<=le2;++i2)
				sum[2*i-i1+2*la1-1][i2]-=sum[i1][i2];
	}
}
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
   	flag=1;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){
			scanf("%d",&sum[i][j]);
			ans=max(ans,sum[i][j]);
		}	
	dfs(m-1,n-1,1,n,1,m);
	if(!flag)
		return 0;
	printf("%d",ans);
	return 0;
}
