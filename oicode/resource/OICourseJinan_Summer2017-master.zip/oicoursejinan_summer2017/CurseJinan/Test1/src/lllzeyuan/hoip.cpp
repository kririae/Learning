#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,ans1,ans;
int y=998244353;
int gcd(int a,int b)
{
	int temp;
	while(b)
	{
		temp=b;
		b=a%b;
		a=temp;
	}
	return a;
}


int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			ans1+=gcd(i,j)%y;
		}
	ans=ans1%y;
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}


