#include <iostream>  
#include <cstdio> 
#include <algorithm> 
using namespace std;  
int t[60][60],n,m,m1,m2,bl=1,ans=0; 
int main()  
{  
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
    	for(int j=1;j<=m;j++){
    		cin>>t[i][j];
    		if(t[i][j]>m1)m1=t[i][j];
    		if(m1>m2)swap(m1,m2);
    		if(t[i][j]<0)bl=0;
    		if(bl)ans+=t[i][j];
		}
	}
	cout<<max(ans,m1+m2);
	fclose(stdin);
    fclose(stdout);
    return 0;  
}  
