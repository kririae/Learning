#include <iostream>  
#include <cstdio> 
#include<algorithm> 
using namespace std;  
typedef long long LL;
LL a,b,c=998244353,ans=0;

int main()  
{  
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);//
    cin>>a>>b;
    for(int i=1;i<=a;++i){
    	for(int j=1;j<=b;++j){
    		ans+=__gcd(i,j);
    		//cout<<i<<' '<<j<<' '<<__gcd(i,j)<<endl;
    		ans%=c;
		}
	}
    cout<<ans<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;  
}  
