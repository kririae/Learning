#include <iostream>  
#include <cstdio>  
using namespace std;  
typedef long long LL;
LL a,b,c=998244353;
LL C(){   
    LL ans=0;  
    a=a%c;  
    b=b%c;  
    while(b>0){  
        if(b&1) ans=(ans+a)%c;  
        a=(a+a)%c;  
        b>>=1;  
    }  
    return ans;  
}  
int main()  
{  
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
    cin>>a>>b;
    cout<<(C()-1+c)%c<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;  
}  
