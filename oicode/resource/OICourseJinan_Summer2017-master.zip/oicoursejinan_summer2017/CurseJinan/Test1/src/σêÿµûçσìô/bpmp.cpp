#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
using namespace std;
typedef long long ll;
const ll md = 998244353;
ll m, n;
int main()
{ 
    freopen("bpmp.in", "r", stdin);
    freopen("bpmp.out", "w", stdout);
    cin >> m >> n;
    ll ans = m * n - 1;
    cout << ans % md << endl;
}
