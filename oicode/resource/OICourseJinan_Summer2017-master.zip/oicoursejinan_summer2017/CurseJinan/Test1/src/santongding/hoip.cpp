#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,m;
int tot=0;
int prime[100005]={0};
int num_prime=0;
int isNotPrime[100005]={1,1};

void ifprime(int x){
	for(long i = 2 ; i < x ; i ++)         
        {              
       if(! isNotPrime[i])                 
            prime[num_prime ++]=i;    
        
        for(long j = 0 ; j < num_prime && i * prime[j] <  x ; j ++)  
          {                 
                isNotPrime[i * prime[j]] = 1;    
            if( !(i % prime[j] ) )                   
               break;             
        }          
    } 

}
inline int gcd(int a,int b){
	return !b ? a: gcd(b,a%b);
}
int main()
{	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	int xmax=max(n,m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
//	if((isNotPrime[i]==0)||(isNotPrime[j]==0))
//tot++;
		tot+=gcd(i,j)%998244353;}
//	ifprime(xmax);
	printf("%d ",tot%998244353);
//	printf("%d",isNotPrime[13]);
	return 0;
}
