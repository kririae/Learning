#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,m;
int v[21][501],a[501][501];
int xtot[501][21],ytot[21][501];
int xmax,ymax;
int tmpans=0;
int ans;
int vs(int x,int y){
	if (y*2<=x)return x-y;
	else return y;
}
void dfs(int q,int p,int &ans){
	int ans1=ans;
		for(int i=1;i<=p-1;i++)
	{	int tmp=vs(p,i);
		for(int j=1;j<=tmp;j++)
			{	
				if(((i+j)<=p)&&((i-j+1)>=1))
				{
				a[q][j]=a[q-1][i+j]+a[q-1][i-j+1];		
				}
			else	if ((i-j+1)>=1)
				a[q][j]=a[q-1][i-j+1];
			else	if((i+j)<=p)
				a[q][j]=a[q-1][i+j];
			else a[q][j]=0;

			if(a[q][j]>=ans1)
				{	//cout<<a[q][j]<<endl;
					ans1=a[q][j];
					tmpans=i;
				}
			}
	}
if (tmpans){
	ans=ans1;


		for(int j=1;j<=p;j++)
{
	if(((tmpans+j)<=p)&&((tmpans-j+1)>=1))
				{
				a[q][j]=a[q-1][tmpans+j]+a[q-1][tmpans-j+1];		
				}
			else	if ((tmpans-j+1)>=1)
				a[q][j]=a[q-1][tmpans-j+1];
			else	if((tmpans+j)<=p)
				a[q][j]=a[q-1][tmpans+j];
			else a[q][j]=0;
}
int tmp2=tmpans;
tmpans=0;
q++;
dfs(q,vs(p,tmp2),ans);
}
}

int main()
{	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	{	for(int j=1;j<=m;j++)
		{
			scanf("%d",&v[i][j]);
			xtot[0][i]+=v[i][j];
			a[0][j]+=v[i][j];
			xmax=max(xtot[0][i],xtot[0][i-1]);
			ymax=max(a[0][i],a[0][i-1]);
		}
	}

int ans=ymax;
//cout<<ans;
dfs(1,m,ans);
cout<<ans;

	return 0;
}
