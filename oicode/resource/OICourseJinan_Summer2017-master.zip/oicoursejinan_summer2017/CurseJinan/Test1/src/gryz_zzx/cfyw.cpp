#include <iostream>
#include <cstdio>
#include <algorithm>
#define ll long long 

using namespace std;
ll read()
{
	ll x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int pic[25][205],dp[25][205];
int n,m,ans;
int maxn=-10000;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	pic[i][j]=read(),maxn=max(maxn,pic[i][j]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		int k=1;
		while(1)
		{
			if(i+k>n&&j+k>m)break;
			if(i+k<=n)
			{
				dp[i][j]=max(dp[i][j],pic[i][j]+pic[i+k][j]);
			}
			if(j+k<=m)
			{
				dp[i][j]=max(dp[i][j],pic[i][j]+pic[i][j+k]);
			}
			k+=2;
		}
		ans=max(ans,dp[i][j]);
	}
	printf("%d",max(maxn,ans));
	return 0;
}
