#include<iostream>
#include<cstdio>
using namespace std;
int n,m;
typedef long long LL ;  
const int mod=998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(!n||!m)
	{
		puts("0");return 0;
	}
	LL ans=(((n%mod*m%mod)%mod)-1%mod)%mod;
	printf("%I64d",ans);
	return 0;
}
