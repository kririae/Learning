#include<cstdio>  
#include<algorithm>  
using namespace std;  
const int maxn = 10000005;  
typedef long long LL ;  
const int mod=998244353;
LL f[maxn]; 
int main()  
{  
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
    int n,m;  
    scanf("%d%d",&n,&m);  
    LL q=min(n,m);  
    LL ans=0;  
    for(int i=q;i;i--)
	{  
        f[i]=(LL)(m/i)*(n/i);  
        for(int j=i+i;j<maxn;j+=i)  
		f[i]-=f[j];  
        ans+=f[i]*i;
    }  
    printf("%I64d\n",ans%mod);  
    return 0;  
}  
