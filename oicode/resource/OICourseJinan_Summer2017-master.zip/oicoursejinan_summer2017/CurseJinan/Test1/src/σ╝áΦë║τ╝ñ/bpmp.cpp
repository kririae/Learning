#include<cstdio>
#include<iostream>
using namespace std;
const int p = 998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	int q = (1ll * n * m - 1) % p;
	printf("%d",q);
	return 0;
}
