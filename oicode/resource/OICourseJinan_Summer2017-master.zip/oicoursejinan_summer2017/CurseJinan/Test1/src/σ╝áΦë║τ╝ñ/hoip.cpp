#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int p = 998244353;
long long q[10000010];
int n,m;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int i,j;
	long long s = 0;
	scanf("%d%d",&n,&m);
	if(n > m) swap(n,m);
	for(i = n;i >= 1;i--)
	{
		q[i] = 1ll * (n / i) * (m / i);
		for(j = i + i;j <= n;j += i) q[i] -= q[j];
		s += q[i] * i;
	}
	printf("%d",s % p);
	return 0;
}
