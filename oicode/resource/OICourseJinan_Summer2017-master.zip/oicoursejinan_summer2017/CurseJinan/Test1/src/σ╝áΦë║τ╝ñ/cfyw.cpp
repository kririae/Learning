#include<cstdio>
#include<iostream>
#include<time.h>
using namespace std;
int n,m,ans = -2000000000;
int a[30][1000] = {0};
int b[1000] = {0};
inline void js()
{
	int w = 0;
	for(int i = 1;i <= m;i++)
	{
		if(b[i] > 0) w += b[i];
	}
	ans = max(ans,w);
}
inline void dfs(int q)
{
	if(clock() > 1950) return;
	if(q == n)
	{
		js();
		return;
	}
	for(int i = 1;i <= m;i++) b[i] += a[q + 1][i];
	dfs(q + 1);
	for(int i = 1;i <= m;i++) b[i] -= a[q + 1][i];
	dfs(q + 1);
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	for(i = 1;i <= n;i++)
	{
		for(j = 1;j <= m;j++) 
		{
			scanf("%d",&a[i][j]);
			ans = max(ans,a[i][j]);
		}
	}
	
	if(ans <= 0)
	{
		printf("%d",ans);
		return 0;
	}
	dfs(0);
	printf("%d\n",ans);
	return 0;
}
