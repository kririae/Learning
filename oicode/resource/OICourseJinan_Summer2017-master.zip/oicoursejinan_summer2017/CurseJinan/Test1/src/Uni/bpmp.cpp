#include<cstdio>
const int mod = 998244353;
int main() {
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	long long n, m;
	scanf("%lld%lld", &n, &m);
	printf("%lld\n", (m*n-1)%mod);
	return 0;
}
