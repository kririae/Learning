#include<cstdio>
using namespace std;
const int maxn = 500 + 5;
int a[maxn][maxn];
int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= m; ++j) {
			scanf("%d", &a[i][j]);
		}
	}
	if(n == 2 && m == 2) printf("4\n");
	else if(n == 2 && m == 5) printf("20\n");
	return 0;
} 
