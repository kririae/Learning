#include<cstdio>
#include<algorithm>
using namespace std;
const int mod = 998244353;
const int maxn = 10000000 + 5;
int gcd(int a, int b) {
	if(b == 0) return a;
	else return gcd(b, a%b);
}
int main() {
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	int n, m;
	long long ans = 0;
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= m; ++j) {
			ans += gcd(i, j);
			ans %= mod;
		}
	}
	printf("%lld\n", ans);
	return 0;
}
