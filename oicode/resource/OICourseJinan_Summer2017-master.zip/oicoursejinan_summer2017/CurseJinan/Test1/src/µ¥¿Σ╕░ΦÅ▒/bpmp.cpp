#include<cstdio>

int main()
{
	FILE * fin;
	FILE * fout;
	fin=fopen("bpmp.in","r");
	fout=fopen("bpmp.out","w");
	int n,m,n1,m1;
	int i,j,k;
	long long num1,num2=0;
	fscanf(fin,"%d %d",&n,&m);
	for(i=2;i<=n;i++)
	{
		if(n%i==0 || n==1)
		{
			n1=n/i;
			if(n>=3) j=3;
			else j=2;
			for(;j<=m;j++)
			{
				if(m%j==0 || m==1)
				{
					m1 = m / j;
					num1 = n1 * m1 - 1;
					num1 = num1 % 998244353;
					for(k=1;k<=i*j;k++)
					{
						num2 += num1;
						num2 %= 998244353;
					}
					break;
				}
			}
			num2 += i - 1 + (j - 1) * i;
			num2 %= 998244353;
			break;
		}
	}
	fprintf(fin,"%lld",num2);
	return 0;
}
