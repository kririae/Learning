#include<cstdio>

int gong(int n,int m)
{
	for(int i=n;i>=1;i--)
	{
		if(m%i==0 && n%i==0)
		{
			return i;
		}
	}
}

int main()
{
	FILE * fin;
	FILE * fout;
	fin=fopen("hoip.in","r");
	fout=fopen("hoip.out","w");
	int i,j;
	int n,m;
	long num=0,num1;
	fscanf(fin,"%d %d",&n,&m);
	for(i=2;i<=n;i++)
	{
		for(j=2;j<=m;j++)
		{
			if(i<j)
			{
				num+=gong(i,j);
			}
			else if(i>j)
			{
				num+=gong(j,i);
			}
			else num+=i;
			num %= 998244353;
		}
	}
	num+=(n+m-1);
	num%=998244353;
	fprintf(fout,"%ld",num);
	return 0;
}
