#include<cstdio>

int b[21]={0};
int c[21]={0};
int n,m;
int max=-100;

int heng(int i,int num)
{
	if(num>max) max=num;
	int k;
	for(k=i;k<=m;k+=2)
	{
		heng(k+1,num+b[k+1]);
	}
}

int shu(int i,int num)
{
	if(num>max) max=num;
	int k;
	for(k=i;k<=n;k+=2)
	{
		shu(k+1,num+c[k+1]);
	}
}

int main()
{
	FILE * fin;
	FILE * fout;
	fin=fopen("cfyw.in","r");
	fout=fopen("cfyw.out","w");
	int a[21][500];
	int i,j;
	int num;
	fscanf(fin,"%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		num=0;
		for(j=1;j<=m;j++)
		{
			fscanf(fin,"%d",&a[i][j]);
			b[j]+=a[i][j];
			num+=a[i][j];
		}
		c[i]=num;
	}
	for(i=1;i<=m;i++)
	{
		heng(i,b[i]);
	}
	for(i=1;i<=n;i++)
	{
		shu(i,c[i]);
	}
	fprintf(fout,"%d",max);
	return 0;
}
