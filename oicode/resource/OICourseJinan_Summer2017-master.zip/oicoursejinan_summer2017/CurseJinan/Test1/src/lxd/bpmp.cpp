#include <iostream>
#include <fstream>

using namespace std;

fstream fin("bpmp.in",ios::in);
fstream fout("bpmp.out",ios::out);

#define in fin
#define out fout

#define mo 998244353

long long n,m;
long long ans=0;

void run()
{
	ans=(m*n-1)%mo;
}

void release()
{
	fin.close();
	fout.close();
}

int main()
{
	in>>n>>m;
	run();
	out<<ans;
	release();
	return 0;
}