#include <iostream>
#include <fstream>
#include <map>
#include <cstring>
#include <ctime>
#include <algorithm>

using namespace std;

fstream fin("hoip.in",ios::in);
fstream fout("hoip.out",ios::out);

#define in fin
#define out fout

#define mo 998244353

//#define MYDEBUG

long long n,m;
long long ans=0;

long long** db;

inline void dbinit()
{
	db=new long long*[max(n,m)];
	for(long long i=0;i<max(n,m);i++)
	{
		db[i]=new long long[i+1];
	}
}

inline void dbrelease()
{
	for(long long i=0;i<max(n,m);i++)
	{
		delete db[i];
	}
	delete[] db;
}

inline long long get(long long a,long long b)
{
	if(a<b)
	{
		swap(a,b);
	}
	return db[a-1][b-1];
}

inline long long add(long long a,long long b,long long re)
{
	if(a<b)
	{
		swap(a,b);
	}
	db[a-1][b-1]=re;
	return re;
}


long long gcd(long long a,long long b)
{
	if(get(a,b))
	{
		return get(a,b);
	}
	else
	{
		if(a==b)
		{
			return add(a,b,a);
		}
		if(b==1||a==1)
		{
			return add(a,b,1);
		}
		return add(a,b,gcd(b,a%b));
	}
}

void init()
{
	dbinit();
	for(long long i=0;i<max(n,m);i++)
	{
		for(long long j=i;j>=0;j--)
		{
			db[i][j]=0;
		}
	}
}

void run()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			ans=(ans+gcd(i,j))%mo;
		}
	}
}

void release()
{
	dbrelease();
	fin.close();
	fout.close();
}

int main()
{
	in>>n>>m;
	init();
	run();
	out<<ans;
	release();
	#ifdef MYDEBUG
	cout<<"time:"<<clock()/CLOCKS_PER_SEC;
	system("pause");
	#endif

	return 0;
}