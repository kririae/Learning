#include<cstdio>
#include<algorithm>
using namespace std;
long long m,n,sum;
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	sum=(m*n-1)%998244353;
	printf("%d",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
