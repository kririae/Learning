#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,sum;
int find(int xx,int yy){
	int ans=1;
	int mi=min(xx,yy);
	for (int i=mi;i>=2;i--)
	 if ((xx%i==0)&&(yy%i==0)){
	 	ans=i;
	 	break;
	 }
	//printf("%d\n",ans);
	return ans;	 
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	sum=(n+m-1)%998244353;
	for (int i=2;i<=n;i++)
	 for (int j=2;j<=m;j++){
	 	if (i==j) sum=(sum+i)%998244353;
	 	else if (j%i==0) sum=(sum+i)%998244353;
	 	else if (i%j==0) sum=(sum+j)%998244353;
	 	else if (((i%2!=0)&&(j%2==0))||((i%2==0)&&(j%2!=0))) sum++;
	 	else sum=(sum+find(i,j))%998244353;
	 	//printf("i=%d j=%d sum=%d\n",i,j,sum);
	 }
	printf("%d",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
