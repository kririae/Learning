#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,sum,num;
int a[10001][10001];
bool f[10001][10001];
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	 for (int j=1;j<=m;j++){
	 	scanf("%d",&a[i][j]);
	 	if (a[i][j]>0){
	 		num++;
	 		sum=sum+a[i][j];
	 		f[i][j]=true;
		 }
	 }
	//if (num==n*m){
		printf("%d",sum);
		fclose(stdin);
		fclose(stdout);
		return 0;
	//}
}
