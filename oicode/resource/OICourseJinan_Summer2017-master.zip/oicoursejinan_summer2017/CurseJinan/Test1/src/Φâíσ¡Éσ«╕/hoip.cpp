#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>//��ѧ���� 
#include<string>//�ַ��� 
#include<cstdlib> 	 
#include<algorithm>//�㷨�� 
#include<vector>//���������� 
#include<set>//���� 
#include<map>//ӳ�� 
#include<sstream>//�ַ����� 
#include<stack>//ջ 
#include<iterator>//������ 
#include<queue>//���� 
#include<functional>//�������� 
#include<list>//���� 
#include<deque>//˫�˶��� 
#include<utility>//pair���� 
#include<numeric>//accumulate�ۼӺ��� 
using namespace std;

const int r=998244353;
long long n,m;
//int an[10005],am[10005];
int t=1,v=0;
int a[100005][3];
int daan,sum;

inline int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}

void zhi(int x)
{
	for(int p=3; p<=x; p++)
	{
		for(int i=2; i<p; i++)
		{
			if( !(p%i) ) v=1;
			//if(v) break;	
		}
		if(!v)
		{
			a[p][2]=1;
		}
		
	}
	return;
}

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout); 
	scanf("%lld %lld",&n, &m );
	long long tot=max(n,m);
	for(int i=1; i<=tot; i++)
	{
		a[i][1]=i;
	}
	zhi( tot );//zhi2(m);
	if(n==2)
	{
		daan=m+( m/2 )*2+m-( m/2 );
		printf("%d", daan );
		return 0;
	}
	if(m==2)
	{
		daan=n+( n/2 )*2+n-( n/2 );
		printf("%d", daan );
		return 0;
	}
	if(m==1)
	{
		daan=n;
		printf("%d", n);
		return 0;
	}
	if(n==1)
	{
		daan=m;
		printf("%d", m);
		return 0;
	}
	if(n>=m) 
	sum+=n+( n/2 )*2+n-( n/2 );
	else
	sum+=m+( m/2 )*2+m-( m/2 );
	//int s1=sizeof(an);
	//int s2=sizeof(am);
	int d=min(n,m);
	for(int i=3; i<=tot; i++)
	{
		//if( (i%a[i][1])==0 )
		if( a[i][2] ) sum+=a[i][1]-( d/a[i][1] )*a[i][1];
		else 
		{
			for(int y=3; y<=d; y++)
			{
				sum+=gcd(i,y);
			}
		}
	}
	
	printf("%d", sum);
	return 0;
	
	
}







