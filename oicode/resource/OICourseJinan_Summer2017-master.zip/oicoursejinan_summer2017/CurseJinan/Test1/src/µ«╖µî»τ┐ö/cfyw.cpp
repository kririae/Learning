#include<bits/stdc++.h>
using namespace std;
int a[23][505],sum[505],ans=-999999,n,m,f[505],mx[2];
void dfs(int now){
	mx[0]=mx[1]=-999999;
	for(int i=1;i<=m;++i)	sum[i]+=a[now][i];
	for(int i=1;i<=m;++i){
		f[i]=sum[i];
		f[i] += max(0, mx[(i&1)^1]);
		ans = max(ans,f[i]);
		mx[i&1] = max(mx[i&1],f[i]);
	}
	for(int i=now+1;i<=n;++++i)	dfs(i);
	for(int i=1;i<=m;++i)	sum[i]-=a[now][i];
}

int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)scanf("%d",&a[i][j]);
	for(int i=1;i<=n;++i)	dfs(i);
	printf("%d",ans);
	return 0;
}
