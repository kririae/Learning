#include<cstdio>
int main(){
 	freopen("bpmp.in","r",stdin);
 	freopen("bpmp.out","w",stdout);
	long long a,b;
	scanf("%d%d",&a,&b);
    printf("%lld",(a*b-1)%998244353);
    return 0;
}
