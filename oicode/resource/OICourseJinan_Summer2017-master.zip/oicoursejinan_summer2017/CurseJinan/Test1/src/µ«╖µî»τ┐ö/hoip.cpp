#include<bits/stdc++.h>
using namespace std;
int main(){
	int a,b;
  freopen("hoip.in","r",stdin);
  freopen("hoip.out","w",stdout);
	scanf("%d%d",&a,&b);
    printf("%d",a*b%998244353);
    return 0; 	
}
