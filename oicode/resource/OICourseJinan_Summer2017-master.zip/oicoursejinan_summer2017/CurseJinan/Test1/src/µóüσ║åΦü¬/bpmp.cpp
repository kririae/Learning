#include<iostream>
#include<cstdio>
#include<algorithm>
#define MOD 998244353
using namespace std;

char a[15],b[15];
int len1=0,len2=0,len=0,sum[30],mod[10]={0,9,9,8,2,4,4,3,5,3};
long long n,m;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	if(n==1){printf("%lld",(m-1)%MOD);return 0;}
	else if(m<=1005&&n<=10005){printf("%lld",(m*n-1)%MOD);return 0;}
	long long k;
	if(m>n){k=n;n=m;m=k;}
	while(n>=10)
	{
		len1++;
		k=n%10;
		a[len1]=k;
		n/=10;
	}
	a[++len1]=n;
	//for(int i=1;i<=len1;i++)printf("%d",a[i])-'0';
	for(int i=1;i<=len1/2;i++)swap(a[i],a[len1+1-i]);
	//for(int i=1;i<=len1;i++)printf("%d",a[i]);cout<<endl;
	//int  s=len1;
	/*while(m>=10)
	{
		k=m%10;
		b[s--]=k;
		m/=10;
		//cout<<s<<"*";
	}
	b[s]=m;s--;*/
	while(m>=10)
	{
		len2++;
		k=m%10;
		b[len2]=k;
		m/=10;
	}
	b[++len2]=m;
	for(int i=1;i<=len2/2;i++)swap(b[i],b[len2+1-i]);
	//for(int i=1;i<=len2;i++)printf("%d",b[i]);cout<<endl;
	
	len=len1;
	for(int i=1;i<=len1;i++)
		for(int j=1;j<=len2;j++)
		{
			sum[j+i-1]+=a[i]*b[j];
		}
	while(sum[len+1])len++;
	for(int i=1;i<=len;i++){sum[i+1]+=sum[i]/10;sum[i]%=10;}
	while(sum[len+1])len++;sum[1]-=1;
	if(len>9)
	{
		k=1;
		while(k)
		{
			for(int i=1;i<=9;i++)
			{
				sum[i]-=mod[10-i];
			}
			for(int i=1;i<=len;i++)if(sum[i]<0){sum[i]+=10;sum[i+1]--;}
			while(!sum[len]){len--;}
			if(len<=9)k--;
		}
	}
	for(int i=len;i>=1;i--)printf("%d",sum[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
