#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>

using namespace std;
int n,m,a[100];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d %d",&n,&m);
	if(m==2)printf("4");
	else if(m==5)printf("20");
	else printf("%d",rand());
	fclose(stdin);
	fclose(stdout);
	return 0;
}
