#include<iostream>
#include<cstdio>
#include<algorithm>
#define MOD 998244353

using namespace std;
int c[9005][9005];

int  gcd(int a,int b)
{
	if(b==0)return a;
		else return gcd(b,a%b);
}


int n,m,a[100];
long long sum=0;

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(c[i][j]!=0){sum+=c[i][j]%MOD;sum%=MOD;continue;}
			else 
			{
				c[i][j]=c[j][i]=gcd(i,j);
				sum+=c[i][j]%MOD;
				sum%=MOD;
			}
		}
	printf("%lld",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
