#include<iostream>
#include<cstdio>
#include<cctype>

using namespace std;
#define ll long long
#define in =read()
const ll size = 10000 + 10;
ll n, m;
ll ans;

inline ll read() {
	ll f = 1, num = 0;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch = '-') f = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		num = num * 10 + ch - '0';
		ch = getchar();
	}
	return num * f;
}

ll gcd(ll x,ll y)
{
	ll a = max(x,y); ll b = min(x,y);
	ll c = a % b;
	if(c == 0) return b;
	else if(c != 0){
		a = b; b = c;
		gcd(a,b);
	}
}

int main() {
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	n in; m in;
	for(int i = 2; i <= m; i ++){
		for(int j = 2; j <= n; j ++){
			ans += gcd(i,j);
		}
	}
	printf("%d",(ans + n + m - 1) % 998244353);
}
