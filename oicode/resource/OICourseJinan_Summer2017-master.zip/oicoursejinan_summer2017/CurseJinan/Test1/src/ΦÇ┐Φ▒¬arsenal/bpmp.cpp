#include<iostream>
#include<cstdio>
#include<cctype>
using namespace std;
#define ll long long
#define in =read()
const ll size = 10000 + 10;
ll n, m;
ll ans;
ll t = 1, p = 0;

inline ll read() {
	ll f = 1, num = 0;
	char ch = getchar();
	while(!isdigit(ch)) {
		if(ch = '-') f = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		num = num * 10 + ch - '0';
		ch = getchar();
	}
	return num * f;
}

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	n in; m in;
	n = n % 998244353;
	m = m % 998244353;
	ans = n * m - 1;
	printf("%d",ans % 998244353);
}
