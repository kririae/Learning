#include<iostream>
#include<cstdio>
#include<cctype>
#include<algorithm>

using namespace std;
#define ll long long 
#define in =read()
const ll size = 10000 + 10;
const ll len = 500 + 10;
ll n, m, ans;
ll map[len][len];
ll a[size],b[size];

inline ll read()
{
    ll f = 1, num = 0; char ch = getchar();
    while(!isdigit(ch)){
        if(ch = '-') f = -1;
        ch = getchar();
    }
    while(isdigit(ch)){
        num = num * 10 + ch - '0';
        ch = getchar();
    }
    return num * f;
}

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	n in; m in;
	for(int i = 1; i <= n; i ++){
		for(int j = 1; j <= m; j ++){
			map[i][j] in;
		}
	}
	int t = 1, h = 1;
	for(int i = 1; i <= n; i ++){
		for(int j = 1; j <= m; j ++){
			a[t] += map[i][j];
		}
		t ++;
	}
	sort(a,a+t+1);
	for(int i = 1; i <= m; i ++){
		for(int j = 1; j <= n; j ++){
			b[h] += map[j][i];
		}
		h ++;
	}
	sort(b,b+h+1);
	ans = max(a[t],b[h]);
	printf("%d",ans);
}
