#include<iostream>
#include<cstdio>

using namespace std;

long long m,n;

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	if(n==1) cout<<(m-1)%998244353;
	  else 
	  		{
	  		cout<<((n%998244353)*(m%998244353)-1)%998244353;				}
	return 0;
}
