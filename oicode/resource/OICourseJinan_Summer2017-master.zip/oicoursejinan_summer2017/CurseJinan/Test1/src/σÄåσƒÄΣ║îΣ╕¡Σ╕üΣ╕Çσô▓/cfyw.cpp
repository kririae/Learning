#include<iostream>
#include<cstdio>

using namespace std;
int n,m;
long long a[25][505];

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	long long ans=0;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			if(a[i][j]>0)
			ans+=a[i][j];
		}
	cout<<ans<<endl;
	return 0;
}
