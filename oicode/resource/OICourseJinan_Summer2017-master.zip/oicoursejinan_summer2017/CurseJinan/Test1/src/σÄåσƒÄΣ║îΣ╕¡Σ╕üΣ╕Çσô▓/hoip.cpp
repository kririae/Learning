#include<iostream>
#include<cstdio>
using namespace std;
long long n,m;
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
const int MD=998244353;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	long long ans=0;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	  {
	  	ans+=gcd(i,j)%MD;
	  }
	cout<<ans%MD<<endl;
	return 0;
}
