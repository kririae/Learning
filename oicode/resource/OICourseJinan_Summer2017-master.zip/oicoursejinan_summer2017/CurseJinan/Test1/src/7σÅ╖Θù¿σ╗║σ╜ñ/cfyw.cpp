#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int MAXN = 510;
const int INF = 1e8;
int n,m,ans = -INF,tmp,cnt,ad;
int a[MAXN][MAXN];
bool hen[MAXN],shu[MAXN];

void dfs(int sum,int lx,int ly,int rx,int ry)
{
	ans = max(ans,sum);
	for (int i=ly; i<=(ry/2); ++i)
	{
		if (hen[i]) continue ;
		hen[i] = true ;
		ad = -INF;
		for (int j=i+1; j<=i+i; ++j)
			for (int k=lx; k<=rx; ++k)
				a[j][k] += a[i+i+1-j][k], ad = max(ad,a[j][k]);	
		ad = max(ad,sum);
		dfs(ad,lx,i+1,rx,ry);
		
		for (int j=i+1; j<=i+i; ++j)
			for (int k=lx; k<=rx; ++k)
				a[j][k] -= a[i+i+1-j][k];
		hen[i] = false;
	}
	for (int i=ry-1; i>=(ry/2+1); --i)
	{
		if (hen[i]) continue ;
		hen[i] = true;
		ad = -INF;
		for (int j=i; j>=(i+1+i-ry); --j)
			for (int k=lx; k<=rx; ++k)
				a[j][k] += a[i+i+1-j][k],ad = max(ad,a[j][k]);
		ad = max(ad,sum);
		dfs(ad,lx,ly,rx,i);		
		for (int j=i; j>=(i+1+i-ry); --j)
			for (int k=lx; k<=rx; ++k)
				a[j][k] -= a[i+i+1-j][k];
		hen[i] = false;		
	}
	
	for (int i=lx; i<=(rx/2); ++i)
	{
		if (shu[i]) continue ;
		shu[i] = true ;
		ad = -INF;
		for (int j=i+1; j<=i+i; ++j)
			for (int k=ly; k<=ry; ++k)
				a[j][k] += a[i+i+1-j][k], ad = max(ad,a[j][k]);
		ad = max(ad,sum);
		dfs(ad,i+1,ly,rx,ry);
		for (int j=i+1; j<=i+i; ++j)
			for (int k=ly; k<=ry; ++k)
				a[j][k] -= a[i+i+1-j][k];
		shu[i] = false ;
	}
	for (int i=rx-1; i>=(rx/2+1); --i)
	{
		if (shu[i]) continue ;
		shu[i] = true;
		ad = -INF;
		for (int j=i; j>=(i+1+i-rx); --j)
			for (int k=ly; k<=ry; ++k)
				a[j][k] += a[i+i+1-j][k], ad = max(ad,a[j][k]);
		ad = max(ad,sum);
		dfs(ad,lx,ly,i,ry);
		for (int j=i; j>=(i+1+i-rx); --j)
			for (int k=ly; k<=ry; ++k)
				a[j][k] -= a[i+i+1-j][k];
		shu[i] = false;
	}
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; ++i)
		for (int j=1; j<=m; ++j)
			scanf("%d",&a[i][j]);
	dfs(-1e8,1,1,m,n);
	printf("%d",ans);
	return 0;
}
