#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const long long mod = 998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long ans,n,m;
	cin>>n>>m;
	ans = ((n-1)%mod + ((m-1)*n)%mod + mod)%mod;
	cout<<ans;
	return 0;
}
