#include<algorithm>
#include<cstdio>
#include<iostream>
using namespace std;
const int mod = 998244353;
inline int gcd(int x,int y)
{
	if (y==0) return x;
	return gcd(y,x%y);
}

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int ans = 0,n,m,t,d;
	cin>>n>>m;
	if (n==m)
	{
		ans += (n+n-1);	//��1��x����x��1��ʱ 
		for (int i=2; i<=n; ++i)
		{
			for (int j=i+1; j<=n; ++j)
				ans = (ans+(gcd(i,j)*2))%mod;
			ans = (ans+i)%mod;	//(i,i) 
		}
		printf("%d",ans);
		return 0;
	}
	t = min(n,m);
	d = max(n,m);
	
	ans += (t+t-1);
	for (int i=2; i<=t; ++i)
	{
		for (int j=i+1; j<=t; ++j)
			ans = (ans+(gcd(i,j)*2))%mod;
		ans = (ans+i)%mod;
	}
	for (int i=t+1; i<=d; ++i)
		for (int j=1; j<=t; ++j)
			ans = (ans+gcd(i,j))%mod;
	printf("%d",ans);
	return 0;
}
