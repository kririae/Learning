#include<cstdio>
#include<cctype>
#include<iostream>
using namespace std;
typedef long long ll;
const int ha=998244353;
int m,n,ans;
int g[1001][1001];
inline void in(int &x){
    x=0;int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
    x*=f;
}
inline void out(int x){//�������� 
	char c[10]={0};
	while(c[++c[0]]=x%10+'0',x/=10,x);
	while(putchar(c[c[0]]),--c[0],c[0]);
}
inline int gcd(int x,int y){
	if(y>x) swap(x,y);
	if(x<=1000&&y<=1000){
		if(g[x][y]) return g[x][y];
		return !y?x:gcd(y,x%y);
	}
	return !y?x:gcd(y,x%y);
}
inline int mian(){
	freopen("hoip.in","r",stdin);
    freopen("hoip.out","w",stdout);
    in(n);in(m);
    for(int i=1;i<=n;i++)
    	for(int j=1;j<=m;j++){
    		ans=(ans+gcd(i,j)%ha)%ha;
		}
	out(ans);
	return 0;
}
int shimakaze=mian();
int main(){;}
