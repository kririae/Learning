#include<cstdio>
#include<cctype>
#include<iostream>
using namespace std;
int n,m;
int g[21][501],s[21][501],ans=-0xfffffff;
int x1,x2,y1,y2,si;
inline void in(int &x){
    x=0;int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
    x*=f;
}
inline void out(int x){//�������� 
	char c[10]={0};
	while(c[++c[0]]=x%10+'0',x/=10,x);
	while(putchar(c[c[0]]),--c[0],c[0]);
}
inline int mian(){
	freopen("cfyw.in","r",stdin);
    freopen("cfyw.out","w",stdout);
    in(n);in(m);
    for(int i=1;i<=n;i++)
    	for(int j=1;j<=m;j++){
    		in(g[i][j]);
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+g[i][j];
	for(int i=1;i<=n;i++)
	 	for(int j=1;j<=m;j++)
	  		for(int k=0;k<=max(m,n);k++)
				for(int l=0;l<=max(m,n);l++){
	  			x1=max(0,i-k-1);y1=max(0,j-l-1);
	  			x2=min(n,i+k);y2=min(m,j+l);
	  			si=s[x2][y2]-s[x1][y2]-s[x2][y1]+s[x1][y1];
				ans=max(ans,si);
	}
	if(ans>=0) out(ans);
	else printf("%d",ans);
	return 0;
}
int shimakaze=mian();
int main(){;}
