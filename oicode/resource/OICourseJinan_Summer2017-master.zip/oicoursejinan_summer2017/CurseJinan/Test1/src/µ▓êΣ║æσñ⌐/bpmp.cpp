#include<cstdio>
#include<cctype>
#include<iostream>
using namespace std;
typedef long long ll;
const int ha=998244353;
int m,n;
//int f[1001][1001];
inline void in(int &x){
    x=0;int f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
    x*=f;
}
inline void out(int x){//�������� 
	char c[10]={0};
	while(c[++c[0]]=x%10+'0',x/=10,x);
	while(putchar(c[c[0]]),--c[0],c[0]);
}
/*
inline int dfs(int x,int y){
	if(f[x][y]||(x==1&&y==1)) return f[x][y];
	if(x==1){
		if(y%2){
			f[x][y]=dfs(x,y/2)+dfs(x,y/2+1)+1;
			return f[x][y];
		}else{
			f[x][y]=dfs(x,y/2)+dfs(x,y/2)+1;
			return f[x][y];
		}
	}
	if(y==1){
		if(x%2){
			f[x][y]=dfs(x/2,y)+dfs(x/2+1,y)+1;
			return f[x][y];
		}else{
			f[x][y]=dfs(x/2,y)+dfs(x/2,y)+1;
			return f[x][y];
		}
	}
	if((x%2)&&(y%2)){
		f[x][y]=min(dfs(x/2,y)+dfs(x/2+1,y)+1,dfs(x,y/2)+dfs(x,y/2+1)+1);
		return f[x][y];
	}
	if((!(x%2))&&(y%2)){
		f[x][y]=min(dfs(x/2,y)+dfs(x/2,y)+1,dfs(x,y/2)+dfs(x,y/2+1)+1);
		return f[x][y];
	}
	if((x%2)&&(!(y%2))){
		f[x][y]=min(dfs(x/2,y)+dfs(x/2+1,y)+1,dfs(x,y/2)+dfs(x,y/2)+1);
		return f[x][y];
	}
	if((!(x%2))&&(!(y%2))){
		f[x][y]=min(dfs(x/2,y)+dfs(x/2,y)+1,dfs(x,y/2)+dfs(x,y/2)+1);
		return f[x][y];
	}
}
*/
inline int mian(){
	freopen("bpmp.in","r",stdin);
    freopen("bpmp.out","w",stdout);
    //f[1][1]=0;f[1][2]=1;f[2][1]=1;
    in(n);in(m);
    //if(n<=1000&&m<=1000) out(dfs(n,m));
    //else{
    	int ans=(((ll)(n%ha)*(m%ha))%ha-1)%ha;
    	out(ans);
	//}
	return 0;
}
int shimakaze=mian();
int main(){;}
