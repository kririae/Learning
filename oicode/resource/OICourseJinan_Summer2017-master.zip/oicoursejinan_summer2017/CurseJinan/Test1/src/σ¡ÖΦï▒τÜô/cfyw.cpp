#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
int n,m,a[600][600],maxn=-0x7ffffffff;
int hang,lie,f[60][600],tot;

int pd()
{
	for(int i=1;i<=hang;i++)
	{
    	if(f[1][i]==1)
	    tot++;
	}
    for(int j=1;j<=lie;j++)
    {
	     if(f[2][j]==1)
	     tot++;
	}
	if(tot==hang+lie)
	return 1;
	else
	{
		tot=0;
		return 0;
	}
}

void zd()
{
	for(int p=1;p<=n;p++)
	   for(int q=1;q<=m;q++)
	      if(maxn<a[p][q])
	      maxn=a[p][q];
}

void zz(int h,int l)
{
	if(pd()==1)
	{
		cout<<maxn;
		return;
	}
	 
	for(int j=1;j<=h+l;j++)
	   {
	   	   if(j<=h/2&&f[1][j]==0)
	   	   {
	   	       for(int k=1;k<=l+1;k++)
				  {
				  	  a[j+1][k]+=a[j][k];
				  	  zd();
		    	  } 	
		    	f[1][j]=1;
		    	zz(h-1,l);
			   for(int k=1;k<=l+1;k++)
				  {
				  	  a[j+1][k]-=a[j][k];
		    	  } 
		    	  f[1][j]=0;
		   }
		   
		   
		   if(j>=h/2&&j<=h&&f[1][j]==0)
	   	   {
	   	       for(int k=1;k<=l+1;k++)
				  {
				  	  a[j][k]+=a[j+1][k];
				  	  zd();
		    	  } 	
		    	f[1][j]=1;
		    	zz(h-1,l);
			   for(int k=1;k<=l+1;k++)
				  {
				  	  a[j][k]-=a[j+1][k];
		    	  } 
		    	  f[1][j]=0;
		   }
		   
		if(j>h&&j-h<=l/2&&f[j-h][1]==0)
	   	   {
	   	       for(int k=1;k<=h+1;k++)
				  {
				  	  a[k][j+1-h]+=a[k][j-h];
				  	  zd();
		    	  } 	
		    	f[j-h][1]=1;
		    	zz(h,l-1);
			   for(int k=1;k<=h+1;k++)
				  {
				  	  a[k][j+1-h]-=a[k][j-h];
		    	  } 
		    	 f[j-h][1]=0;
		   }
		   	   
	    if(j-h>l/2&&f[j-h][1]==0)
	   	   {
	   	       for(int k=1;k<=h+1;k++)
				  {
				  	  a[k][j-h]+=a[k][j+1-h];
				  	  zd();
		    	  } 	
		    	f[j-h][1]=1;
		    	zz(h,l-1);
			   for(int k=1;k<=h+1;k++)
				  {
				  	  a[k][j-h]-=a[k][j-h+1];
		    	  } 
		    	  f[j-h][1]=0;
		   }
	   }
}

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
       for(int j=1;j<=m;j++)
         {
		  scanf("%d",&a[i][j]);
		  if(maxn<a[i][j])
		  maxn=a[i][j];
         } 
         hang=n-1;
         lie=m-1;
  
    zz(hang,lie);
     fclose(stdin);
	   fclose(stdout);
    return 0;
}

