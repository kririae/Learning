#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
long long m,n,mod,ans;
int main()
{
	freopen("bmpm.in","r",stdin);
	freopen("bmpm.out","w",stdout);
	scanf("%ld%ld",&m,&n);
	mod=998244353;
	ans=(m*n-1)%mod;
	printf("%ld",ans);

		fclose(stdin);
	   fclose(stdout);
	return 0;	
}
