#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
long long m,n,c[2000000],f[2000000],tot,s,sum;

long long zdgy(int a,int b)
{
	long long r=a%b;
	while(r!=0)
	{
		a=b;
		b=r;
		r=a%b;
	}
	return b;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	   for(int j=1;j<=m;j++)
	   tot+=zdgy(i,j);
	   cout<<tot;
	   fclose(stdin);
	   fclose(stdout);
	   return 0;
}
