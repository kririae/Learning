#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string.h>
using namespace std;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cout<<100;
}


