#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string.h>
using namespace std;
long long m,n,ans;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	m%=998244353;
	n%=998244353;
	ans=(m*n-1)%998244353;
	cout<<ans<<endl;
	return 0;	
}

