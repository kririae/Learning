#include <iostream>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <string.h>
using namespace std;
const int M=998244353;
long long ans;
int m,n;
int gcd(int m,int n)
{
	return (n==0)?m : gcd(n,m%n);
}
int ps(int a)
{
	int signal=1;
	if(a==2) return 1;
	for(int i=2;i<sqrt(a)+1&&signal==1;i++)
		if(a%i==0)
			signal=0;
	if(signal==1)
		return 1;
	else
		return 0;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int exc,t;
	cin>>m>>n;
	if(m>n)
	{
		exc=m;m=n;n=exc;
	}
	ans=m+n-1;
	for(int i=2;i<=m;i++)
	{
		if(ps(i))
		{
			t=n/i;
			ans=(ans+t*i+n-t-1)%M;
		}
		else
		{
			for(int j=2;j<=n;j++)
			{
				ans=(ans+gcd(i,j))%M;
			}
		}
    }
		cout<<ans;
	return 0;
}


