#include<iostream>
#include<cstdio>
using namespace std;
int n,m;
int main()
{
	freopen("bpmp.in ","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	printf("%lld\n",(long long)n*m-1);
	return 0;
}
