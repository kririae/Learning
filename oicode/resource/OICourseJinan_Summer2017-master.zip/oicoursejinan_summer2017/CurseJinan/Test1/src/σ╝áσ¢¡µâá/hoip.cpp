#include<iostream>
#include<cstdio>
using namespace std;
#define mod 998244353
int n,m,ans,flag,minn;
int gcd(int n,int m)
{
	if(n%m==0)return m;
	else return gcd(m,n%m);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n>=m){
		flag=1;
		minn=m;
	}
	else
	minn=n;
	for(int i=2;i<=minn;i++)
	for(int j=1;j<=i-1;j++)
	ans=(ans%mod+gcd(i,j))%mod;
	ans=(ans%mod+ans%mod)%mod;
	ans=(ans+(1+minn)*(minn/2)%mod)%mod;
	if(minn&1){
		ans=(ans+(minn+1)/2)%mod;
	}
	if(flag){
		for(int i=m+1;i<=n;i++)
		for(int j=1;j<=m;j++)
		ans=(ans+gcd(i,j))%mod;
	}
	else{
		for(int i=n+1;i<=m;i++)
		for(int j=1;j<=n;j++)
		ans=(ans+gcd(i,j))%mod;
	}
	printf("%d\n",ans);
	return 0;
}
