#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,ans,maxx=-2147483647,js;
int scor[25][510],dp[25][510];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
	 scanf("%d",&scor[i][j]);	
	 if(scor[i][j]>0)ans+=scor[i][j],js++;
	 maxx=max(scor[i][j],maxx);
	}
	if(!js)cout<<maxx<<endl;
	else
	cout<<ans<<endl;
	return 0;
}
