#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
long long n,m,i,j;
long long ans;
int MOD=998244353;
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			ans+=gcd(i,j);
			ans%=MOD;
		}
	}
	cout<<ans<<endl;
	return 0;
}
