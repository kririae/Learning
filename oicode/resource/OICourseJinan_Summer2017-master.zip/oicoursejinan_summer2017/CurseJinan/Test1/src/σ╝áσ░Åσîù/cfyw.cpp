#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int n,m,ans=0;
int a[510][510];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{
				cin>>a[i][j];
				if(a[i][j]>=0)
				ans+=a[i][j];
			}
	cout<<ans<<endl;
	return 0;
}
