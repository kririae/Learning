#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
long long n,m,ans;
long long MOD=998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	ans=n*m-1;
	ans%=MOD;
	cout<<ans<<endl;
	return 0;
}
