#include <cstdio>
#include <iostream>

int n, m;
long long ans;

inline int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
	for(; isdigit(ch); ch = getchar()) x = (x << 1) + (x << 3) + ch - '0';
	return x * f;
}

inline long long gcd(int x, int y)
{
	return !y ? x : gcd(y, x % y);
}

int main()
{
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	int i, j;
	n = read();
	m = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= m; j++)
			ans = (ans + gcd(i, j)) % 998244353;
	printf("%lld\n", ans);
	return 0;
}
