#include <cstdio>

long long n, m;

int main()
{
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	scanf("%lld %lld", &n, &m);
	printf("%lld\n", (n * m - 1) % 998244353);
	return 0;
}
