#include <cstdio>
#include <iostream>
#define max(x, y) ((x) > (y) ? (x) : (y))

int ans;
int a[41][1001];

inline int read()
{
	int x = 0, f = 1;
	char ch = getchar();
	for(; !isdigit(ch); ch = getchar()) if(ch == '-') f = -1;
	for(; isdigit(ch); ch = getchar()) x = (x << 1) + (x << 3) + ch - '0';
	return x * f;
}

inline void dfs(int x, int y, int n, int m)
{
	int i, j, k, sum = 0;
	for(i = x; i < x + n; i++)
		for(j = y; j < y + m; j++)
			if(a[i][j] > 0)
				sum += a[i][j];
	if(sum <= ans) return;
	if(n == 1 && m == 1) return;
	for(i = 1; i < n; i++)
		if(i > n / 2)
		{
			for(j = x; j < x + i; j++)
				for(k = y; k < y + m; k++)
					a[j][k] += a[2 * i - j + 2 * x - 1][k], ans = max(ans, a[j][k]);
			dfs(x, y, i, m);
			for(j = x; j < x + i; j++)
				for(k = y; k < y + m; k++)
					a[j][k] -= a[2 * i - j + 2 * x - 1][k];
		}
		else
		{
			for(j = x; j < x + i; j++)
				for(k = y; k < y + m; k++)
					a[2 * i - j + 2 * x - 1][k] += a[j][k], ans = max(ans, a[2 * i - j + 2 * x - 1][k]);
			dfs(x + i, y, n - i, m);
			for(j = x; j < x + i; j++)
				for(k = y; k < y + m; k++)
					a[2 * i - j + 2 * x - 1][k] -= a[j][k];
		}
	for(i = 1; i < m; i++)
		if(i > m / 2)
		{
			for(j = x; j < x + n; j++)
				for(k = y; k < y + i; k++)
					a[j][k] += a[j][2 * i - k + 2 * y - 1], ans = max(ans, a[j][k]);
			dfs(x, y, n, i);
			for(j = x; j < x + n; j++)
				for(k = y; k < y + i; k++)
					a[j][k] -= a[j][2 * i - k + 2 * y - 1];
		}
		else
		{
			for(j = x; j < x + n; j++)
				for(k = y; k < y + i; k++)
					a[j][2 * i - k + 2 * y - 1] += a[j][k], ans = max(ans, a[j][2 * i - k + 2 * y - 1]);
			dfs(x, y + i, n, m - i);
			for(j = x; j < x + n; j++)
				for(k = y; k < y + i; k++)
					a[j][2 * i - k + 2 * y - 1] -= a[j][k];
		}
}

int main()
{
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	int n, m, i, j;
	n = read();
	m = read();
	for(i = 1; i <= n; i++)
		for(j = 1; j <= m; j++)
			a[i][j] = read(), ans = max(ans, a[i][j]);
	dfs(1, 1, n, m);
	printf("%d\n", ans);
	return 0;
}
