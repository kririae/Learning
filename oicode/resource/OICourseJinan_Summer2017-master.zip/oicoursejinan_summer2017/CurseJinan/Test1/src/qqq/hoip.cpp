#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,dl,ans;
int shu[20102010];

int hhh(int a,int b)
{
	if(a%b ==0) return b;
	a=a % b;
	hhh(b,a); 
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n>m) 
	{int k=m;m=n;n=k;}
	for(int i=1;i<=n;i++)
	{
	
	 for(int j=1;j<=i;j++)
	  	{ if(i>j) shu[j]=hhh(i,j);else shu[j]=hhh(j,i);
		  ans=ans+shu[j]*(m/i);}
		 
	 for(int j=1;j<=(m % i);j++)
	 	ans=ans+shu[j];
		 
   }
   printf("%d",ans);
   return 0;
}
