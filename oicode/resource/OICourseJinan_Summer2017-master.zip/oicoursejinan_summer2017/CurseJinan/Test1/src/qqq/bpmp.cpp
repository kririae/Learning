#include<algorithm>
#include<cstdio>
#include<cstring>
long long m,n,ans;

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if (n!=998244353) n=n %998244353;
	if (m!=998244353) m=m %998244353;
	ans=(n*m-1)%998244353;
	printf("%lld",ans);
	return 0;

}
