#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m;
int a[21][21];
int b[21][21];
int maxx;
int ans=-1e9;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++) { scanf("%d",&a[i][j]); if(a[i][j]>=0)maxx+=a[i][j];}
	printf("%d",maxx);
	return 0;
}

