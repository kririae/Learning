#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m;
int ans=0;
int gcd[1001][1001];
int g(int x,int y)
{int t;
int a=x,b=y;
	while(y>0)
	{
		t=x%y;
		x=y;
		y=t;
	}
	gcd[a][b]=gcd[b][a]=x;
	return x ;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(!gcd[i][j])ans=(ans+g(i,j))%998244353;
		else ans=(ans+gcd[i][j])%998244353;
	}
	printf("%d",ans%998244353);
	return 0;
}

