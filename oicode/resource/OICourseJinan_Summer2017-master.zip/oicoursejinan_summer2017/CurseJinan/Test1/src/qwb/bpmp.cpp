#include<iostream>
//998244353
#include<cstdio>
#include<ctime>
#include<algorithm>
#include<cstring>
using namespace std;
long long n,m;
long long kscf(long long a,long long b,long long mod)
{
	long long ans=0;
	while(b>0)
	{
		if(b&1)ans=((ans%mod)+(a%mod))%mod;
		b/=2;
		a=2*(a%mod)%mod;
	}
	return ans%mod;
}
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	//cout<<n*m-1;
	long long ans=kscf(n,m,998244353)-1;
	if(ans<0)ans+=998244353;
	cout<<ans;
	return 0;
}

