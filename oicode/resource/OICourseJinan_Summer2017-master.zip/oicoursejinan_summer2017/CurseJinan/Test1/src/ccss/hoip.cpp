#include<iostream>
#include<cstdio>
#define maxn 20001
using namespace std;
int factery[maxn][maxn],m,n;
long long sum=0,ans;
int gcd(int x,int y)
{
	if(!y)
	return x;
	else return gcd(y , x%y);
}

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=1000; i++)
		for(int j=i; j<=1000; j++)
			factery[j][i]=factery[i][j] = gcd(i,j);
//	for(int i=1; i<=18; i++)
//	{
//		for(int j=1; j<=18; j++)
//			cout<<factery[i][j]<<" ";
//			cout<<endl;
//	}
		
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++){
			sum+=factery[i][j];
		}
	printf("%lld",sum);
}
