#include<iostream>
#include<cstdio>
using namespace std;
int n,m,num1[10],num2[10],num[20];
int p1=0,p2=0,moder[]={3,5,3,4,4,2,8,9,9},b[]={1};
int k=1,p;
bool cmp(int num[],int moder[])
{
	if(p > 9)return 1;
	if(p < 9)return 0;
	for(int i = p;i >= 1;i --)
		if(moder[i] < num[i])return 0;
	return 1;
}
int subs(int num1[],int a[])
{
	for(int i = 1;i <= p;i ++)
	{
		num[i] = num[i] - a[i];
		if(num[i]<0)num[i+1]--;
	}		
}

void mult(int a[], int b[]) {  
	p=p1+p2; 
    int sum;  
    for(int i=1; i<=p2; i++) {  
        for(int j=1,k=i+j-1; j<=p1; j++,k++) {  
            sum = a[j]*b[i] + num[k];  
            num[k] = sum%10;  
            num[k+1] += sum/10;  
        }  
    }  
}  

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	while(n != 0){
		num1[ ++p1] = n%10;
		n /= 10;
	}
	
	while(m != 0){
		num2[ ++ p2] = m%10;
		m /= 10;
	}
	mult(num1,num2);
	
	if(cmp(num,moder))
		subs(num,moder);
	subs(num,b);
	while(num[p] == 0)p --;
	for(int i=p; i>=1; i--){
		printf("%d",num[i]);
	}
	return 0;
}
