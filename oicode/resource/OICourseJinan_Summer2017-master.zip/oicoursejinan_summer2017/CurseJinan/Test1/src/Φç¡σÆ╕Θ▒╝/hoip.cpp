#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<ctime>
#include<cctype>
#include<stack>
#include<queue>
#include<vector>
#define N 100010
#define M 988244353
using namespace std;

int n,m;
int notprime[100000];

void make()
{
	notprime[1]=true;
	for(int i=2;i<=99997;i++)
		if(!notprime[i])
			for(int j=2;i*j<=99997;j++)
				if(!notprime[i*j])
					notprime[i]=true;
}

bool pd(int num)
{
	if(num%2==0)
		return true;
	return false;	
}

int gcd(int x,int y)
{
	if(x<y)
	{
		int t;
		t=x;x=y;y=t;
	}
	if(y==0)
		return x;
	else if(pd(x)&&pd(y))
		return 2*gcd(x/2,y/2);
	else if(pd(x)&&!pd(y))
		return gcd(x/2,y);
	else if(!pd(x)&&pd(y))
		return gcd(x,y/2);
	else if(!pd(x)&&!pd(y))
		return gcd(x-y,y);				
} 

int main()
{	
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	
	make();
	
	cin>>n>>m;
	/*if(n<=1000&&m<=1000)
	{*/
		long long sum=n+m-1;
		for(int i=2;i<=n;i++)
		{
			bool shit=false;
			for(int j=2;j<=m;j++)
			{
				if(i>j&&!notprime[i])
				{
					shit=true;
					break;
				}
				if(j>i&&!notprime[j])
				{
					sum++;
					break;
				}
				sum=sum+gcd(i,j);
				if(sum>M)
					sum-=M;
			}
			if(shit)
				sum=sum+m-1;
		}
		cout<<sum%M;	
	/*}*/
	
	return 0;
} 






