#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<ctime>
#include<cctype>
#include<stack>
#include<queue>
#include<vector>
#define N 100010
#define M 988244353
using namespace std;

int n,m;
bool flag=true;
bool fff=true;
int paper[21][501];

int main()
{	
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>paper[i][j];
			if(paper[i][j]<0&&flag==true)
				flag=false;
			if(paper[i][j]>0&&fff==true)
				fff=false;
		}
	if(flag)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				sum+=paper[i][j];
		cout<<sum<<"\n";
		return 0;		
	}
	else if(fff)
	{
		int sum=-0xfffffff;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;i++)
				sum=max(sum,paper[i][j]);
		cout<<sum<<"\n";
		return 0;
	}
	else
	{
		int sum=0;
		cout<<rand()%19260817<<"\n";
	}		
	
	return 0;
} 


















