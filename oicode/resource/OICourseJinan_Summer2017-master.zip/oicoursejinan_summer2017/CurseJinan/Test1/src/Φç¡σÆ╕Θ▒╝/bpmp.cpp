#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<ctime>
#include<cctype>
#include<stack>
#include<queue>
#include<vector>
#define N 400000010
#define M 988244353
using namespace std;

long long n,m;

int main()
{	
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	
	cin>>n>>m;
	cout<<(n*m-1)%M;
	
	return 0;
} 












