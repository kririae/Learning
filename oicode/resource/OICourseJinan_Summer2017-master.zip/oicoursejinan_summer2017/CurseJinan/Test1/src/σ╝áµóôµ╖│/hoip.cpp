#include<bits/stdc++.h>
using namespace std;
int gcd(int x,int y)
{
	if(x<y) swap(x,y);

	if(x%y==0) return y;
	else 
	for(int k=y;k>=1;k--)
	if(x%k==0&&y%k==0) return k;
}
int ans=0;
int main(){
	int m,n;
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{if(i==1||j==1) ans+=1;
		else 
		ans+=gcd(i,j);
		}
	
		cout<<ans%998244353;
		fclose(stdin);
		fclose(stdout);
		return 0;
	
}
