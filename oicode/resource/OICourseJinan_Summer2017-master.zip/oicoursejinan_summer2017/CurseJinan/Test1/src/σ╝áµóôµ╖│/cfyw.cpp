#include<bits/stdc++.h>
using namespace std;
int m,n,a[25][505],b[505],b1[505];
int maxx=-1999999;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{cin>>a[i][j];
			 maxx=max(maxx,a[i][j]);
			}
	
	for(int j=1;j<=m;j++)
		for(int i=1;i<=n;i++)
	{b[j]+=a[i][j]; 
		}	
		
	
	for(int i=1;i<=m-1;i++)
		maxx=max(b[i],b[i]+b[i+1]);	
		
	cout<<maxx;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
