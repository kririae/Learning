#include<bits/stdc++.h>
using namespace std;
long long n,m;
long long ans=0;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	n=n%998244353;
	m=m%998244353;
	
	ans=m*n-1;

	cout<<ans%998244353;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
	
	
}
