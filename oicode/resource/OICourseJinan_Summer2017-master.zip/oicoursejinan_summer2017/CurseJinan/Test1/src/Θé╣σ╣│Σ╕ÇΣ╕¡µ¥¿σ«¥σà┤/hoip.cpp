#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;
int n,m,p;
int ans;
int c=998244353;
int measure(int a,int b)  
{         
    while(a != b)  
    {  
        if(a>b)  
        {  
            a = a - b;  
        }  
        else   
        {  
            b = b - a;  
        }  
    }  
    return a;  
}  

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>m>>n;

	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			ans+=measure(i,j);
		}
	ans%=c;
	cout<<ans;
	return 0;
}
