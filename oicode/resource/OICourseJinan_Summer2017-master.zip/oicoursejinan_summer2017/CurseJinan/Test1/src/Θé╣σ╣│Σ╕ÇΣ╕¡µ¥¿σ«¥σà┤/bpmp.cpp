#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;
long long n,m;
int a=998244353;
int ans;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	ans=(n*m-1)%a;
	cout<<ans;
	return 0;
}


