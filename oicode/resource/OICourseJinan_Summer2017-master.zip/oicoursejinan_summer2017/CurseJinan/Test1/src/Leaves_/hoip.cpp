#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<queue>
#include<stack>
#define ll long long
using namespace std;

const ll INF=998244353 ;
ll ans=0;
ll n,m;
ll gcd(ll a,ll b)
{
	if(a==1||b==1)
	{
		return 1;
	}
	else 
	{
		while(a!=0)
		{
			ll c;
			ll tmp=a;
			a%=b;
			if(a==tmp)
			{
				c=a;a=b;b=c;
			}
		}
		return b;
	}
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(ll i=1;i<=n;i++)
		for(ll j=1;j<=m;j++)
		{
			ans%=INF;
			ans+=gcd(i,j);
			ans%=INF;
		}
	printf("%lld",ans);
	return 0;
}

