#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<queue>
#include<stack>

using namespace std;

const int N=10004;
int n,m,sum;
int a[N],ans=0;

void water()//everything is water
{
	for(int i=1;i<=sum;i++)
	{
		if(a[i]>=0) ans+=a[i];
	}
}

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[n]);
		}
	sum=n*m;
	water();
	printf("%d",ans);
	return 0;
}

