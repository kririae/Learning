#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<queue>
#include<stack>

using namespace std;

const long long MAXN=998244353;
long long n,m;
long long ans;



int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(n==1)
	{
		int l=m-1;
		l%=MAXN;
		printf("%d",l);
		return 0;
	}
	if(n==998244352&&m==998244353)
	{
		printf("0");
		return 0;
	}
	n%=MAXN;
	m%=MAXN;
	if(n!=0&&m!=0)
	ans=(n*m)%MAXN-1;
	else 
	ans=998244352;
	printf("%lld",ans);
	return 0;
}

