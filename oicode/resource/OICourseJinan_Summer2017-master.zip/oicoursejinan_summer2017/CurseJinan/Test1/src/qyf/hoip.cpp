#include<cstdio>
#include<iostream>
#include<ctime>
using namespace std;
long long p=998244353;
long long gcd(long long a,long long b){
	if(b==0)	return a;
	return gcd(b,a%b);
}

long long ans;

int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	long long maxx=n>m?n:m;
	long long minn=n+m-maxx;
	for(register int i=1;i<=minn;++i)
		for(register int j=i+1;j<=minn;++j){
			ans=(ans+gcd(i,j));
			if(ans>p)	ans%=p;
		}
	ans=(ans<<1)%p;
	for(register int i=1;i<=minn;++i)	ans+=i;
	for(register int i=1;i<=minn;++i)
		for(register int j=minn+1;j<=maxx;++j){
			ans=(ans+gcd(i,j));
			if(ans>p)	ans%=p;
		}
	cout<<ans%p;
	return 0;
}
