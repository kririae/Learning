#include<cstdio>
#include<iostream>
using namespace std;

int XJ,YJ,XF,YF;

inline long long read(){
	long long num=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')	f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		num=(num<<1)+(num<<3)+ch-'0';
		ch=getchar();
	}
	return num*f;
}

long long  que[25][505];

long long ans;
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){	
			cin>>que[i][j];
			if(que[i][j]>0)	ans+=que[i][j];
		}
	cout<<ans;
	return 0;
}
