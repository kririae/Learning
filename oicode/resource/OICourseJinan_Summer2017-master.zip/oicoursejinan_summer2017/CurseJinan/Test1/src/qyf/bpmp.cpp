#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long p=998244353;

/*long long ksm(long long n,long long i){
	if(i==1)	return n;
	if(i==0)	return 1;
	long long k=ksm(n,i/2);
	if(i%2)		return ((k%p)*(k%p)*n)%p;
	else 		return (k%p)*(k%p);
}*/

long long ans;

void dfs(int x,int y){
	if(x==1&&y==1)	return;
	ans++;
	ans%=p;
	if(x!=1)	dfs(x>>1,y),dfs(x-(x>>1),y);
	else	dfs(y>>1,x),dfs(y-(y>>1),x);
}

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	cout<<(long long)((n*m)%p)-1;
	return 0;
}
