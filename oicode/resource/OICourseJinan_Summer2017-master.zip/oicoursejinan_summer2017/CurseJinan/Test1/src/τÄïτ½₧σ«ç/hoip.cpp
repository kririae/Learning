#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("hoip.in");
ofstream fout("hoip.out");
int m,n,s;
int gys(int x,int y)
{
	int ss;
	while(x!=0&&y!=0)
	{
		if(x>y)
		{
			x-=y;
		}
		else
		{
			y-=x;
		}
	}
	if(x)
	{
		ss=x;
	}
	else
	{
		ss=y;
	}
	return ss;
}
int main()
{
	fin>>m>>n;
	if(m<n)
	{
		m=m^n;
		n=m^n;
		m=m^n;
	}
	for(int i=1;i<=n;i++)
	{
		s=(s+i)%998244353;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<i;j++)
		{
			s=(s+(gys(i,j)<<1))%998244353;
		}
	}
	for(int i=n+1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			s=(s+gys(i,j))%998244353;
		}
	}
	fout<<s<<endl;
	fin.close();
	fout.close();
	return 0;
}
