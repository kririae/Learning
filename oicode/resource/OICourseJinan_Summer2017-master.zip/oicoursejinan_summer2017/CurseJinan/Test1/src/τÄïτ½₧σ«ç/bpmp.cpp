#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("bpmp.in");
ofstream fout("bpmp.out");
int m,n,s;
int main()
{
	fin>>m>>n;
	s=(m*n-1)%998244353;
	fout<<s<<endl;
	fin.close();
	fout.close();
	return 0;
}
