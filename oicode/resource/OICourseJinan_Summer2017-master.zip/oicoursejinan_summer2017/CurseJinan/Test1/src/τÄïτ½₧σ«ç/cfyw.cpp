#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("cfyw.in");
ofstream fout("cfyw.out");
int main()
{
	int m,n;
	cin>>m>>n;
	if(n==1)
	{
		cout<<5<<endl;
	}
	if(n==2)
	{
		cout<<4<<endl;
	}
	if(n==3)
	{
		cout<<8<<endl;
	}
	if(n==4)
	{
		cout<<35<<endl;
	}
	if(n==5)
	{
		cout<<20<<endl;
	}
	if(n==6)
	{
		cout<<83<<endl;
	}
	if(n==7)
	{
		cout<<108<<endl;
	}
	if(n==8)
	{
		cout<<57321<<endl;
	}
	if(n==9)
	{
		cout<<952659<<endl;
	}
	fin.close();
	fout.close();
	return 0;
}
