#include<iostream>
#include<cstdio>
using namespace std;
int n,m,ans;
int main(){
	scanf("%d%d",&n,&m);
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cout<<n*m-1;
	return 0;
}
