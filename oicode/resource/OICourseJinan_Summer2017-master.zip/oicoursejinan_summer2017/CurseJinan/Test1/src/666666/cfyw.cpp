#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,a[1005][1005],num1=1;
struct node{
	int num;
	int ii;
	int jj;
}b[10005];
int cmp(node x,node y){
	return x.num>=y.num;
}
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	/*for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			b[10005].num=a[i][j];
			num1++;
		}
	sort(b+1,b+num1+1,cmp);
	dfs(1,1)*/
	if(n==1) cout<<m-1;
	if(m==1) cout<<n-1;
	
	return 0;
}
