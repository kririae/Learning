#include<iostream>
#include<cstdio>
#define ll long long
ll cnt[42][1001];
using namespace std;
ll ans,vis=0;
int main(){
	ll n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>cnt[i][j];
			if(cnt[i][j]>=0) vis=1;
		}
	}
	if(vis=0){
		for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			ans=max(cnt[i][j],ans);
		}
	}
}
	else {
		for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(cnt[i][j]>0) ans+=cnt[i][j];
		}
	}
	}
	cout<<ans; 
}
