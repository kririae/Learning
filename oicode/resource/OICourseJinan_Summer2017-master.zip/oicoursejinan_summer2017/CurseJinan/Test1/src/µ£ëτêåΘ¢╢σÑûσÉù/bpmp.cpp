#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
int main(){
	ll n,m,ans;
	cin>>n>>m;
	ans=(m*n-1)%998244353;
	cout<<ans;
	return 0;
}
