#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll gcd(ll a,ll b){
	if(b==0) return a;
	return gcd(b,a%b);
}
int main(){
	ll n,m,ans=0;
	cin>>n>>m; 
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			ans+=(gcd(i,j)%998244353);
		}
	}
	cout<<ans;
}
