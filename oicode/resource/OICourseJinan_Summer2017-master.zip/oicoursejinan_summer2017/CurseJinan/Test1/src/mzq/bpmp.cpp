#include <cstdio>
typedef unsigned long long ll;
const int MOD = 998244353;
int n, m, ans(0);
int main() {
    freopen("bpmp.in", "r", stdin);
    freopen("bpmp.out", "w", stdout);
    scanf("%d%d", &n, &m);
    if(n == 1 && m == 1){
        printf("0\n");
        return 0;
    }
    n %= MOD; m %= MOD;
    ans = (int)(((ll)(n) * (ll)(m) - 1) % MOD);
    ans %= MOD;
    printf("%d\n", ans);
    return 0;
}