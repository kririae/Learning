#include <cstdio>
#include <algorithm>
#define re register
const int MAXN = 1e7 + 1;
const int MOD = 998244353;
int n, m, k, ans;
int atm[MAXN], phi[MAXN], prime[MAXN], prm_num;
inline void caul(int n){
    int l(0);
    phi[1] = 1;
    for (re int i = 2; i <= n; ++i){
        if (!atm[i]) prime[++prm_num] = atm[i] = i, phi[i] = i - 1;
        for (re int j = 1; j <= prm_num && (l = prime[j] * i) < n; ++j){
            atm[l] = prime[j];
            if (atm[i] == prime[j]){
                phi[l] = phi[i] * prime[j]; break;
            }
            else phi[l] = phi[i] * (prime[j] - 1);
        }
    }
}
int main() {
    freopen("hoip.in", "r", stdin);
    freopen("hoip.out", "w", stdout);
    scanf("%d%d", &n, &m);
    k = std::min(n, m);
    caul(k);
    for (re int i = 1; i <= k; ++i){
        ans = (ans + ((phi[i] % MOD) * (n / i) * (m / i)) % MOD) % MOD;
    }
    printf("%d\n", ans);
    return 0;
}