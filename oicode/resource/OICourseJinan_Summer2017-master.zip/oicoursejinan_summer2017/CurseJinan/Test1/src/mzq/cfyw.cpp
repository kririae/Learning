#include <cstdio>
int n, m, a[21][501], k, ans;
int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfye.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n * m; ++i){
        scanf("%d", &k);
        if(k >= 0) ans+=k;
    }
    printf("%d\n", ans);
    return 0;
}
