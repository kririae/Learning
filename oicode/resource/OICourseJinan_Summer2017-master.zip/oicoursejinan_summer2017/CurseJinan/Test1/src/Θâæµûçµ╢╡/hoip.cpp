#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
const int MO=998244353;
unsigned long long ans=0;
int Gcd(int a, int b)
{
    while(b != 0)
    {
        int tmp = b;
        b = a % b;
        a = tmp;
    }
    return a;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	unsigned long long m,n,i,j;
	m=n=i=j=0;
	scanf("%lld%lld",&n,&m);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			ans+=Gcd(i,j);
			ans=ans%MO;
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}
