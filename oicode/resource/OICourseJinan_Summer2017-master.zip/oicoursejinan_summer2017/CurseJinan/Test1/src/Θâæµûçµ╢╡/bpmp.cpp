#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
/*int pow4(int a,int x,int mo)
{
	int base=1;
	int ans=a;
	if(x!=0)
	{
		
	}
}*/
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	int pdn,pdm;
	int m,n,i,j;
	unsigned long long ans;
	m=n=i=j=ans=0;
	scanf("%d%d",&n,&m);
	ans=m*n-1;
	ans=ans%998244353;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
