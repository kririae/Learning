#include <bits/stdc++.h>

using namespace std;

#define maxn 501
int a1[maxn],b1[maxn],ac[2*maxn];
int a2[maxn],b2[maxn],bc[2*maxn];
char s1[maxn],t1[maxn],al2[maxn],bl2[maxn];

inline long long  read(){
	
	int num=0,f=1; char c=getchar();
	
	while(!isdigit(c)){
		
		if(c=='-') f=-1; c=getchar();
	}
	
	while(isdigit(c)){
		
		num=(num<<1)+(num<<3)+(c^48);
		
		c=getchar();
	}
	
	return num*f;
}

//int mutiple(char s,char t){
//
//	int la=strlen(s); int lb=strlen(t);
//	
//	for(int i=0;i<la;i++)  a1[la-i]=s1[i]-'0';
//	
//	for(int i=0;i<lb;i++)  b1[lb-i]=t1[i]-'0';
//	
//	for(int i=1;i<=la;i++)
//	
//	  for(int j=1;j<=lb;j++)
//	  
//	  	bc[i+j-1]+=a1[i]*b1[j];
//	  	
//	int lc=la+lb;
//	int i=1;
//	
//	while(i<=lc)
//	{
//		bc[i+1]+=bc[i]/10;
//		
//		bc[i]%=10;
//		
//		i++;
//	}
//	
//	while(bc[lc]==0) lc--;
//
//}

//int add_num(char al,char bl){
//	
//	int lena=strlen(al); int lenb=strlen(bl);
//	
//	for(int i=0;i<lena;i++) a2[lena-i]=al2[i]-48;   //a^48 or a-'0' or a-48
//	
//	for(int i=0;i<lenb;i++) b2[lenb-i]=bl2[i]-48;
//	
//	int x=0; int lenc=1;
//	
//	while(lenc<=lena or lenc<=lenb){
//		
//		ac[lenc]=a2[lenc]+b2[lenc]+x;
//		
//		x=ac[lenc]/10;
//		
//		ac[lenc]%=10;
//		
//		lenc++;
//	}
//	
//	ac[lenc]=x;
//	
//    if(ac[lenc]==0) lenc--;
//    
//}


int main(){
	
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	int n,m;
	
	n=read(); m=read();
    
    long long ans;
    
    ans=n-1+n*(m-1);
    
    ans%=998244353;
    
    cout<<ans;
    
    return 0;
}
