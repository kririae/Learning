#include <bits/stdc++.h>

using namespace std;

inline int read(){
	
	int num=0,f=1; char c=getchar();
	
	while(!isdigit(c)){
		
		if(c=='-') f=-1; c=getchar();
	}
	
	while(isdigit(c)){
		
		num=(num<<1)+(num<<3)+(c^48);
		
		c=getchar();
	}
	
	return num*f;
} 

long long gcd(int i,int j)
{
	if(!i)return j;
	
	else if(!j) return i;
	
	else return gcd(min(i,j),max(i,j)%min(i,j));
}


int main(){
	
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	
    int n,m,ans=0;
	
	n=read(); m=read();

	for(int i=1;i<=n;i++)
	
	   for(int j=1;j<=m;j++){
	   	
	   	   ans+=gcd(i,j); 
	   	   
	   	   ans%=998244353;
	   }
	       
	cout<<ans;
	
	return 0;
}
