#include <bits/stdc++.h>

using namespace std;

inline int read(){
	
	int num=0,f=1; char c=getchar();
	
	while(!isdigit(c)){
		
		if(c=='-') f=-1; c=getchar();
	}
	
	while(isdigit(c)){
		
		num=(num<<1)+(num<<3)+(c^48);
		
		c=getchar();
	}
	
	return num*f;
}

const int maxn=3000;
int a[maxn][maxn],c[maxn][maxn];
int maxx,n,m;

inline void dfs(int x,int y){
	
	if(a[x][y]==0) return;
	
	for(int i=1;i<=n-x+1;i++){
		
	   if(i%2!=0){
	   	
	   	  c[x][y]+=a[x][i-1];
	   	  
	   	  maxx=max(maxx,c[x][y]);
	   	  
	   	  dfs(y,i);
	   	  
	   	  c[x][y]=c[x][y];
	   } 
	   
	   if(i%2==0){
	   	
	   	  c[x][y]+=a[x][i]; 
	   	  
	   	  maxx=max(maxx,c[x][y]);
			 
			 dfs(x,i);
			 
			c[x][y]=c[x][y];
	   }
	}
	
	for(int i=1;i<=m-y+1;i++){
		
		if(i%2!=0){
	   	
	   	  c[x][y]+=a[x][i-1];
	   	  
	   	  maxx=max(maxx,c[x][y]);
	   	  
	   	  dfs(y,i);
	   	  
	   	  c[x][y]=c[x][y];
	   } 
	   
	   if(i%2==0){
	   	
	   	  c[x][y]+=a[x][i]; 
	   	  
	   	  maxx=max(maxx,c[x][y]);
			 
			 dfs(y,i);
			 
		  c[x][y]=c[x][y]; 
	   }
	}
    
    return;
}

int main(){
	
	//freopen("cfyw.in","r",stdin);
	//freopen("cfyw.out","w",stdout);
	
	n=read(); m=read();
	
	for(int i=1;i<=n;i++)
	
	   for(int j=1;j<=m;j++){
	   	
	   	   a[i][j]=read(); 
	   }
	
	dfs(1,1);
	
	cout<<maxx;
	
	return 0;
}
