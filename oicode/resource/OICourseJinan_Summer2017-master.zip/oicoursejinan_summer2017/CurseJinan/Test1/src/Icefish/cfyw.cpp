#include<iostream>

using namespace std;

int main () {
	int n,m,a;
	cin>>n>>m;
	long long ans=0;
	for(int i=0; i<n; i++)
		for(int j=0; j<m; j++) {
			cin>>a;
			if(a>0) ans+=a;
		}
	cout<<ans;
}
