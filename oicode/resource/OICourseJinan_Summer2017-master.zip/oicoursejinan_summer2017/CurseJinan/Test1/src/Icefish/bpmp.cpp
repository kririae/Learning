#include<iostream>
#include<cstdio>
const int ha=998244353; 
using namespace std;

long long  n,m;

int main () {
	cin>>n>>m;
	n=n%ha;
	m=m%ha;
	cout<<(long long)(n*m)%ha-1;
	
}
