#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

const int MAXSIZE = 505;
const int INF = 2147483647;
int n,m;
int ans1,ans2,ans3,ans4,maxn,final_ans;
int a[MAXSIZE][MAXSIZE];
int sum1[MAXSIZE],sum2[MAXSIZE],sum3[MAXSIZE],sum4[MAXSIZE];
bool all_minus;
bool used[MAXSIZE];

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			scanf("%d",&a[i][j]);
	
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			sum1[i]+=a[i][j];
	for(int i=1; i<=n-1; i++)
		if (sum1[i]+sum1[i-1]<0) i++;
		else ans1+=sum1[i];
	if (sum1[n]>0) ans1+=sum1[n];
	
//	printf("ans1=%d\n",ans1);
	
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			sum2[j]+=a[i][j];
	for(int i=1; i<=m-1; i++)
		if (sum2[i]+sum2[i-1]<0) i++;
		else ans2+=sum2[i];
	if (sum2[m]>0) ans2+=sum2[m];
	
//	printf("ans2=%d\n",ans2);
	
	memset(used,false,sizeof(used));
	for(int i=1; i<=n-1; i++)
		if (sum1[i]+sum1[i-1]<0) i++;
		else used[i]=true;
	if (sum1[n]>0) used[n]=true;
	for(int i=1; i<=n; i++)
	{
		if (!used[i]) continue;
		for(int j=1; j<=m; j++)
			sum3[j]+=a[i][j];
	}
	for(int i=1; i<=m-1; i++)
		if (sum3[i]+sum3[i-1]<0) i++;
		else ans3+=sum3[i];
	if (sum3[m]>0) ans3+=sum3[m];
		
//	printf("ans3=%d\n",ans3);
	
	memset(used,false,sizeof(used));
	for(int i=1; i<=m-1; i++)
		if (sum2[i]+sum2[i-1]<0) i++;
		else used[i]=true;
	if (sum2[m]>0) used[m]=true;
	for(int i=1; i<=m; i++)
	{
		if (!used[i]) continue;
		for(int j=1; j<=n; j++)
			sum4[j]+=a[i][j];
	}
	for(int i=1; i<=n-1; i++)
		if (sum4[i]+sum4[i-1]<0) i++;
		else ans4+=sum4[i];
	if (sum4[n]>0) ans4+=sum4[n];
		
//	printf("ans4=%d\n",ans4);
	
	final_ans=max(max(max(ans1,ans2),ans3),ans4);
	
	/*
	void fold(int num, bool is_col)
	{
		if (is_col)
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++)
					if (used[i][j]&&2*num-j+1<=m&&1<=2*num-j+1)
						used[i][2*num-j+1]=true;
		else
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++)
					if (used[i][j]&&2*num-i+1<=n&&1<=2*num-i+1)
						used[i][2*num-i+1]=true;
	}
	
	void dfs(int dep)
	{
		if (dep>memdep)
		{
			int _ans=0;
			for(int i=1; i<=n; i++)
				for(int j=1; j<=m; j++)
					if (used[i][j])
						_ans+=a[i][j];
			if (_ans>=dep_ans) dep_ans=_ans;
		}
		
	}
	
	int main_dfs()
	{
		maxx=1,maxy=1;
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
			{
				scanf("%d",&a[i][j]);
				if (a[i][j]>=a[maxx][maxy])
					maxx=i,maxy=j;
			}
		used[maxx][maxy]=true;
		for(int memdep=1; memdep<=5; memdep++)
		{
			dfs_ans=0;
			dfs(1);
			final_ans=max(dfs_ans,final_ans);
		}
	}
	*/
	
	maxn=-INF;
	all_minus=true;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
		{
			if (a[i][j]>0) all_minus=false;
			if (a[i][j]>maxn) maxn=a[i][j];
		}
	if (all_minus)
	{
		printf("%d\n",maxn);
		return 0;
	}
	else
		final_ans=max(final_ans,maxn);
	
	maxn=-INF;
	for(int i=1; i<=n; i++)
		for(int j=2; j<=m; j++)
		{
			if (a[i][j]+a[i][j-1]>maxn) maxn=a[i][j]+a[i][j-1];
		}
	final_ans=max(final_ans,maxn);
	
	maxn=-INF;
	for(int i=2; i<=n; i++)
		for(int j=1; j<=m; j++)
		{
			if (a[i][j]+a[i-1][j]>maxn) maxn=a[i][j]+a[i-1][j];
		}
	final_ans=max(final_ans,maxn);
	
	printf("%d\n",final_ans);
}
