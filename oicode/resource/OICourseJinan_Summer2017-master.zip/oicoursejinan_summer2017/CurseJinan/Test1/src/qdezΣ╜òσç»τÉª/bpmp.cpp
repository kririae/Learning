#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

const int MOD = 998244353;
long long n,m;

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	printf("%lld\n",(n*m-1)%MOD);
	return 0;
}
