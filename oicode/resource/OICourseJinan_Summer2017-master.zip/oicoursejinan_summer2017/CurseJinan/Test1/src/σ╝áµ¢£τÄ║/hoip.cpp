#include<iostream>
#include<fstream>
using namespace std;
	ifstream fin("hoip.in");
	ofstream fout("hoip.out");
long long sum=0;
int gys(int x,int y)
{
	int s;
	while(x!=y)
	{
		s=x-y;
		x=(y>=s)?y:s;
		y=(y<=s)?y:s;
		
	}
	return x;
}
int main()
{
	int a,b,m,n;
	fin>>a>>b;
	m=(a>=b)?a:b;
	n=(a<=b)?a:b;
	for (int i=1;i<=n;i++)
	 for (int j=1;j<i;j++)
	 {
	 if (i>j) sum+=gys(i,j);
	 else sum+=gys(j,i);
    }
    sum*=2;
    for (int i=1;i<=n;i++)
    sum+=i;
    	for (int i=n+1;i<=m;i++)
	 for (int j=1;j<n;j++)
	 {
	 if (i>j) sum+=gys(i,j);
	 else sum+=gys(j,i);
    }
	 fout<<(sum%998244353);
	fin.close();
	fout.close();
	return 0;
}
