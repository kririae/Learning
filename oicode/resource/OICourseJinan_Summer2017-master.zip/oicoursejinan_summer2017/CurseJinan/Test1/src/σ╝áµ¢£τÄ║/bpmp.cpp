#include<iostream>
#include<fstream>
using namespace std;
	ifstream fin("bpmp.in");
	ofstream fout("bpmp.out");
int main()
{

	long long m,n,s;
	fin>>m;
	fin>>n;
	s=m*n-1;
	s%=998244353;
	fout<<s;
	fin.close();
	fout.close();
	return 0;
    
}
