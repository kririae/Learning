#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

int maxn(int x,int y)
{
	if(x>=y)
	return x;
	else 
	return y;
}
int gong(int x,int y)
{
	if(x==y)
	return x; 
	int i,max=1;
	for(i=2;i<=maxn(x,y);i++)
	 if(x%i==0&&y%i==0)
	 max=i;
	return max;
}
int main()
{
	freopen("hoip.in","r",stdin); 
    freopen("hoip.out","w",stdout); 
	int i,k,m,n,temp;
	long long sum=0;
	cin>>n>>m;
	for(i=1;i<=m;i++)
	 {
	 	sum+=n;
	 	sum%=998244353;
	 }
	 if(n<m)
	  {
	  	temp=n;
	  	n=m;
	  	m=temp;
	  }
	 
	for(i=1;i<=n;i++)
	 {

	 for(k=1;k<=m;k++)
	  sum+=gong(i,k)-1;
	  sum%=998244353;
     }
	cout<<sum;
	return 0;
	  
}
