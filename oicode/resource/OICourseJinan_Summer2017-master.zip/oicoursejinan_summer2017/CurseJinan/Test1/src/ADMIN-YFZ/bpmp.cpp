#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
freopen("bpmp.in","r",stdin); 
freopen("bpmp.out","w",stdout); 
string s1,s2;
cin>>s1>>s2;
int a[20];
int b[20]; 
int ans[100];
int c[100];
memset(a,0,sizeof(a));
memset(b,0,sizeof(b));
memset(ans,0,sizeof(ans));
a[0]=s1.length();
b[0]=s2.length();
for(int i=1;i<=a[0];i++)
{
a[i]=s1[a[0]-i]-'0';
}
for(int i=1;i<=b[0];i++)
{
b[i]=s2[b[0]-i]-'0';
}
int w,x=0;
w=a[0]+b[0];
for(int i=1;i<=a[0];i++)
{
x=0;
for(int j=1;j<=b[0];j++)
{
ans[i+j-1]=a[i]*b[j]+x+ans[i+j-1];
x=ans[i+j-1]/10;
ans[i+j-1]=ans[i+j-1]%10;
}
ans[i+b[0]]=x;
}
while(ans[w]==0&&w>1)
w--;
int e=1;
for(int i=w;i>=1;i--,e++)
{
c[e]=ans[i];
}
int m=0;
for(int i=1;i<e;i++)
m=(m*10+c[i])%998244353;
if(m==0)
cout<<998244353;
else
cout<<m-1;
return 0;
}
