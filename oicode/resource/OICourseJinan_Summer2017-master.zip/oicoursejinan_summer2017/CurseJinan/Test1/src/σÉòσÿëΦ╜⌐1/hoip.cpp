#include<cstdio>
int m,n,min,max,ans;
int gcd(int x,int y)
{
	if(y%x!=0)
		gcd(y%x,x);
	else
		ans=(ans+x)%998244353;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			max=i>j?i:j;
			min=i<=j?i:j;
				gcd(min,max);
		}
	printf("%d",ans);
	return 0;
}
