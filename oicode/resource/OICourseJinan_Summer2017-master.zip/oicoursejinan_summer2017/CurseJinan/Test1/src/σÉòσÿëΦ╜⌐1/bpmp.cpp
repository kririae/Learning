#include<cstdio>
long long ans;
int m,n;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans=(n*m-1)%998244353;
	printf("%lld",ans);
	return 0;
}
