#include<iostream>
#include<cstdio>
using namespace std;
int funder;
int gcd(int a,int b)
{
	do{
	if(a<b)
	{
		funder=a;
		a=b;
		b=funder;	
	}
		a=a%b;
	}
	while(a!=0);
	return b;
}
const int N=998244353;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int n,m,final;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			final=final+gcd(i,j);
			final=final%N;
		}
	}
		printf("%d",final);
	return 0;
}

