#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;
const int MOD = 998244353;

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int n,m;
	long long ans = 0;
	scanf("%d%d",&m,&n);
		if(n == 1){
		printf("%d",(m-1) % MOD);
		return 0;
	}
	if(m == 1){
		printf("%d",(n-1) % MOD);
		return 0;
	}
	if(n < m)	swap(m,n);
	//ȷ�� n>=m 
	ans += m-1;
	ans %= MOD;
	ans += (long long) (m*(n-1));
	ans %= MOD;
	
	printf("%lld\n",ans);
	return 0;
	//n*m -> 1*1�Ĵ��� 
}
