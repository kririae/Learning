#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
const int MOD = 998244353;

int gcd(int a,int b)
{
	if(a < b)	swap(a,b);
	if(b == 0)	return a;
	gcd(b,a%b);
}
bool bp[10000003];
int prime[10000003];
inline void makep(int n)
{
	int cnt = 0;
	for(int i = 2;i <= n;++ i)
	{
		if(!bp[i])	prime[++ cnt] = i;
		for(int j = 2;j <= cnt;++ j)
		{
			if(i * prime[j] > n)	break;
			bp[i * prime[j]] = true;
			if(i % prime[j] == 0)	break;
		}
	}
}

int main()
{
//	freopen("1.txt","r",stdin);
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int m,n,ans = 0;
	scanf("%d%d",&n,&m);
	int mx = max(m,n);
	if(mx > 1100)
	{
		makep(mx);
		for(int i = 1;i <= n;i ++)
		{
			for(int j = 1;j <= m;j ++)
			{
				if((!bp[j]) || (!bp[i])){
					if(j%i == 0)
						ans += min(i,j),ans %= MOD;
					else
						ans ++,ans %= MOD;
					continue; 
				}
				ans += gcd(i,j);
				ans %= MOD;
			}
		}
	}
	else
	{
		for(int i = 1;i <= n;i ++)
		{
			for(int j = 1;j <= m;j ++)
			{
				ans += gcd(i,j);
				ans %= MOD;
			}
		}
	}
	printf("%d\n",ans%MOD);
	return 0;
}
