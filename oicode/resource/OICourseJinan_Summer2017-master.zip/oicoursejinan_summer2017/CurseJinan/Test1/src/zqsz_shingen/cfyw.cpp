#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;
int num[25][550];
int tmp[10][550];
int tag,tmpx,tmpy;

int main()
{
//	freopen("1.txt","r",stdin);
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int m,n,flag = 0,sum = 0;
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;i ++)
		for(int j = 1;j <= m;j ++)
		{
			scanf("%d",&num[i][j]);
			if(num[i][j] < 0)
				num[i][j] = 0,flag ++;
			else
				sum += num[i][j]; 
		}
	if(!flag)
	{
		printf("%d\n",sum);
		return 0;
	}
	for(int i = 1;i <= n;i ++)
	{
		for(int j = 1;j <= m;j ++)
		{
			if(num[i][j] > 0)
				tmp[1][i] = num[i][j] + tag,tag += num[i][j];
		}
		tag = 0;
	}
	for(int j = 1;j <= m;j ++){
		for(int i = 1;i <= n;i ++)
		{
			if(num[i][j] > 0)
				tmp[2][j] = num[i][j] + tag,tag += num[i][j];
		}
		tag = 0;
	}
	for(int i = 1;i <= n;i ++)
		tmpx = max(tmpx,tmp[1][i]);
	for(int j = 1;j <= m;j ++)
		tmpy = max(tmpy,tmp[2][j]);
	int ans = max(tmpx,tmpy);
	printf("%d\n",ans);
	return 0;
}
