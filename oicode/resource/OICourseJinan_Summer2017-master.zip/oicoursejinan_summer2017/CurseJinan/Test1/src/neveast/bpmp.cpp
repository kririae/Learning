#include<cstdio>
using namespace std;
typedef long long LL;
LL n,m,MOD=998244353;
void read(LL &x){
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

void writ(LL &x){
	LL X=x,NUM=0;
	char ch[25];
	ch[NUM++]=(X%10)+'0';
	X/=10;
	while(X){
		ch[NUM]=(X%10)+'0';
		NUM++;
		X/=10;
	}
	while(NUM)putchar(ch[--NUM]);
}

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	read(n);read(m);
	n=((n)*(m)-1)%MOD;
	writ(n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
