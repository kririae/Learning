#include<cstdio>
#include<algorithm>
#include<cmath>
#include<time.h>
using namespace std;

int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	srand(time(NULL));
	printf("%d",rand());
	return 0;
}
