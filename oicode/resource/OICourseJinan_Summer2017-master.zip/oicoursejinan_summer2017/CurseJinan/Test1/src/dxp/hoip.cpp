#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
	 long long n,m,ji,i,j;
void gcd(int x,int y)
     {
     	if(x%y==0) 
     	{
     		ji+=y;
     		return;
		 }
     	else gcd(y,x%y);
	 }

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	ji=0;
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	gcd(i,j);
	printf("%lld",ji%998244353);
	return 0;
}
