#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
int m,n;
long long p;
int g(int x,int y)
{
	int k,s;
	k=max(x,y);
	s=min(x,y);
    while(s!=0)
    {
    	int r;
    	r=k%s;
    	k=s;
    	s=r;
	}
	return k;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			p+=g(i,j);
			p=p%998244353;
		}
	}
	cout<<p<<endl;
	return 0;
}
