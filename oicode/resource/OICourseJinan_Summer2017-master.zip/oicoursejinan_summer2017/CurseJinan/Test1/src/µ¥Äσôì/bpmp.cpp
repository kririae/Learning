#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<stack>
using namespace std;
int c2[1]={2},lc2=2;
int n[100000],m[1000000];
int ji[19000000],t[10]={0,3,5,3,4,4,2,8,9,9},lt=10;
int ans[10000000],zh[10000000],lans=0,lz;
string s;
int put(int o[])
{
	cin>>s;
	int l=s.length();
	for(int i=1;i<=l;i++)
	{
		o[i]=s[l-i]-'0';
	}
	return l;
}
int chengfa(int a[],int la,int b[],int lb,int c[],int lc)
{
	lc=la+lb;
	for(int i=1;i<=la;i++)
	for(int j=1;j<=lb;j++)
	{
		c[i+j-1]+=a[i]*b[j];
	}
	for(int i=1;i<=lc-1;i++)
	{
		if(c[i]>=10)
		{
			int x=c[i]/10;
			c[i+1]=c[i+1]+x;
			c[i]=c[i]%10;
		}
	}
	int p;
	for(p=lc;p>=1;p--)
	{
		if(c[p])break;
	}
	lc=p;
}
int jianfa(int a[],int la,int b[],int lb,int c[],int lc)
{
	lc=max(la,lb);
	for(int i=1;i<=lc;i++)
	{
		if(a[i]>=b[i])
		{
			c[i]=a[i]-b[i];
		}
		else
		{
			a[i]+=10;a[i+1]-=1;
			c[i]=a[i]-b[i];
		}
		for(int p=lc;p>=1;p--)
		{
			if(c[p])
			{
				lc=p;break;
			}
		}
		int k=lc;
		for(int i=lc;i>=1;i--)
		{
		if(c[k]==0)
		{
			k--;continue;
		}
		if(i==1)
		{
			cout<<c[i]-1;break;
		}
		cout<<c[i];
		}
	}
}
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int ln=put(n);
	int lm=put(m);
	int lji=ln+lm;
	chengfa(n,ln,m,lm,ji,lji);
	if(lji<10)
	{
	int r=lji;
	for(int i=r;i>=1;i--)
	{
		if(ji[r]==0)
		{
			r--;
			continue;
		}
		if(i==1)
		{
			cout<<ji[i]-1;break;
		}
		cout<<ji[i];
	}
	return 0;
	}
	if(lji=10)
	{
		for(int i=lji;i>=1;i--)
		{
			if(ji[i]>t[i])
			{
				jianfa(ji,lji,t,lt,ans,lans);
				return 0;
			}
		}
		for(int i=lji;i>=1;i--)
		{
			cout<<ji[i];
		}
	}
	if(lji>10)
	{
		lz=12;
		chengfa(t,lt,c2,lc2,zh,lz);
		for(int i=lji;i>=1;i--)
		{
			if(ji[i]>zh[i])
			{
				jianfa(ji,lji,zh,lz,ans,lans);
				return 0;
			}
			jianfa(ji,lji,t,lt,ans,lans);
		}
	}
	return 0;
}
