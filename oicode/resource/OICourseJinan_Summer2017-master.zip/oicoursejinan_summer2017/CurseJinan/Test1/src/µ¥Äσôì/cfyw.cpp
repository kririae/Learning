#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;
int an[10001][10001];
int am[10001][10001];
int map[21][21];
int max1=0;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int m,n;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>map[i][j];
		}
	int midx=m/2,midy=n/2;
	for(int i=1;i<=midx;i++)
		for(int j=1;j<=n;j++)
		{
			an[i][j]=map[i][j]+map[2*midx-i+1][j];
		}
	for(int i=1;i<=m;i++)
		for(int j=1;j<=midy;j++)
		{
			am[i][j]=map[i][j]+map[i][2*midy-j+1];
		}
	for(int i=1;i<=midx;i++)
	{
		for(int j=1;j<=m;j++)
		{
			max1=max(an[i][j],max1);
		}
	}
	for(int i=1;i<=midx;i++)
	{
		for(int j=1;j<=midy;j++)
		{
			max1=max(am[i][j],max1);
		}
	}
	cout<<max1;
	return 0;
}
