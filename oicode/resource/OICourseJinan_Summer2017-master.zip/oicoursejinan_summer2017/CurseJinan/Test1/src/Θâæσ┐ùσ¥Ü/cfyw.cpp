#include<cstdio>
int mod=998244353;
int n,m,i,j;
int ans,a[505][505];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]>0) ans=(ans+a[i][j])%mod;
		}
	}
	printf("%d",ans);
	return 0;
} 
