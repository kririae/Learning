#include<cstdio>
int mod=998244353;
int n,m;
long long sum=0;
int gcd(int x,int y)
{
	if(x==0) return y;
	if(x>y) return gcd(x%y,y);
	else return gcd(y%x,x);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			sum+=gcd(i,j);
		}
	}
	printf("%lld",sum%mod);
	return 0;
}
