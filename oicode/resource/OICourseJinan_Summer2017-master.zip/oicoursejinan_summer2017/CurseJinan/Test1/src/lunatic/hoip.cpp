#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cmath>
const int maxn=10000;
using namespace std;
int n,m,a[maxn][maxn],s[maxn][maxn];
int gcd(int x, int y){
    if(y==0) return x;
    if(x<y) return gcd(y,x);
    else return gcd(y,x%y);
}
int main(){
	freopen("hoip.txt","r",stdin);
    freopen("hoip.txt","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=gcd(i,j);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			s[i][j]+=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
		}
	}
	cout<<s[n][m];
	return 0;
}

