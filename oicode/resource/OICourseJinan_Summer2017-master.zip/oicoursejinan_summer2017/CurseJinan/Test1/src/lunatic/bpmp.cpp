#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cmath>
typedef long long LL;
const int mo=998244353;
using namespace std;
int a,b;
int main(){
	freopen("bpmp.txt","r",stdin);
    freopen("bpmp.txt","w",stdout);
	ios::sync_with_stdio(false);
	cin>>a>>b;
	cout<<a*b-1;
	return 0;
}

