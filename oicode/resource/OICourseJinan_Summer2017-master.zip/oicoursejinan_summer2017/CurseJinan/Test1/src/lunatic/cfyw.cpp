#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
int a[21][501],dp[21][501],ans;
int maxn(int a,int b,int c,int d){
	return max(max(max(a,b),c),d);
}
int main()
{
	freopen("cfyw.txt","r",stdin);
    freopen("cfyw.txt","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int k=i+1;k<=n;k+=2){
				for(int l=j+1;l<=m;l+=2){
					dp[i][j]=maxn(dp[i][j],dp[i][j]+a[k][j],dp[i][j]+a[i][l],a[i][j]);
					ans=max(ans,dp[i][j]);
				}
			}
		}
	}
	cout<<ans;
	return 0;
}

