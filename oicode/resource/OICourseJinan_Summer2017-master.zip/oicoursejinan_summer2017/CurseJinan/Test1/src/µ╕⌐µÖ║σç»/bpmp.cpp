#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int MAXN=998244353;
int main()
{
	long long m,n,ans;
	
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	scanf("%lld%lld",&m,&n);
	
	if (m<=0 || n<=0) { printf("0"); return 0;}
	
	m=(m+MAXN)%MAXN;
	n=(n+MAXN)%MAXN;
	ans=(m*n-1+MAXN)%MAXN;
	
	printf("%lld",ans);

	fclose(stdin);
	fclose(stdout);

	return 0;
}

