#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int MAXN=998244353;
inline int gcd(int x,int y)
{
	int i,m;
	
	if(y%x==0)
	{
		return x;
	}
	
	m=x/2;
	for (i=m;i>=1;i--)
	{
		if (x%i==0 && y%i==0)
		{
			break;	
		}	
	}
	
	return i;	
}
int main()
{
	int n,m,x,y,i,j,sum;
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	sum=0;
	x=min(m,n);
	y=x-1;
	
	for (i=1;i<=y;i++)
	{
		for (j=i+1;j<=x;j++)
		{
			sum=(sum+2*gcd(i,j))%MAXN;
		}
	}
	
	for (i=1;i<=x;i++)
	{
		sum=(sum+i)%MAXN;
	}
	
	y=max(m,n);
	
	if (m==n) 
	{
		printf("%d",sum);
		return 0;
	}
	
	for (i=1;i<=x;i++)
	{
		for (j=x+1;j<=y;j++)
		{
			sum=(sum+gcd(x,y))%MAXN;
		}
	}
	
	printf("%d",sum);

	fclose(stdin);
	fclose(stdout);

	return 0;
}

