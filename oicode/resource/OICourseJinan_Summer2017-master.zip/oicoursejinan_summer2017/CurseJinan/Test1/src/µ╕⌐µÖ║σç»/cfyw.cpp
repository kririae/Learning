#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int MAXN=0x3f3f3f3f;
int a[25][505];
int n,m,ans;
int main()
{
	int l,r,u,d,i,j,cnt,s,sum;
	
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);

	scanf("%d%d",&n,&m);
	ans=-1*MAXN;
	cnt=0;
	sum=0;
	for (i=1;i<=n;i++)
	{
		for (j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			if (ans<a[i][j]) ans=a[i][j];
			if (a[i][j]<=0) cnt++;
			sum+=a[i][j];
		}
	}
	
	s=m*n-1;
	if (cnt>=s) {
		printf("%d!",ans);
		return 0;
	}	
	
	if (sum>ans) ans=sum;
	
	for (i=1;i<=n;i++)
	{
		cnt=0;
		for (j=1;j<=m;j++)
		{
			if (a[i][j]>0) cnt+=a[i][j];	
		}
		if (cnt>ans) ans=cnt;
	}
	
	for (j=1;j<=m;j++)
	{
		cnt=0;
		for (i=1;i<=n;i++)
		{
			if (a[i][j]>0) cnt+=a[i][j];
		}
		if (cnt>ans) ans=cnt;
	}
	
	if (m>100)
	{
		printf("%d",ans);
		return 0;
	}
	
	for (l=1;l<m;l++)
	{
		for (r=l+1;r<=m;r++)
		{
			for (u=1;u<n;u++)
			{
				for (d=u+1;d<=n;d++)
				{
					cnt=a[u][l]+a[u][r]+a[d][l]+a[d][r];
					if (cnt>ans) ans=cnt;
				}
			}
		}
	}
	
	for (l=1;l<=m;l++)
	{
		for (u=1;u<n;u++)
		{
			for (d=u+1;d<=n;d++)
			{
				cnt=a[u][l]+a[d][l];
				if (cnt>ans) ans=cnt;
			}
		}
	}
	
	for (l=1;l<m;l++)
	{
		for (r=l+1;r<=m;r++)
		{
			for (u=1;u<=n;u++)
			{	
				cnt=a[u][l]+a[u][r];
				if (cnt>ans) ans=cnt;
			}
		}
	}
	
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);

	return 0;
}

