#include <cstdio>

using namespace std;

int n, m, A[25][505], k, ans;

inline int read();
inline int max(int a, int b){return a > b ? a : b;}
int main()
{
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	n = read(), m = read();
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= m; j ++)
			A[i][j] = read();
	for (int i = 1; i <= m; i ++)
	{
		k = 0;
		for (int j = 1; j <= n; j ++)
			k += A[j][i];
		ans = max(ans, k);
	}
	for (int i = 1; i <= n; i ++)
	{
		k = 0;
		for (int j = 1; j <= m; j ++)
			k += A[i][j];
		ans = max(ans, k);
	}
	printf("%d\n", ans);
	return 0;
}

inline int read()
{
	int x = 0 ,f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9'){if (ch == '-')f = -1;ch = getchar();}
	while (ch >= '0' && ch <= '9'){x = x * 10 + ch - '0';ch = getchar();}
	return x * f;
}
