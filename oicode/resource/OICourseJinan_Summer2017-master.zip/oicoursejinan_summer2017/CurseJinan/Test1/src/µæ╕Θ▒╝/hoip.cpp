#include <cstdio>
#define MOD 998244353
#define MAX 10000005
using namespace std;

int n, m;
long long ans;
bool f[MAX] = {1, 1};
int fn[MAX], fi;

int gcd(int a, int b);
void f_init(int N);

int main()
{
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	scanf("%d%d", &n, &m);
	//f_init(n > m ? m : n);
	for (int i = 1; i <= n; i ++)
	{
		for (int j = 1; j <= i; j ++)
			ans += gcd(i, j);
	}
	printf("%I64d\n", (ans % MOD * 2 - 1) % MOD);
	return 0;
}

void swap(int& a, int& b){int t = a;a = b;b = t;}
int gcd(int a, int b)
{
	if (a < b)	swap(a, b);
	return a % b == 0 ? b : gcd(a, a % b);
}

void f_init(int N)
{
	for (int i = 2; i < N; i ++)
	{
		if (!f[i])
			fn[fi ++] = i;
		for (int j = 0; j < fi && i * fn[j] < N; j ++)
		{
			f[i * fn[j]] = 1;
			if (!(i % f[j]))
				break;
		}
	}
}
