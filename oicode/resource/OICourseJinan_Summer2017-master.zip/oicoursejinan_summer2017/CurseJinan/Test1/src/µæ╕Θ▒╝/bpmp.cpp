#include <cstdio>
#define MOD 998244353

using namespace std;

long long n, m;

int main()
{
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	printf("%I64d\n", ((n % MOD) * (m % MOD) - 1) % MOD);
	return 0;
}
