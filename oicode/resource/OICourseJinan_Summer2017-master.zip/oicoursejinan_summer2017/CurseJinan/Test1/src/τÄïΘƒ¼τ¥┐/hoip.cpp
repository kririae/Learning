#include<cstdio>
#include<iostream>
using namespace std;
int gongyueshu(long long int x,long long int y)
{
	int x1=0,y1=0;
	int sum=0;
	if(x>y)
	{x1=x;y1=y;}
	else
	{x1=y;y1=x;	}
	while(1)
	{
		if(x%y1==0&&y%y1==0)
		return y1;
		
		sum=x1/y1;
		x1=y1;
		y1=sum;
	
	}
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	 long long int n,m;
	 cin>>n>>m;
	 long long int count=0;
	 for(int i=1;i<=n;i++)
	 {
		for(int j=1;j<=m;j++)
		{
		//	cc=gongyueshu(i,j);
			count+=gongyueshu(i,j);
		}
	 }
	 cout<<(count%998224353);
	return 0;
}
