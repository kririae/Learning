#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int n,m;
	cin>>n>>m;
	if(n==1)
	{
		cout<<(m%998244353);
		return 0;
	}
	cout<<((n-1)*(m+1)%998244353);
	return 0;
}
