#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

int main()
{
	freopen("cfyw.in","r",stdin);
	//freopen("cfyw.out","w",stdout);
	int n,m;
	int count=0;
	int a[21][501];
	memset(a,0,sizeof(a));
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			cin>>a[i][j];
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			if(a[i][j]>0)
				count+=a[i][j];
		}
	}
	cout<<count;
	return 0;
}
