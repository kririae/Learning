#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<set>
using namespace std;
int n,m;
int gcd(int x,int y)
{
	if(x<y)
	return gcd(y,x);
	if(x%y==0)
	return  y;
	else return (y,x%y);
}
int main()
{
	scanf("%d%d",&n,&m);
	long long ans=0;
	for(int i=2;i<=n;i++)
	for(int j=2;j<=m;j++)
	{
	ans+=gcd(i,j);
	ans%=998244353;
    }
	ans=(ans+m+n-1)%998244353;
	printf("%lld",ans);
	return 0;
}

