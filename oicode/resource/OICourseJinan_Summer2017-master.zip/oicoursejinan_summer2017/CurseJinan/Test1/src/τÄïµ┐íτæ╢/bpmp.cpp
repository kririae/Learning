#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#include<set>
using namespace std;

long long a,b;

int main()
{
	scanf("%lld%lld",&a,&b);
	long long c=((a%998244353)*(b%998244353))%998244353-1;
	printf("%lld",c);
	return 0;
}
