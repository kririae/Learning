#include<cstdio>
#include<cctype>
#include<algorithm>
const long long maxn=998244353;
using namespace std;
inline int get();
long long gcd(int i,int j);
int n,m;
long long ans;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	n=get();m=get();
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=m;j++)
		{
			if(i==j)ans=(ans+i)%maxn;
			else if(j>n)ans=(ans+gcd(i,j))%maxn;
			else ans=(ans+(gcd(i,j)<<1))%maxn;
		}
	}
	printf("%lld",ans);
	return 0;
}
long long gcd(int i,int j)
{
	if(!i)return j;
	else if(!j) return i;
	else return gcd(min(i,j),max(i,j)%min(i,j));
}
inline int get()
{
 	int t=0,jud=1;char c=getchar();
	while(!isdigit(c))
	{
 	 	if(c=='-')jud=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
	 	t=(t<<3)+(t<<1)+c-'0';
		c=getchar();
	}
	return t*jud;
}

