#include<cstdio>
#include<cctype>
#include<ctime>
#include<cstdlib>
using namespace std;
inline int get();
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	srand(time(0));
	printf("%d",rand());
	return 0;
}
inline int get()
{
 	int t=0,jud=1;char c=getchar();
	while(!isdigit(c))
	{
 	 	if(c=='-')jud=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
	 	t=(t<<3)+(t<<1)+c-'0';
		c=getchar();
	}
	return t*jud;
}

