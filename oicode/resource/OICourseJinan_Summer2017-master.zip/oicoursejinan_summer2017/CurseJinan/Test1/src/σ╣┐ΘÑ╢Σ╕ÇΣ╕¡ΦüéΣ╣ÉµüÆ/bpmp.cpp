#include<cmath>
#include<cstdio>
#include<cctype>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

const int mod=998244353;
string n,m;
int len1,len2,len3,x;
long long tot;
char c[1000],nn[100],mm[100];

int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	len1=n.size(),len2=m.size();
	for(int i=0;i<len1;++i)
		nn[len1-i]=n[i]-48;
	for(int i=0;i<len2;++i)
		mm[len2-i]=m[i]-48;
	for(int i=1;i<=len1;++i)
	{
		x=0;
		for(int j=1;j<=len2;j++)
		{
		  	c[i+j-1]+=nn[i]*mm[j]+x;
		  	x=c[i+j-1]/10;
		  	c[i+j-1]%=10;
		}
		c[i+len2]=x;//������ǰ�����λ��λ 
	}
	len3=len1+len2;
	while(c[len3]==0&&len3>1)
		len3--;
	for(int i=len3;i>10||(i<=10&&i>0);--i)
		tot=(tot<<1)+(tot<<3)+c[i];
	cout<<tot%mod;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
