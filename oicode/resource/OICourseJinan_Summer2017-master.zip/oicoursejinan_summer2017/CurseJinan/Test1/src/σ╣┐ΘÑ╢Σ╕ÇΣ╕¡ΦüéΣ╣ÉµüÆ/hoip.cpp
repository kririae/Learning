#include<cmath>
#include<cstdio>
#include<cctype>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int n,m,maxx;
long long ans;
const int mod=998244353;
bool vis[1000100];

inline int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}

inline void zhishushai()
{
	for(int i=2;i<=sqrt(maxx);++i)
		if(!vis[i])
			for(int j=i*2;j<=maxx;j+=i)
				vis[j]=1;
	return ;
}

inline int read()
{
	int num=0,f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar())
		if(c=='-')
			f=-1;
	for(;isdigit(c);c=getchar())
		num=(num<<1)+(num<<3)+c-'0';
	return num*f;
}

int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	n=read();m=read();
	maxx=max(n,m);
	zhishushai();
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
		{
			if(i%j==0)
			{
				ans+=j;
				continue;
			}
			if(j%i==0)
			{
				ans+=i;
				continue;
			}
			if(!vis[i]||!vis[j])
			{
				++ans;
				continue;
			}
			ans+=gcd(i,j);
			if(ans>mod)
				ans%=mod;
		}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
