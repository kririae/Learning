#include<cmath>
#include<cstdio>
#include<cctype>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int n,m;
int map[510][510],ans;
int dp[510][510][1];

inline int read()
{
	int num=0,f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar())
		if(c=='-')
			f=-1;
	for(;isdigit(c);c=getchar())
		num=(num<<1)+(num<<3)+c-'0';
	return num*f;
}

int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	n=read();m=read();
	for(int i=0;i<n;++i)
		for(int j=0;j<m;++j)
		{
			map[i][j]=read();
			if(map[i][j]>0)
				ans+=map[i][j];
		}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
