#include<iostream>
#include<cstdio>
using namespace std;
long long n,m,s;
void get(long long &x)
{
    char c = getchar(); x = 0;
    while(c < '0' || c > '9') c = getchar();
    while(c <= '9' && c >= '0') x = x*10+c-48, c = getchar();
}
void put(long long x)  
{  
    int num = 0; char c[15];
    while(x) c[++num] = (x%10)+48, x /= 10;
    while(num) putchar(c[num--]);
}
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	get(n);
	get(m);
	s+=(n*m-1)%998244353;
	put(s);
	return 0;
}
