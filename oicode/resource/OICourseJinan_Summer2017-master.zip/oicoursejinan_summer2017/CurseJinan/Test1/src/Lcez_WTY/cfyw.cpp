#include<iostream>
#include<cstdio>
using namespace std;
int n,m,sum,map2[21][500];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>map2[i][j];
		if(map2[i][j]>0)
		sum+=map2[i][j];
	}
	cout<<sum;
	return 0;
}
