#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
long long sum,i,j,n,m;
void get(long long &x)
{
    char c = getchar(); x = 0;
    while(c < '0' || c > '9') c = getchar();
    while(c <= '9' && c >= '0') x = x*10+c-48, c = getchar();
}
void put(long long x)  
{  
    int num = 0; char c[15];
    while(x) c[++num] = (x%10)+48, x /= 10;
    while(num) putchar(c[num--]);
}
int measure(long long x, long long y)  
{     
    long long z = y;  
    while(x%y!=0)  
    {  
        z = x%y;  
        x = y;  
        y = z;    
    }  
    return z;  
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	get(n);
	get(m);
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	sum+=measure(i,j)%998244353;
	put(sum);
	return 0;
}


