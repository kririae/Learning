#include<iostream>
#include<cstdio>
using namespace std;
long long n;
long long m;
long long kobe;
long long ans;
#define N 998244353
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	if(n==1)
	{
		ans=(m-1)%N;
		cout<<ans;
		return 0;
	}
	if(n<=1000&&m<=1000)
	{
		ans=n*m%N-1;
		cout<<ans;
		return 0;
	}
	kobe=1000;
	//cout<<kobe;
	while(m>0)
	{
		if(m-kobe<=0) kobe=m;
		ans=(ans+n*kobe%N)%N;
		ans%=N;
		m-=kobe;
	}
	cout<<ans;
} 
