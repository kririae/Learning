#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<cstring>
using namespace std;
#define sec 1950
int map[21][501];
int Map[21][501];
int t;
int tmp;
int ans=-sec;
int dfs(int n,int m)
{
	if(clock()-t>sec)
	{
		cout<<ans;
		exit(0);
	}
	if(n==1&&m==1)
	{
		ans=max(ans,Map[1][1]);
		return 0;
	}
	tmp=-sec;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		tmp=max(tmp,Map[i][j]);
	}
	ans=max(ans,tmp);
	for(int i=1;i<=n+m-2;i++)
	{
		if(i<=m-1&&m-1>0)
		{
			if(i<=(m-1)/2)
			{
				for(int j=1;j<=i;j++)
				{
					int kobe=j-i+1;
					for(int k=1;k<=n;k++)
					{
						Map[k][i+kobe]+=map[k][j];
					}
				}
				int dxy=max(i,m-i);
				dfs(n,dxy);
				for(int j=1;j<=i;j++)
				{
					int kobe=j-i+1;
					for(int k=1;k<=n;k++)
					{
						Map[k][i+kobe]-=map[k][j];
					}
				}
			}
			else
			{
				for(int j=m;j>i;j--)
				{
					int kobe=j-i-1;
					for(int k=1;k<=n;k++)
					{
						Map[k][i-kobe]+=map[k][j];
					}
				}
				int dxy=max(i,m-i);
				dfs(n,dxy);
				for(int j=m;j>i;j--)
				{
					int kobe=j-i-1;
					for(int k=1;k<=n;k++)
					{
						Map[k][i-kobe]-=map[k][j];
					}
				}
			}
		}
		else
		{
			if(n-1<=0) return 0;
			int I=i-n+1;
			if(I<=0) continue;
			if(I<=(n-1)/2)
			{
				for(int j=1;j<=I;j++)
				{
					int kobe=j-I+1;
					for(int k=1;k<=m;k++)
					{
						Map[I+kobe][k]+=map[j][k];
					}
				}
				int dxy=max(I,n-I);
				dfs(dxy,m);
				for(int j=1;j<=I;j++)
				{
					int kobe=j-I+1;
					for(int k=1;k<=m;k++)
					{
						Map[I+kobe][k]-=map[j][k];
					}
				}
			}
			else
			{
				for(int j=n;j>I;j--)
				{
					int kobe=j-I-1;
					for(int k=1;k<=m;k++)
					{
						Map[I-kobe][k]+=map[j][k];
					}
				}
				int dxy=max(I,n-I);
				dfs(dxy,m);
				for(int j=n;j>I;j--)
				{
					int kobe=j-I-1;
					for(int k=1;k<=m;k++)
					{
						Map[I-kobe][k]-=map[j][k];
					}
				}
			}
		}
	}
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	t=clock();
	int n,m;
	//cout<<t;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>map[i][j];
		Map[i][j]=map[i][j];
	}
	//cout<<clock()-t;
	dfs(n,m);
	cout<<ans;
}
//#include<iostream>
//#include<cstdio>
//#include<ctime>
//#include<cstdlib>
//#include<cstring>
//using namespace std;
//#define sec 1950
//int map[21][501];
//int Map[21][501];
//int t;
//int tmp;
//int ans=-sec;
//int dfs(int n1,int n2,int m1,int m2)
//{
////	if(clock()-t>sec)
////	{
////		cout<<ans;
////		exit(0);
////	}
//	int n=n2-n1;
//	int m=m2-m1;
//	if(n1==n2&&m1==m2)
//	{
//		ans=max(ans,Map[1][1]);
//		return 0;
//	}
//	tmp=-sec;
//	for(int i=1;i<=n;i++)
//	for(int j=1;j<=m;j++)
//	{
//		tmp=max(tmp,Map[i][j]);
//	}
//	ans=max(ans,tmp);
//	for(int i=1;i<=n+m-2;i++)
//	{
//		if(i<=m-1&&m-1>0)
//		{
//			if(i<=(m-1)/2)
//			{
//				for(int j=m1;j<=i+m1-1;j++)
//				{
//					int kobe=j-i+1;
//					for(int k=n1;k<=n2;k++)
//					{
//						Map[k][m1+i+kobe-1]+=map[k][j];
//					}
//				}
//				dfs(n1,n2,i+1,m2);
//				for(int j=m1;j<=i+m1-1;j++)
//				{
//					int kobe=j-i+1;
//					for(int k=n1;k<=n2;k++)
//					{
//						Map[k][m1+i+kobe-1]-=map[k][j];
//					}
//				}
//			}
//			else
//			{
//				for(int j=m2;j>i;j--)
//				{
//					int kobe=j-i-1;
//					for(int k=n1;k<=n2;k++)
//					{
//						Map[k][m1+i-1-kobe]+=map[k][j];
//					}
//				}
//				dfs(n1,n2,m1,i);
//				for(int j=m2;j>i;j--)
//				{
//					int kobe=j-i-1;
//					for(int k=n1;k<=n2;k++)
//					{
//						Map[k][m1+i-1-kobe]-=map[k][j];
//					}
//				}
//			}
//		}
//		else
//		{
//			if(n-1<=0) return 0;
//			int I=i-n+1;
//			if(I<=0) continue;
//			if(I<=(n-1)/2)
//			{
//				for(int j=n1;j<=I;j++)
//				{
//					int kobe=j-I+1;
//					for(int k=m1;k<=m2;k++)
//					{
//						Map[n1+I+kobe-1][k]+=map[j][k];
//					}
//				}
//				dfs(I+1,n2,m1,m2);
//				for(int j=n1;j<=I;j++)
//				{
//					int kobe=j-I+1;
//					for(int k=m1;k<=m2;k++)
//					{
//						Map[n1+I+kobe-1][k]-=map[j][k];
//					}
//				}
//			}
//			else
//			{
//				for(int j=n2;j>I;j--)
//				{
//					int kobe=j-I-1;
//					for(int k=m1;k<=m2;k++)
//					{
//						Map[n1+I-1-kobe][k]+=map[j][k];
//					}
//				}
//				dfs(n1,I,m1,m2);
//				for(int j=n2;j>I;j--)
//				{
//					int kobe=j-I-1;
//					for(int k=m1;k<=m2;k++)
//					{
//						Map[n1+I-1-kobe][k]-=map[j][k];
//					}
//				}
//			}
//		}
//	}
//}
//int main()
//{
//	freopen("cfyw.in","r",stdin);
//	//freopen("cfyw.out","w",stdout);
//	t=clock();
//	int n,m;
//	//cout<<t;
//	cin>>n>>m;
//	for(int i=1;i<=n;i++)
//	for(int j=1;j<=m;j++)
//	{
//		cin>>map[i][j];
//		Map[i][j]=map[i][j];
//	}
//	//cout<<clock()-t;
//	dfs(1,n,1,m);
//	cout<<ans;
//}
