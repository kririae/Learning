#include<iostream>
using namespace std;
const long long mod=998244353;
int main()
{   int n,m;long long ans;
    freopen("bpmp.in","r",stdin);freopen("bpmp.out","w",stdout);
	cin>>n>>m;ans=n*m-1;ans%=mod;cout<<ans<<endl;return 0;}
