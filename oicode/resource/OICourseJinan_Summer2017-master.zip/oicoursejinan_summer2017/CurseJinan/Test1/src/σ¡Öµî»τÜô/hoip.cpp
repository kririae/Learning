#include<cstdio>
using namespace std;
const long long mod=998244353;
long long ans,n,m;
long long gcd(int x,int y)
{   if(x==y)return x;
    long long t;
    if(x<y){ t=x;x=y;y=t;}
    t=x%y;
    while(t!=0)
    { x=y;y=t;t=x%y;}
    return y;}
int main()
{   int i,j;
    freopen("hoip.in","r",stdin);freopen("hoip.out","w",stdout);
	scanf("%lld%lld",&n,&m);ans=n+m-1;
    for(i=2;i<=n;i++)
     for(j=2;j<=m;j++)ans+=gcd(i,j);
    ans%=mod;printf("%lld\n",ans);return 0;}
