#include<iostream>
#include<ctime>
#include<algorithm>
using namespace std;
int main()
{   freopen("cfyw.out","w",stdout);srand(time(0)+20020104);
    int t=rand()%19260817;cout<<t<<endl;return 0;}
