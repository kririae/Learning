#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cstdlib>
#include<queue>
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	unsigned long long n,m;
	scanf("%lld%lld",&n,&m);
	printf("%lld",(n*m-1)%998244353);
	return 0;
}
