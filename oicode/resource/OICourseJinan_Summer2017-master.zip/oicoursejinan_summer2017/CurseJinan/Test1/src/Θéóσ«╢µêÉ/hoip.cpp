#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cstdlib>
#include<queue>
using namespace std;
int k=1,r=1;
int gcd(int x,int y);
int sum=0;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			sum+=gcd(i,j);
		}
	}
	cout<<(sum%998244353);
	return 0;
}
int gcd(int x,int y)
{
	k=1,r=1;
	while(x%2==0&&y%2==0)
	{
		x/=2;y/=2;k*=2;
	}
	while(x%3==0&&y%3==0)
	{
		x/=3;y/=3;k*=3;
	}
	while(x%5==0&&y%5==0)
	{
		x/=5;y/=5;k*=5;
	}
	while(x%7==0&&y%7==0)
	{
		x/=7;y/=7;k*=7;
	}
	if(x>y)
	{
		for ( ;y!=0 ;)
	   {  
   	    r = x%y ;  
   	    x = y ;  
   	    y = r ;  
  	   }  
		return x*k;
	}
	else
	{
		for ( ;x!=0 ;)  
	    {  
        	r = y%x ;  
        	y = x ;  
        	x = r ;  
    	}  
		return y*k;
	}
}
