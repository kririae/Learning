#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
#define P 998244353
#define N 10000010
int n,m,cnt,cnt1,prime[5000000],qaz[5000000][2],xh[N];
long long ans,tmp;
bool b[N];
/*long long iGcd(int x,int y){
	return y?iGcd(y,x%y):x;
}*/
void iPre(int x){
	long long qwe;
	for(int i=2;i<=m;i++){
		if(!b[i])prime[++cnt]=i;
		for(int j=1;j<=cnt;j++){
			qwe=i*prime[j];
			if(qwe>x)break;
			b[qwe]=1;
			if(!(i%prime[j]))break;
		}
	}
}
void iWork(int x){
	//memset(qaz,0,sizeof(qaz));
	cnt1=0;
	for(int i=1;i<=cnt;i++){
		if((x%prime[i]))continue;
		cnt1++;
		qaz[cnt1][0]=prime[i];
		qaz[cnt1][1]=0;
		for(;x && !(x%prime[i]);x/=prime[i])qaz[cnt1][1]++;
		if(!x)break;
	}
}
int main(){
	//freopen("hoip.in","r",stdin);
	//freopen("hoip.out","w",stdout);
	cin>>n>>m;
	
	/*if(n<=3500 && m<=3500){
		for(int j,i=1;i<=n;i++){
			for(j=1;j<=m;j++){
				ans+=iGcd(i,j);
				for(;ans>=P;ans-=P);
			}
			//j=m/i;
			//ans=(ans+j*i+m-j)%P;
		}
		cout<<ans;
		return 0;
	}*/
	
	iPre(n);
	ans=m;
	xh[1]=1;
	for(int hja,l,q,p,k,j,i=2;i<=n;i++){
		iWork(i);
		//hja= ((i-1)>>1);
		//for(j=2;j<=hja;j++)xh[j]=1;
		for(j=2;j<=i;j++)xh[j]=1;
		for(j=1;j<=cnt1;j++){
			q=qaz[j][0];
			p=1;
			for(k=1;k<=qaz[j][1];k++){
				p=p*q;
				//for(l=p;l<=hja;l+=p)xh[l]*=q;
				for(l=p;l<=i;l+=p)xh[l]*=q;
			}
		}
		tmp=0;
		//for(j=1;j<=hja;j++){
		for(j=1;j<=i;j++){
			//tmp+=(xh[j]<<1);
			tmp+=xh[j];
			//xh[n-j]=xh[j];
		}
		//if((i-1)&1)tmp-=xh[hja];
		tmp=((tmp)*(m/i))%P;
		for(j=m%i;j;j--)tmp+=xh[j];
		ans=(ans+tmp)%P;
	}
	cout<<ans;
	return 0;
}
