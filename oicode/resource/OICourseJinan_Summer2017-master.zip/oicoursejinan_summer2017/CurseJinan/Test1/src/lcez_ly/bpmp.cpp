#include<cstdio>
#include<iostream>
using namespace std;
#define P 998244353
long long n,m;
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	n%=P;
	m%=P;
	cout<<(n*m-1)%P;
	return 0;
}
