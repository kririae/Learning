#include<fstream>
#include<iostream>
#define ll long long
#define cin fin
#define cout fout

using namespace std;

ll m,n;
ifstream fin("bpmp.in");
ofstream fout("bpmp.out");

int main()
{
	cin>>m>>n;
//	if(m*n<=100000000)
	cout<<(m*n-1)%99824435<<endl;
	
	fin.close();
	fout.close();
	return 0;
	
}
