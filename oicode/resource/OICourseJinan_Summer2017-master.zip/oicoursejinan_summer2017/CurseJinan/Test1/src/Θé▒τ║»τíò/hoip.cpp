#include<fstream>
#include<iostream>
#define ll long long
#define cin fin
#define cout fout
#define MAX 100000
using namespace std;

ifstream fin("hoip.in");
ofstream fout("hoip.out");

int n,m;
ll ans;
int yue(int a,int b)
{
	int ans;
	while(a!=b)
	{
		ans=a-b;
		a=(b>=ans)?b:ans;
		b=(b<=ans)?b:ans;
	}
	return ans;
}

int main ()
{
	cin>>m>>n;
	if(m<n){m=m^n;n=m^n;m=m^n;}
	for(int i=1;i<=n;i++)
	for(int j=1;j<i;j++)
		{	
			ifm==n+1) ans++;
			else
			ans=(ans+yue(i,j))%998244353;
		}
	ans=(ans*2+((1+n)*n)/2)%998244353;
	if(n<m)
	for(int i=n+1;i<=m;i++)
	for(int j=1;j<=n;j++)
		{
			ans=(ans+yue(i,j))%998244353;
		}
	
	cout<<ans<<endl;
	
	fin.close();
	fout.close();
	return 0;
}
