#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
long long int n,m,sum;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	sum=(m*n-1)%998244353;
	cout<<sum;
	return 0;
}
