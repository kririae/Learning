#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
long long int m,n,sum;
int yue(int x,int y)
{
	int a,b,c;
	if(x>y)
	{a=x;b=y;}
	else
	{a=y;b=x;}
	while(a%b!=0)
	{
		a=a%b;
		if(a<b)
		{c=a;a=b;b=c;}
	}
	return b;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			sum=sum+yue(i,j);
		}
	}
	cout<<sum%998244353;
	return 0;
}
