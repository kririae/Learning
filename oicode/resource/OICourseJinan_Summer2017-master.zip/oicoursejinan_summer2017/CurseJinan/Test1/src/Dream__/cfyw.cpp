/*

	
	code by XHZXHZ__
	2017/7/15
	
*/

#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

long long n,m;
long long x,ans=0;

int main() {
	
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			
			scanf("%lld",&x);
			ans+=x;	
			
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}
