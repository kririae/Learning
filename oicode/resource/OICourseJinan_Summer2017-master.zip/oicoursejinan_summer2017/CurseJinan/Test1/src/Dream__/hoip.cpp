/*

	qingbei Laekov hoip
	code by XHZXHZ__
	2017/7/15
	
*/

#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

long long n,m,ans=0;

int gcd(int,int);

int main() {
	
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(n<=1000 && m<=1000) {
		
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				
				ans+=gcd(max(i,j),min(i,j));
				
			}
		}
		printf("%lld",ans%998244353);
		
	}
	else printf("1");
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}

int gcd(int x,int y) {
	
	if(y==0) return x;
	return gcd(y,x%y);
	
}
