/*

	qingbei laekov bpmp
	code by XHZXHZ__
	2017/7/15
	
*/

#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <windows.h>

using namespace std;

const int N=20;

int flagn,flagm,flagc;
int n,m,p=998244353,p1=998244353,sum;
int sizen=0,sizem=0,sized=0,sizec;
int a[N],b[N],c[N],d[N],ans;

void cheng(int,int);
void jian(int[]);
int re1(int[],int);

int main() {
	
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<0) flagn=1;
	if(m<0) flagm=1;
	n=abs(n);
	m=abs(m);
	while(n>0) {
		
		a[sizen]=n%10;
		n=n/10;
		sizen++;
		
	}
	while(m>0) {
		
		b[sizem]=m%10;
		m=m/10;
		sizem++;
		
	}
	while(p>0) {
		
		d[sized]=p%10;
		p=p/10;
		sized++;
		
	}
	sizec=max(sizem,sizen);
	for(int i=0;i<sizem;i++) {
		
		cheng(b[i],i);
		
	}
	for(int i=0;i<sizec;i++) {
		
		c[i+1]+=c[i]/10;
		c[i]=c[i]%10;
		
	}
	while(c[sizec]>0) {
		
		c[sizec+1]+=c[sizec]/10;
		c[sizec]=c[sizec]%10;
		sizec++;
		
	}
	if(flagn==flagm) {
		
		sum=re1(c,sizec);
		while(sum>=0) {
			
			ans=sum;
			sizec=max(sizec,sized);
			jian(d);
			sum=re1(c,sizec);
			
		}
		
	}
	else {
		
		sum=re1(c,sizec);
		while(sum>0) {
			sizec=max(sizec,sized);
			jian(d);
			sum=re1(c,sizec);
			ans-=sum;
			
		}
		
	}
	if(ans!=0) ans-=1;
	else ans=p1-1;
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}

void cheng(int y,int num) {
	
	int e[N],sizee=sizen;
	memset(e,0,sizeof(e));
	for(int i=0;i<sizen;i++) {
		
		e[i]+=a[i]*y;
		e[i+1]+=e[i]/10;
		e[i]=e[i]%10;
		
	}
	while(e[sizee]>0) {
		
		e[sizee+1]+=e[sizee]/10;
		e[sizee]=e[sizee]%10;
		sizee++;
		
	}
	for(int i=0;i<sizee;i++) {
		
		c[i+num]+=e[i];
		
	}
	
}

void jian(int y[]) {
	
	for(int i=sizec-1;i>=0;i--) {
		
		c[i]=c[i]-y[i];
		if(c[i]<0) {
			
			c[i]+=10;
			c[i+1]-=1;
			
		}
		
	}
	if(c[sizec]<0 || c[sizec-1]<0) {
		
		flagc=1;
		sizec--;
		
	}
	while(c[sizec-1]==0) sizec--;
	
}

int re1(int x[],int sizex) {
	
	if(flagc==1) return -1;
	if(sizex>=10) return 1;
	int sum1=0;
	for(int i=sizex-1;i>=0;i--) {
		
		sum1=sum1*10+x[i];
		
	}
	return sum1;
	
}
