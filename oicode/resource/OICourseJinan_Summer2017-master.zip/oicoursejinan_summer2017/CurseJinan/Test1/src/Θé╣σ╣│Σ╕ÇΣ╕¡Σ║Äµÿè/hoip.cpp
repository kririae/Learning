#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,m,t,ans;
int gcd(int x,int y);
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	if(n>m)
	{
		t=n;
		n=m;
		m=t;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			if(i==j)ans+=i;
			else ans+=2*gcd(i,j);
			ans%=998244353;
		}
	}
	for(int i=n+1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			ans+=gcd(i,j);
			ans%=998244353;
		}
	}
	cout<<ans;
	return 0;
}

int gcd(int x,int y)
{
	while(x!=y)
	{
		if(x>y)x-=y;
		else y-=x;
	}
	return x;
}
