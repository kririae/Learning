#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,m;
long long ans;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
	n%=998244353;
	m%=998244353;
	ans=n*m-1;
	ans%=998244353;
	cout<<ans;
	return 0;
}
