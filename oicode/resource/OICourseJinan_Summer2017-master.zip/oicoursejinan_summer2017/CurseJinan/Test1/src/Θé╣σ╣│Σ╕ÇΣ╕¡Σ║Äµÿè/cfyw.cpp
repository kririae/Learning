#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,m,sum,ans;
int a[501][501];
int h[501],l[501];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			cin>>a[i][j];
			h[j]+=a[i][j];
			l[i]+=a[i][j];
			if(ans<a[i][j])ans=a[i][j];
		}
	}
	for(int i=0;i<m;i++)
		ans=max(ans,h[i]);
	for(int i=0;i<n;i++)
		ans=max(ans,l[i]);
	for(int i=0;i<m;i++)
		for(int j=0;j<i;j++)
		{
			sum=h[i]+h[j];
			ans=max(sum,ans);
		}
	for(int i=0;i<n;i++)
		for(int j=0;j<i;j++)
		{
			sum=l[i]+l[j];
			if(ans<sum)ans=sum;
		}
	for(int i=0;i<n;i++)
		for(int j=0;j<i;j++)
			for(int t=0;t<j;t++)
			{
				sum=l[i]+l[j]+l[t];
				if(ans<sum)ans=sum;
			}
	cout<<ans;
	return 0;
}
