#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	//freopen("bpmp.in","r",stdin);
	//freopen("bpmp.out","w",stdout);
	long long m,n;
	long long tot=0;
	long long ans=1;
	cin>>n>>m;
	if (n>=m)
	{
		long long m1=m,n1=n;
		while((m1!=1)&&(n1!=1))
		{
		    m1/=2;
			tot=(tot+ans)%998244353;
		    ans*=2;
		    
		    tot=(tot+ans)%998244353;
		    ans*=2;
			long long nn=n1;
			n1/=2;
			if (n1*2!=nn)
			   tot=(tot+ans)%998244353;
		}
		if ((m1==1)&&(n1!=1))
		   tot=(tot+(n1-1)*ans)%998244353;
		else if ((n1==1)&&(m1!=1))
		   tot=(tot+(m1-1)*ans)%998244353;
	}
	else
	{
		long long m2=n,n2=m;
		while((m2!=1)&&(n2!=1))
		{
		    m2/=2;
			tot=(tot+ans)%998244353;
		    ans*=2;
		    
		    tot=(tot+ans)%998244353;
			ans*=2;
			long long nnn=n2;
			n2/=2;
			if (n2*2!=nnn)
			   tot=(tot+ans)%998244353;
		}
		if ((m2==1)&&(n2!=1))
		   tot=(tot+(n2-1)*ans)%998244353;
		else if ((n2==1)&&(m2!=1))
		   tot=(tot+(m2-1)*ans)%998244353;
	}
	cout<<tot;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
