#include<iostream>
#include<cstdio>
#include<cmath>
long long z[10001][10001];
long long tot;
using namespace std;
void zhishu(long long x,long long y)
{
	long long z=min(x,y);
	for (long long i=z;i>=1;i--)
	  if ((x%i==0)&&(y%i==0))
	  {
	  	  z[x][y]=i;
	  	  break;
	  }
}
int main()
{
	//freopen("hoip.in","r",stdin);
	//freopen("hoip.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	for (long long i=1;i<=n;i++)
	for (long long j=1;j<=m;j++)
	   zhishu(i,j);
	for (long long i=1;i<=n;i++)
	for (long long j=1;j<=m;j++)
	   tot=(tot+z[i][j])%998244353;
	cout<<tot;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
