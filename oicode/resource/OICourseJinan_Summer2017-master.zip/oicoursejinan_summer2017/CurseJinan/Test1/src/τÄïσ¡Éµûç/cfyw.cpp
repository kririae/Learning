#include<iostream>
#include<cstdio>
using namespace std;
int n,m;
int tot;
int maxx;
int a[100][1000],b[100][1000],z[11000];
int dx[56]={1,2,4,16,1,2,4,16,-1,-2,-4,-16,-1,-2,-4,-16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,4,6,8,10,12,14,16,18,20,-1,-4,-6,-8,-10,-12,-14,-16,-18,-20};
int dy[56]={1,2,4,16,-1,-2,-4,-16,-1,-2,-4,-16,1,2,4,16,1,4,6,8,10,12,14,16,18,20,-1,-4,-6,-8,-10,-12,-14,-16,-18,-20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
void dfs(int x)
{
	if (tot>maxx)
	  maxx=tot;
	int m1,n1;
	n1=x/n+1;
	m1=x%n;
	for (int i=0;i=55;i++)
	{
		if ((m1+dx[i]>0)&&(m1+dx[i]<=m)&&(n1+dy[i]>0)&&(n1+dy[i]<=n))
		{
			int m2=m1;
			int n2=n1;
			m1+=dx[i];
			n1+=dy[i];
			int ans=tot;
			if ((n2!=n1)||(m2!=m1))
			   tot=tot+a[n2][m2+dx[i]]+a[n2+dy[i]][m2];
			dfs((n1-1)*n+m1);
			tot=ans;
			m1=m2;
			n1=n2;
		}
	}
}
int main()
{
	//freopen("cfyw.in","r",stdin);
	//freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
	for (int j=1;j<=m;j++)
	{
		scanf ("%d",&a[i][j]);
		if (a[i][j]>0)
		{
			b[i][j]=1;
			z[(i-1)*n+j]=a[i][j];
		}
	}
	maxx=-1e9;
	for (int i=1;i<=n*m;i++)
	   if (b[i/n+1][i%n]==1)
	   {
	   	   tot=z[i];
	   	   dfs(i);
	   }
	if (maxx==-1e9)
	{
		for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
		   if (a[i][j]>maxx) 
		     maxx=a[i][j];
	}
	cout<<maxx;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
