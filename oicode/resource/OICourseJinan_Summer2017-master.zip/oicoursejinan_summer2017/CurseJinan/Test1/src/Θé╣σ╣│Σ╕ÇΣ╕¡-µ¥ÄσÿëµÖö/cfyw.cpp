#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int g[50][50];
int hm[50];
int lm[50];


int main()
{
	freopen("cfyw.in","r",stdin);
      freopen("cfyw.out","w",stdout);
	int n,m;
	int hs,ls;
	int ans;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		
		{
			cin>>g[i][j];
			if(g[i][j]>0)
			ans+=g[i][j];
		}
	}
	cout<<ans;
	return 0;
	

return 0;
}
