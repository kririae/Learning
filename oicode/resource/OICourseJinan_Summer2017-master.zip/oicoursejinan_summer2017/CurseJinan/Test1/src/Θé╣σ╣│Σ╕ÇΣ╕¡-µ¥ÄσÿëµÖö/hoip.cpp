#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int f[10000][10000];
int gcd(int,int);
int main(int argc,char * argv[])
{

freopen("hoip.in","r",stdin);
      freopen("hoip.out","w",stdout);
    int n,m;
	int ans;
   cin>>n>>m;
   for(int i=1;i<=n;i++)
   {
   		for(int j=1;j<=m;j++)
   		{
   			f[i][j]=gcd(i,j);
   		 ans+=f[i][j];
		   }
   }
cout<<ans;
    return 0;

}

int gcd(int x,int y)

{

    while(x!=y)

    {

        if(x>y) x=x-y;

        else y=y-x;

    }

    return x;

}
