#include<iostream>
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out ","w",stdout);
	long long int m,n,k,s,sum=0; 
	cin>>n>>m;
	n=n%998244353;
	m=m%998244353;
	if(m==0||n==0)
	cout<<998244352;
	else
	cout<<(m*n-1)%998244353;
	return 0;
}
