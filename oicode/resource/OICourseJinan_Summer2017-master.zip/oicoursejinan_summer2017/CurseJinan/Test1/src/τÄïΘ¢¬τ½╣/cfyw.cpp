#include<iostream>
using namespace std;
int MAX=-19260817;
int n,m,a[1000][1000],f[1000][1000],c[1000][1000];
int find(int,int);
int main()
{
	freopen("cfyw.in ","r",stdin);
	freopen("cfyw.out","w",stdout);
	int i,j,q,w;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	cin>>a[i][j];
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	c[i][j]=a[i][j];
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	{
		if(a[i][j])
		{
			f[i][j]=find(i,j);
			for(q=1;q<=n;q++)
			for(w=1;w<=m;w++)
			a[q][w]=c[q][w];
		}
	}
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	{
		MAX=max(MAX,f[i][j]);
	}
	cout<<MAX;
	return 0;
}
int find(int x,int y)
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		if(a[i][y]>0&&i!=x)
		{
			for(j=1;j<=m;j++)
			{
				a[x][j]+=a[i][j];
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		if(a[x][i]>=0&&i!=y)
		a[x][y]+=a[x][i];
	}
	return a[x][y];
}
