#include<iostream>
using namespace std;
int main()
{
	
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	long long n,m,i,j,ans=0,k,a,b;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	{
		a=i;b=j;
		if(a<b)
		swap(a,b);
		while(a%b!=0)
		{
			k=a;
			a=b;
			b=k%b;
		}
		b=b%998244353;
		ans+=b;
		ans=ans%998244353;
	}
	cout<<ans;
	return 0;
}
