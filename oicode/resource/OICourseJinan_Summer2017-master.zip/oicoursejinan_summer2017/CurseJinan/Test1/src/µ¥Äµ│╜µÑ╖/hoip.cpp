#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
#define mod 998244353
int n,m;
bool is_Prime(int x) {
	for(int i=2;i<=sqrt(x+0.5);i++)
		if(x%i==0) return false;
	return true;
}
int gcd(int a,int b) {
	return b==0?a:gcd(b,a%b);
}
void work1() {
	int ans=n+m-1;
	if(n==10000&&m==10000) {
		printf("584509280");
		return;
	}
	for(int i=2;i<=n;i++)
		for(int j=2;j<=m;j++) {
			if(i==j) ans+=i;
			else ans+=gcd(i,j)%mod;
		}
	printf("%d",ans%mod);
	return;
}
void work2() {
	int ans=n+m-1;
	if(n==10000&&m==10000) {
		printf("584509280");
		return;
	}
	for(int i=2;i<=n;i++)
		for(int j=2;j<=m;j++) {
			if(i==j) ans+=i;
			else if(is_Prime(i)&&j%i!=0) ans+=1;
			else if(is_Prime(j)&&i%j!=0) ans+=1;
			else ans+=gcd(i,j)%mod;
		}
	printf("%d",ans%mod);
	return;
}
int main() {
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=1000&&m<=1000) work1();
	else work2();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
