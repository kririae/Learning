#include<cstdio>
#include<algorithm>
using namespace std;
#define maxn 25
#define maxm 510
#define inf 0x7fffffff
int znum,fnum,sum;
int fmax=-inf,zmax=-inf;
int a[maxn][maxm],ans=0;
bool zf[maxn][maxm]={0};
struct Natural {
	int x,y;
	Natural(int x=0,int y=0):
		x(x),y(y) {}
}z[maxn*maxm],f[maxn*maxm];
void dfs(int x,int y,int score,int remain) {
	if(score+zmax*remain<ans) return;
	if(score==sum) {
		ans=sum;
		exit(0);
	}
	
	return;
}
int main() {
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) {
			scanf("%d",&a[i][j]);
			if(a[i][j]>0) {
				z[++znum]=Natural(i,j);
				sum+=a[i][j];
				zf[i][j]=true;
			} else {
				f[++fnum]=Natural(i,j);
				fmax=max(a[i][j],fmax);
			}
		}
	if(fnum==0) printf("%d",sum);
	else if(znum==0) printf("%d",fmax);
	dfs(z[1].x,z[1].y,a[z[1].x][z[1].y],znum-1);
	printf("%d",ans);
	return 0;
}
