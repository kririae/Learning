#include<cstdio>
using namespace std;
typedef long long ll;
const ll mod=998244353;
inline ll input() {
	char c=getchar();
	ll x=0,flag=1;
	for(;c<'0'&&c>'9';c=getchar())
		if(c=='-') flag=-1;
	for(;c>='0'&&c<='9';c=getchar())
		x=(x<<1)+(x<<3)+c-'0';
	return x*flag;
}
int main() {
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	ll n=input(),m=input();
	printf("%lld",((n*m-1)%mod));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
