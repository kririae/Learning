#include <iostream>
using namespace std;
int n,m;
int a[21][501];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	int ans=-2147483647;
	int i,j;
	for (i=1;i<=n;++i)
	    for (j=1;j<=m;++j) 
		{
			cin>>a[i][j];
			if (ans<a[i][j]) ans=a[i][j];
		}
	cout<<ans;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
