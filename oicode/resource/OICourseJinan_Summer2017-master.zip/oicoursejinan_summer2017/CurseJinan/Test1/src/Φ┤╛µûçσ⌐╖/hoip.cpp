#include <iostream>
using namespace std;
int n,m;
long long ans;
int a[10001][10001];
/*void zzxc(int x,int y)
{
	int t=max(x,y);
	y=min(x,y);
	x=t;
	int r;
	while (x%y!=0)
	{
		r=x%y;
		x=y;
		y=r;
	}
	t=1;
	while (x*t<=n&&y*t<=m)
	{
		a[x*t][y*t]=a[y*t][x*t]=y*t;
		t++;
	}
	ans+=y;
}*/
int zzxy(int x,int y)
{
	if (x%y==0) 
	{
	    a[x][y]=a[y][x]=y;
		return y;
	}
	return a[x][y]=a[y][x]=zzxy(y,x%y);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int i,j;
	cin>>n>>m;
	for (i=n;i>=1;--i)
	    for (j=m;j>=1;--j) 
	    {
	    	zzxy(max(i,j),min(i,j));
	    	if (a[i][j]==0) ans+=zzxy(i,j);
		    else ans+=a[i][j];
		}
		    
	cout<<ans%998244353;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
