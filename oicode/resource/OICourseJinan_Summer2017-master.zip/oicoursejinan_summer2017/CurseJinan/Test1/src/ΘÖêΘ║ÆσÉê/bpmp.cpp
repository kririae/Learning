#include<cstdio>
using namespace std;
int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	long long n,m;
	scanf("%lld%lld",&n,&m);
	long long ans=(n*m-1)%998244353;
	printf("%lld",ans);
	return 0;
}
