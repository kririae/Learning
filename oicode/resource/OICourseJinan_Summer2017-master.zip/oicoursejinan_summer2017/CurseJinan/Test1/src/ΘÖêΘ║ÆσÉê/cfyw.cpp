#include<cstdio>
#include<cmath>
using namespace std;
const int N=1010;
int a[N][N]={0};
int ans=-10000000;
int sum=0;
int main(){
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(int j=1;j<=m;j++){
		sum=0;
		for(int i=1;i<=n;i++){
				if(a[i][j]>0){
					sum+=a[i][j];
				}
		}
		for(int k=j+1;k<=m;k+=2){
			int sum1=sum;
			for(int i=1;i<=n;i++){
				if(a[i][k]>0){
					sum1+=a[i][k];
				}
			}
			ans=max(ans,sum1);
		}
	}
	for(int i=1;i<=n;i++){
		sum=0;
		for(int j=1;j<=m;j++){
				if(a[i][j]>0){
					sum+=a[i][j];
				}
		}
		for(int k=i+1;k<=n;k+=2){
			int sum1=sum;
			for(int j=1;j<=m;j++){
				if(a[k][j]>0){
					sum1+=a[k][j];
				}
			}
			ans=max(ans,sum1);
		}
	}
	printf("%d",ans);
	return 0;
}
