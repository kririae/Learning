#include<iostream>
#include<cstdio>
using namespace std;
void swap(int x,int y){
	int tmp=x;x=y;y=tmp;
}
int gcd(int x,int y)
{
	if(x<y){
		swap(x,y);
	}
	return y==0?x:gcd(y,x%y);
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int n,m;
	int ans=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			ans+=gcd(i,j);
		}
	}
	cout<<ans%998244353;
	return 0;
}
