#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std ;
const int Mod = 998244353;

int n,m;

inline int read()
{
	int sum = 0;char ch = getchar();
	for (;!isdigit(ch);ch = getchar());
	for (;isdigit(ch);ch = getchar()) {
		sum = sum * 10 + ch - 48;
	}
	return sum;
}

int main () {
	
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	
	n = read(),m = read();
	printf("%d",(n*m-1)%Mod);
	return 0;
}
