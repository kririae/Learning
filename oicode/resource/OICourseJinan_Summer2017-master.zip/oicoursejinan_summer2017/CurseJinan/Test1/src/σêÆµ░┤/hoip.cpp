#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>

using namespace std ;
const int N = 10000100;
const int Mod = 998244353;

int ans,n,m;

int gcd(int a,int b)
{
	return b == 0 ? a : gcd(b,a%b);
}

int main () {
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);

	scanf("%d%d",&n,&m);
	
	for (int i = 1;i <= n; ++i) {
		for (int j = 1;j <= m; ++j) {
			ans += gcd(i,j);
			if (ans >= Mod) ans -= Mod;
		}
	}
	printf("%d",ans);
	return 0;
}
