#include <iostream>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <algorithm>

using namespace std ;

int n,m;
int path[30][550];

void dfs(int pos)
{
	
}

int main () {
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);

	scanf("%d%d",&n,&m);
	srand((unsigned)time(NULL));
	for (int i = 1;i <= n; ++i) 
		for (int j = 1;j <= m; ++j) 
			scanf("%d",&path[i][j]);
		
	cout << rand();
	
	return 0;
}
