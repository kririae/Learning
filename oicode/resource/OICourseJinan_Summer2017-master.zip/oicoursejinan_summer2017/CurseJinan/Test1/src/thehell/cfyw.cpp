#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#define ll unsigned long long
using namespace std;
int n,m,c[21][501];
ll ans=0;

int main(int argc,char **argv)
{
	//freopen("cfyw.in","r",stdin);
	//freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&c[i][j]);
			if(c[i][j]>0)	ans+=c[i][j];
		}
	}
	printf("%lld\n",ans);
	//fclose(stdin);fclose(stdout);
	return 0;
}

