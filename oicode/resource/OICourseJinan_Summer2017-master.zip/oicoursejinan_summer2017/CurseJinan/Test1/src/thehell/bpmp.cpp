#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#define ll unsigned long long
const int mod=998244353;
using namespace std;
int n,m,tmpm=0,tmpn=0;
ll ans=0;

int main(int argc,char **argv)
{
	//freopen("bpmp.in","r",stdin);
	//freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1)	printf("%d\n",(m-1)%mod);
	else ans=n*m;
	/*{
		for(int i=1;i<=m;i++)
		{
			if(pow(2,i)>=m)	
			{
				tmpm=i;break;
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(pow(2,i)>=n)
			{
				tmpn=i;break;
			}
		}
	}
	ans=tmpm+tmpn;*/
	printf("%d\n",(ans-1)%mod);
	//fclose(stdin);fclose(stdout);
	return 0;
}

