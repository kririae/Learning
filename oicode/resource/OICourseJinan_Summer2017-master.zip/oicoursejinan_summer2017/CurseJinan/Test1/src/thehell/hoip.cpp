#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
const int mod=998244353;
const int maxn=1e9;
using namespace std;
int n,m,ans=0/*tmp[maxn]*/;
int gcd(int x,int y)
{
	if(y==0)	return x;
	return gcd(y,x%y);
}/*
int phi(int n)	 
{
	int m=(int)sqrt(n);
	int sum=n;	
	for(int i=2;i<=m;i++)
		if(n%i==0)
		{
			sum=sum/i*(i-1);
			while(n%i==0) 	n/=i;
		}
	if(n>1) sum=sum/n*(n-1);	
	return sum;
}
int Find(int x)
{
	int cnt=0,tot=0;
	for(int i=1;i<=x/2;++i)
	{
		if(x%i==0)
		{
			tot++;tmp[tot]=i;
		}
	}
	tot++;tmp[tot]=x;
	for(int i=1;i<=tot;i++)
		cnt+=phi(x/tmp[i])*tmp[i];
	return cnt;
}*/
int main(int argc,char **argv)
{
	//freopen("hoip.in","r",stdin);
	//freopen("hoip.out","w",stdout);
	//memset(tmp,0,sizeof(tmp));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		/*ans+=Find(i);
		for(int j=1;j<=tot;j++)
			ans+=phi(i/tmp[j])*tmp[j];*/
		for(int j=1;j<=m;j++)
		{
			if(i==1 || j==1)	
			{
				ans++;continue;
			}
			else if(j-i==1)
			{
				ans++;continue;
			}
			else ans+=gcd(i,j);
		}
	}
	printf("%d\n",ans%mod);
	//fclose(stdin);fclose(stdout);
	return 0;
}

