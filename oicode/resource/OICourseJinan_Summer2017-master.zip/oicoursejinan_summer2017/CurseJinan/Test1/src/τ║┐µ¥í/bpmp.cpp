#include <iostream>
#include <cstdio>
using namespace std;
long long m,n,a[11],b[11],ans[21],temp=0,yyy,ui=1,s;
#define ktt 998244353

int main(){
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin >> m>>n;
	for(int i=1;i<=10;i++){
		a[i]=m%10;
		b[i]=n%10;
		m=m/10;
		n=n/10;
	}
	for(int i=1;i<=10;i++){
		for(int j=1;j<=10;j++){
			ans[i+j-1]=a[j]*b[i]+ans[i+j-1];
			temp=ans[i+j-1]/10;
			ans[i+j]=ans[i+j]+temp;
			ans[i+j-1]=ans[i+j-1]%10;
		}
	}
	ans[1]-=1;
	for(int i=1;i<=9;i++){
		for(int j=2;j<=i;j++){
			ui=ui*10;
		}
		yyy=yyy+ans[i]*ui;
		ui=1;
	}
	yyy=yyy-ktt;
	s=ans[10]+ans[11]*10+ans[12]*100;
	yyy=yyy+s;
	if(yyy>=0){
		yyy=yyy-ktt;
	}
	s=ans[13]+ans[14]*10+ans[15]*100;
	yyy=yyy+s;
	if(yyy>=0){
		yyy=yyy-ktt;
	}
	s=ans[16]+ans[17]*10+ans[18]*100;
	yyy=yyy+s;
	if(yyy<0){
		yyy=yyy+ktt;
	}
	if(yyy>=ktt){
		yyy=yyy-ktt;
	}
	cout<< yyy;
}
