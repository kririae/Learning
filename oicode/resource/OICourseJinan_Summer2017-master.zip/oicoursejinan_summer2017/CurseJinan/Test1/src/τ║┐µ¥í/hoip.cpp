#include <iostream>
#include <cstdio>
using namespace std;
#define ktt 998244353
long long m,n,ovo,ti;
int gcd(int a,int b){
	do{
		if(a<b){
			ti=a;
			a=b;
			b=ti;
		}
		a=a%b;
	}while(a!=0);
	return b;
}
int main(){
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			ovo=ovo+gcd(i,j);
			ovo=ovo%ktt;
		}
	}
	cout <<ovo;
	return 0;
}
