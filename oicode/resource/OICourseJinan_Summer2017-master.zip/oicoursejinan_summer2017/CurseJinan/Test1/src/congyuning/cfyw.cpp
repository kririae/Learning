#include<iostream>
#include<algorithm>
#include<cstring>
const int inf=-1005;
int a[25][505];
using namespace std;
//void dfs()
int main(){
	memset(a,0,sizeof(a));
	bool flag=1;
	int n,m,ans=inf;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		int x;
		cin>>x;
		a[i][j]=x;
		if(x>0) flag=0;
		ans=max(x,ans);
	}
		cout<<ans;
		return 0;
}
