#include<cstdio>
#include<iostream>
const long long mo=998244353;
using namespace std;
int main(){
	long long m,n;
	cin>>n>>m;
	if(n==1){
		cout<<(m-1)%mo;
	}
	else {
		long long ans=(n*m-1)%mo;
		cout<<ans;
	}
	return 0;
}
