#include<iostream>
const int mo=998244353;
using namespace std;
long long gcd(long long a,long long b){
	if(b==0) return a;
	return gcd(b,a%b);
}
int main(){
	long long n,m,ans=0;
	cin>>n>>m;
	for(long long i=1;i<=n;i++)
	for(long long j=1;j<=m;j++){
		if(i==1||j==1)
		{
			ans=(ans+1)%mo;
		}
		else if(i==j){
			ans=(ans+i)%mo;
		}
		else 
		{
			long long cnt=gcd(i,j);
			ans=(ans+cnt)%mo;
		}
	}
	cout<<ans;
	return 0;
}
