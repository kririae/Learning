#include<iostream>
#include<cstdio>
using namespace std;
long long n,m,sum=0;
void exi(int ,int);
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			exi(i,j);
		}
	}
	printf("%lld",sum%998244353);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
void exi(int x,int y)
{
	if(y!=0)
	{
		exi(y,x%y);
	}
	else
	{
		sum+=x;
		return;
	}
}
