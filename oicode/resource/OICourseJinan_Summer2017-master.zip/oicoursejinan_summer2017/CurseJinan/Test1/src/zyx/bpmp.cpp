#include<iostream>
#include<cstdio>
using namespace std;
long long n,m;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
    scanf("%lld%lld",&n,&m);
    printf("%lld",((((m-1)*n)%998244353)+(n-1))%998244353);
    fclose(stdin);
	fclose(stdout);
    return 0;
}
