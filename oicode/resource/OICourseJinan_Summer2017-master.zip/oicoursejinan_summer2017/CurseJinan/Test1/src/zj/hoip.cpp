#include <iostream>
#include <cstdio>
using namespace std;
const long long mod=998244353;
long long n, m, ans;

int gcd(int a, int b) {
	return b==0?a:gcd(b, a%b);
}

int main() {
	freopen("hoip.in", "r", stdin);
	freopen("hoip.out", "w", stdout);
	cin>>n>>m;
	if(n>m) { int t=m; m=n; n=t; }
	for (int i=1; i<=n; i++)
		for (int j=1; j<i; j++) {
			ans+=gcd(i, j);
			if (ans>=mod) ans-=mod;
		}
	ans<<=1;
	if (ans>=mod) ans-=mod;
	for (int i=1; i<=n; i++) ans+=i;
	for (int i=1; i<=n; i++)
		for (int j=n+1; j<=m; j++) {
			ans+=gcd(i, j);
			if (ans>=mod) ans-=mod;
		}
	cout<<ans<<endl;
	fclose(stdin); fclose(stdout);
	return 0;
}
