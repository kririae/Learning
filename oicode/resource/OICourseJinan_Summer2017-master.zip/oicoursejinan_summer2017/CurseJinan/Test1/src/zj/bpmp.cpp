#include <iostream>
#include <cstdio>
using namespace std;
const long long mod=998244353;
long long n, m, ans1, ans2;

int main() {
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	cin>>n>>m;
	if(n==0 || m==0) { cout<<0; return 0; }
	n%=mod; m%=mod;
	ans1=(n*m-1)%mod;
	cout<<ans1;
	fclose(stdin); fclose(stdout);
	return 0;
}
