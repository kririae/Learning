#include <iostream>
#include <cstdio>
using namespace std;
const long long mod=998244353;
int n, m;
int a[21][501];
int b[21][501];
long long n2, m2, ans=-10000;

int min(int x, int y) { return x>y?y:x; }
int max(int x, int y) { return x<y?y:x; }

void zd(int id, bool hl) {
	id++;
	if (hl==0) {
		int bj=min(id, n-id);
		for (int i=1; i<=bj; i++) {
			int i1=bj-i+1, i2=bj+i;
			for (int j=1; j<=m; j++)
				a[i1][j]+=a[i2][j];
		}
	}
	else {
		int bj=min(id, m-id);
		for (int i=1; i<=bj; i++) {
			int i1=bj-i+1, i2=bj+i;
			for (int j=1; j<=m; j++)
				a[j][i1]+=a[j][i2];
		}
	}
}

void doit(long long h, long long l) {
	for (int i=1; i<=n; i++)
		for (int j=1; j<=m; j++)
			a[i][j]=b[i][j];
	for (int i=0; i<n; i++)
		if (h&(1<<i)) {
			zd(i, 0); break;
		}
	for (int i=0; i<m; i++)
		if (l&(1<<i)) {
			zd(i, 1); break;
		}
	for (int i=1; i<=n; i++)
		for (int j=1; j<=m; j++)
			ans=max(ans, a[i][j]);
}

int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	cin>>n>>m;
	for (int i=1; i<=n; i++)
		for (int j=1; j<=m; j++)
			scanf("%d", &b[i][j]);
	n2=1<<(n-1); m2=1<<(m-1);
	for (int i=0; i<n2; i++)
		for (int j=0; j<m2; j++) {
			doit(i, j);
		}
	cout<<ans;
	fclose(stdin); fclose(stdout);
	return 0;
}
