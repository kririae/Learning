#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;
char n[100000001],m[100000001];
char t[10]={3,5,3,4,4,2,8,9,9,0};
int a[100000001],b[100000001],c[100000001];
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int ans=0,lenn,lenm,lenc=1,jw=0,w,q,maxn=999999999;
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	memset(c,0,sizeof(c));
	gets(n);
	gets(m);
	lenn=strlen(n);
	lenm=strlen(m);
	for(int i=1;i<=lenn;i++)
	{
		a[i]=n[i]-48;
	}
	for(int i=1;i<=lenm;i++)
	{
		b[i]=m[i]-48;
	}
	for(int i=1;i<=lenn;i++)         //�����λ���ĳ˻��� 
		for(int j=1;j<=lenm;j++)
		{
			c[i+j-1]=a[i]*b[j];
		}
	for(int i=1;i<=maxn;i++)    	//��λ 
	{
		if(c[i]>=10)
		{
			jw=c[i]/10;
			c[i+1]+=jw;
			c[i]%=10;
			jw=0;
		}
	}
	for(int i=maxn;i>=1;i--)
	{
		if(c[i])
		{
			w=i;
		}
	}
	while(w>9)
	{
		lenc=1;
		for(int i=1;i<=lenc;i++)
		{
			if(a[lenc]<t[lenc]&&a[lenc+1]>0)
			{
				jw=1;
				a[lenc]=a[lenc]+10;
				a[lenc+1]=a[lenc+1]-jw;
			}
			c[lenc]=a[lenc]-t[lenc];
			jw=0;
			lenc++;
		}
	}
	for(int i=maxn;i>=1;i--)
	{
		if(c[i])
		{
			q=i;
		}
	}
	for(int i=q;i>=1;i++)
	{
		cout<<c[i];
	}
	return 0;
}
