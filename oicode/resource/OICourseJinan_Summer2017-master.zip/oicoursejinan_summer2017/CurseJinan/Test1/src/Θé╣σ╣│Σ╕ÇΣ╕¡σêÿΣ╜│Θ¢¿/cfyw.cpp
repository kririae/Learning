#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[21][501],b[21][501];
int h[1000001];
int dh[1000001];
int dl[1000001];
int xll[1000001];
int xlh[1000001];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	int n,m,ans=0,max=0,x=1,y=1,z=1,w=1;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			b[i][j]=a[i][j];
		}
	sort(b,b+n*m);
	max=b[n][m];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m/2;j++)
		{
			dh[x]=a[i][j]+a[i][m-j];
			x++;
		}
	sort(dh,dh+x);
	if(max<dh[x])
	{
		max=dh[x];
	}
	for(int j=1;j<=m;j++)
		for(int i=1;i<=n/2;i++)
		{
			dl[y]=a[i][j]+a[n-i][j];
		}
	sort(dl,dl+y);
	if(max<dl[y])
	{
		max=dl[y];
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<m;j++)
		{
			xll[z]=a[i][j]+a[i][j+1];
			z++;
		}
	sort(xll,xll+z);
	if(max<xll[z])
	{
		max=xll[z];
	}
	for(int j=1;j<=m;j++)
		for(int i=1;j<n;i++)
		{
			xlh[z]=a[i][j]+a[i+1][j];
			w++;
		}
	sort(xlh,xlh+w);
	if(max<xlh[w])
	{
		max=xlh[w];
	}
	ans=max;
	cout<<ans;
	return 0;
}
