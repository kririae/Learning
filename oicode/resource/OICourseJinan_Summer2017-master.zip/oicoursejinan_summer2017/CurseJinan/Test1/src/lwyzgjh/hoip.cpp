#include<iostream>
#include<cstdio>
using namespace std;
int n,m,mmp=998244353;
long long ans;
int gcd(int a,int b)
{
	if(b==0)
	{
		return a;
	}
	return gcd(b,a%b);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	cin>>n>>m;
	if(n<m)
	{
		swap(n,m);
	}
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=m;j++)
	    {
	    	ans=((ans%mmp)+(gcd(i,j)%mmp))%mmp;
		}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
