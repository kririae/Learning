#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
long long c,d,mmp=998244353;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>c>>d;
	cout<<((c%mmp)*(d%mmp))%mmp-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
