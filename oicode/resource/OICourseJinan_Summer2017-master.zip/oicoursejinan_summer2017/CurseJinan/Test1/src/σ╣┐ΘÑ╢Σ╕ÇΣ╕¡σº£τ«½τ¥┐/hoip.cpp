#include <iostream>
#include <cstdio>
#include <algorithm>
#define ll long long
using namespace std;
ll read()
{
	ll x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
const ll mod(998244353);
bool judge(int num)
{
    if(num==2||num==3)
    return true;
    
    if(num%6!=1&&num%6!=5)
    return false;
    
    for(int i=5;i*i<=num;i+=6)
        if(num%i==0||num%(i+2)==0)
        return false;
    
    return true;
}
ll gcd(ll a,ll b)
{
	return a%b==0?b:gcd(b,a%b);
}
ll ans[1001][1001],Ans,n,m,a;
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	n=read(),m=read();
	if(n<=1000)
	{
		for(int i=1;i<=n;i++)
		for(int j=i;j<=m;j++)
		{
			ans[i][j]=ans[j][i]=gcd(i,j);
		}
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		Ans+=ans[i][j]%mod;
		printf("%lld",Ans%mod);
	}
	else
	{
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			if(((judge(i)&&i!=1)||(judge(j)&&j!=1))&&j%i)
			a=ans[j][i]=1;
			else a=gcd(i,j);
			Ans+=a%mod;
		}
		printf("%lld",Ans%mod);
	}
	return 0;
}
