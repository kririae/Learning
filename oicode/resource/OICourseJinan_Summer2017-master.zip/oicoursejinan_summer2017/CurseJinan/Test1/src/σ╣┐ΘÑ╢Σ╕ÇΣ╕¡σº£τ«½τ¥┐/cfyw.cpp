#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <cstring>
#define ll long long
#define INF 0x7fffffff
using namespace std;
ll read()
{
	ll x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct node{
	ll x,y;
};
ll pic[21][501],n,m,ans[20000],Ans=-INF,vis[21][501];
queue <node> q;
int cnt;
void bfs()
{
	int i,j;
	while(!q.empty())
	{
		i=q.front().x,j=q.front().y;
		q.pop();
		int k=1;
		while(1)
		{
			if(i+k>n&&j+k>m)break;
			if(i+k<=n)
			{
				if(!vis[i+k][j])
				{
					vis[i+k][j]=1;
					ll b=ans[cnt];
					ans[cnt]=max(ans[cnt],ans[cnt]+pic[i+k][j]);
					if(b!=ans[cnt])
					{
						node a;
						a.x=i+k,a.y=j;
						q.push(a);
					}
				}
			}
			if(j+k<=m)
			{
				if(!vis[i][j+k])
				{
					vis[i][j+k]=1;
					ll b=ans[cnt];
					ans[cnt]=max(ans[cnt],ans[cnt]+pic[i][j+k]);
					if(b!=ans[cnt])
					{
						node a;
						a.x=i,a.y=j+k;
						q.push(a);
					}
				}
			}
			k+=2;
		}	
	}
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	pic[i][j]=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		ans[++cnt]=pic[i][j];
		node a;
		a.x=i,a.y=j;
		q.push(a);
		memset(vis,0,sizeof(vis));
		vis[i][j]=1;
		bfs();
	}
	for(int i=1;i<=cnt;i++)
	{
		Ans=max(Ans,ans[i]);
	}
	printf("%lld",Ans);
	return 0;
}                                 
