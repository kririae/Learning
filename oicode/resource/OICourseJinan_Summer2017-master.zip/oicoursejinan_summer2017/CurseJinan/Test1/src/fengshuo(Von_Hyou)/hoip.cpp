//#include <cstdio>
//#include <algorithm>
//#include <cmath>
/*
int gcd(int a, int b) {
  if (!a || !b) return a ? a : b;
  if (!(a % 2) && !(b % 2)) return gcd(a >> 1, b >> 1) << 1;
  else if (!(a % 2) || !(b % 2)) return !(a % 2) ? gcd(a >> 1, b) : gcd(a, b /
2);
  else return gcd(abs(a - b), std::min(a, b));
}

int main() {
  freopen("hoip.in", "r", stdin);
  freopen("hoip.out", "w", stdout);
  int n, m, tot(0);
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= m; ++j)
      tot += gcd(i, j);
  printf("%d\n", tot);
  return 0;
}*/

//const int MAXN = 10000010, Dal = 998244353;
/*
int euler[MAXN];

void EULER() {
  euler[1] = 1;
  for (int i = 2; i < MAXN; ++i) euler[i] = i;
  for (int i = 2; i < MAXN; ++i)
    if (euler[i] == i)
      for (int j = i; j < MAXN; j += i)
        euler[j] = euler[j] / i * (i - 1);
}*/
/*
int main() {
  //freopen("hoip.in", "r", stdin);
  //freopen("hoip.out", "w", stdout);
  EULER();
  int n, m, tot(0);
  scanf("%d%d", &n, &m);
  int tmax = std::max(n, m);
  for (int i = 1; i <= tmax; ++i)
    tot += int(euler[i] % Dal * (int(floor(n / i)) % Dal) * (int(floor(m / i)) % Dal)) % Dal;
  printf("%d\n", tot % Dal);
  return 0;
}*/



//Right Way
#include <cstdio>
#include <algorithm>

typedef long long LL;

const int MAXN = 10000010, Dal = 998244353;

bool mark[MAXN];
LL phi[MAXN], prime[MAXN / 10];

void EULER(int n) {
  phi[1] = 1;
  int cnt(0);
  for (register int i = 2; i <= n; ++i) {
    if (!mark[i]) { phi[i] = i - 1; prime[cnt++] = i; }
    for (register int j = 0; j < cnt && (LL)prime[j] * i <= n; ++j) {
      mark[prime[j] * i] = true;
      if (i % prime[j]) phi[prime[j] * i] = phi[i] * phi[prime[j]];
      else { phi[prime[j] * i] = phi[i] * prime[j]; break;}
    }
  }
}

int main() {
  freopen("hoip.in", "r", stdin);
  freopen("hoip.out", "w", stdout);
  EULER(MAXN);
  int n, m, tot(0);
  scanf("%d%d", &n, &m);
  int tmax = std::max(n, m);
  for (register int i = 1; i <= tmax; ++i)
    tot = (tot + phi[i] * (n / i) * (m / i)) % Dal;
  printf("%d\n", tot % Dal);
  return 0;
}