#include <cstdio>
#include <algorithm>

typedef long long LL;

const LL Dal = 998244353;

LL n, m, tot;

int main() {
  freopen("bpmp.in", "r", stdin);
  freopen("bpmp.out", "w", stdout);
  scanf("%lld%lld", &n, &m);
  n %= Dal, m %= Dal;
  printf("%lld\n", (n * m) % Dal - 1);
  return 0;
}