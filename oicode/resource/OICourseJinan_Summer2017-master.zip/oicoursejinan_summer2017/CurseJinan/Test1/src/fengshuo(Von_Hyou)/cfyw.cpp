#include <cstdio>

int main() {
  freopen("cfyw.in", "r", stdin);
  freopen("cfyw.out", "w", stdout);
  int n, m, x, tot(0);
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= m; ++j) {
      scanf("%d", &x);
      if (x > 0) tot +=x;
    } 
  printf("%d\n", tot);
  return 0;
}