#include<iostream>
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	int m,n;
	cin>>n>>m;
	cout<<n*m-1;
}
