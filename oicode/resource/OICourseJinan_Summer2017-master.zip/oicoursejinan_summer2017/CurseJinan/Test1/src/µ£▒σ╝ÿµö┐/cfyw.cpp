#include<iostream>
using namespace std;
int maxpoint=0;
int m,n;
int paper[20][500];
void dfs(int x,int y,int sum)
{
	int i=1,j=1;
	if(x==m-1&&y==n-1)
		return;
	else
	{
		sum+=paper[x][y];
		if(sum>maxpoint)
			maxpoint=sum;
		while(x+i<=m-1)
		{
			dfs(x+i,y,sum);
			i+=2;
		}
		while(y+j<=n-1)
		{
			
			dfs(x,y+i,sum);
			j+=2;
		}
		i=1;
		j=1;
		while(x+i<=m-1)
		{
			while(y+j<=n-1)
			{
				dfs(x+i,y+i,sum);
				j+=2;
			}
			i+=2;
		}
	}
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			cin>>paper[i][j];
		}
	}
	dfs(0,0,0);
	cout<<maxpoint;
	return 0;
	
}
