#include<iostream>
using namespace std;
int zzxc(int a,int b)
{
	int ys;
	ys=a%b;
	while(ys>0)
	{
		a=b;
		b=ys;
		ys=a%b;
	}
	return b;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int m,n,i=0;
	int ans=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			ans+=zzxc(i,j);
		}
	}
	cout<<ans;
	return 0;
}
