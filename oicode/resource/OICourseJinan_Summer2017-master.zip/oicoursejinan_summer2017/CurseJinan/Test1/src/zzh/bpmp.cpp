#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
const int mod1=998244353;
int n,m;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	scanf("%d%d",&n,&m);
	unsigned long long x=n*m-1;
	printf("%lld",x%mod1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
