#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
long long n,m,sum;
const int mod1=998244353;
int minn(int x,int y)
{
	int a=x%y;
	while(x%y!=0)
	{
		a=x%y;
		x=y;
		y=a;	
	}
	return a;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	sum+=n+m-1;
	if(n>m||n==m)
	{
		for(int i=2;i<=n;i++)
		{
			if(m>=i)
			sum+=i;
			else
			break;
		}
		sum%=mod1;
	}	
	if(n<m)
	{
		for(int i=2;i<=m;i++)
		{
			if(n>=i)
			sum+=i;
			else
			break;
		}
		sum%=mod1;
	}
	for(int i=2;i<=n;i++)
	for(int j=i;j<=m;j++)
	{
		if(i==j)continue;
		if(i>j&&i%j==0)
		{
			sum=(sum+j)%mod1;
			if(m>=i)
			sum=(sum+j)%mod1;
			continue;
		}
		if(i<j&&j%i==0)
		{
			sum=(sum+i)%mod1;
			if(n>=j)
			sum=(sum+i)%mod1;
			continue;
		}
		int y=minn(i,j);
		if(n>=j)y*=2;
		sum=(sum+y)%mod1;
	}
	printf("%d",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
