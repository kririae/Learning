#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
int n,m,c,sum;
int a[21][510];
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		scanf("%d",&a[i][j]);
		if(a[i][j]<0)c=1;
		if(c==1&&a[i][j]>=0)c=-1;
	}
	if(c==0)
	{
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		sum+=a[i][j];
	
	}
	if(c==-1)
	{
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		sum=max(sum,a[i][j]);
	}
	if(c==1)
	{
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		if(a[i][j]>=0)sum+=a[i][j];//ƭ�� 
	}
	printf("%d",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
