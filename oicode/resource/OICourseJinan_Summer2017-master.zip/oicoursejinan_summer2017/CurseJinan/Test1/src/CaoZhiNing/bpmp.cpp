#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long long mod=998244353;
long  n,m;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>n>>m;
    cout<<((n%mod)*(m%mod)%mod-1)%mod;
	return 0;
}

