#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int minn(int a,int b)
{  
   for(int i=1;i<=a;i++)
     if(b%i==0)
     return i;
   return 0;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	int n,m,i,j,ans=0;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	   for(j=1;j<=m;j++)
	        if(j%i==0||i%j==0)
	             ans+=min(i,j);
	          else 
	           ans+=minn(i,j);
    printf("%d\n",ans%998244353);	  
	return 0;
}

