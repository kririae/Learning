#include<iostream>
using namespace std;
ifstream fin=("hoip.in");
ofstream fout=("hoip.out");
#define cin fin
#define cout fout
int n,m,ans;
const int base=998244353;
int gcd(int i,int j)
{
	if(j==0)return i;
	return gcd(j,i%j);
}
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
    {
    	ans+=gcd(i,j);
    	ans%=base;
	}
	cout<<ans;
	return 0;
}
