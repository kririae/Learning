#include<iostream>
#include<fstream>
using namespace std;
ifstream fin=("bpmp.in");
ofstream fout=("bpmp.out");
#define cin fin
#define cout fout
int n,m,ans=-1;
const int base=998244353;
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
{
	ans+=m;
	ans%=base;
}
    cout<<ans;
	return 0;
}
