#include<iostream>
using namespace std;
ifstream fin=("cfyw.in");
ofstream fout=("cfyw.out");
#define cin fin
#define cout fout
const int INF=1000000000;
int n,m,ans=-INF;
const int maxn=22,maxm=502;
int a[maxn][maxm];
bool zheng=1;
void dfs(int l,int r,int u,int d)
{
	int totz=0;
	for(int i=l;i<=r;i++)
	for(int j=u;j<=d;j++)
	{
		if(a[i][j]>ans)ans=a[i][j];
		if(a[i][j]>0)totz+=a[i][j];	
	}
	if(l==r&&u==d)return;
	if(totz<=ans)return;
	for(int k=1;k<=(r-l+1)/2;k++)
	{
		l+=k;
		for(int i=0;i<k;i++)
		for(int j=u;j<=d;j++)
		{
			a[l+i][j]+=a[l-i-1][j];
		}
		dfs(l,r,u,d);
		for(int i=0;i<k;i++)
		for(int j=u;j<=d;j++)
		{
			a[l+i][j]-=a[l-i-1][j];
		}
		l-=k;
	}
		for(int k=1;k<(r-l+1)/2;k++)
	{
		r-=k;
		for(int i=0;i<k;i++)
		for(int j=u;j<=d;j++)
		{
			a[r-i][j]+=a[r+i+1][j];
		}
		dfs(l,r,u,d);
		for(int i=0;i<k;i++)
		for(int j=u;j<=d;j++)
		{
			a[r-i][j]-=a[r+i+1][j];
		}
		r+=k;
	}
		for(int k=1;k<=(d-u+1)/2;k++)
	{
		u+=k;
		for(int i=l;i<=r;i++)
		for(int j=0;j<k;j++)
		{
			a[i][u+j]+=a[i][u-j-1];
		}
		dfs(l,r,u,d);
		for(int i=l;i<=r;i++)
		for(int j=0;j<k;j++)
		{
			a[i][u+j]-=a[i][u-j-1];
		}
		u-=k;
	}
		for(int k=1;k<(d-u+1)/2;k++)
	{
		d-=k;
		for(int i=l;i<=r;i++)
		for(int j=0;j<k;j++)
		{
			a[i][d-j]+=a[i][d+j+1];
		}
		dfs(l,r,u,d);
		for(int i=l;i<=r;i++)
		for(int j=0;j<k;j++)
		{
			a[i][d-j]-=a[i][d+j+1];
		}
		d+=k;
	}
}
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>a[i][j];
		if(a[i][j]<0)
		zheng=0;
	}
	if(zheng)
	{
		for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		ans+=a[i][j];
		cout<<ans;
	}
	else
	{
		dfs(1,n,1,m);
		cout<<ans;
	/*	cout<<endl;
		for(int i=1;i<=10;i++)
		{
			for(int j=1;j<=10;j++)
			cout<<a[i][j]<<' ';
			cout<<endl;
		}*/
	}
	return 0;
}
