#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<stack>
using namespace std;
long long sum;
int gcd(long long x,long long y)
{
	long long c;
	while(y)
	{
		c=x%y;
		x=y;
		y=c;
	}
	return x;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w"stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			int t=gcd(i,j);
			sum+=t;
			
		}
	}
	cout<<sum;
	return 0;
}
