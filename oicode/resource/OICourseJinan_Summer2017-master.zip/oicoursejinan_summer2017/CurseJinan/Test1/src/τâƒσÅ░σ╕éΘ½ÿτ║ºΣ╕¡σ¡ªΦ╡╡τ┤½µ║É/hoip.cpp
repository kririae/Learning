#include<stdio.h>
#include<iostream>
using namespace std;

int gcd(int x, int y)  
{    

    int z=y;  
    while(x%y!=0)  
    {  
        z=x%y;  
        x=y;  
        y=z;    
    }  
    return z;  
}  

int main()
{
freopen("hoip.in","r", stdin);
freopen("hoip.out","w",stdout); 
 int p;
 int m,n;
 cin>>m>>n;
 for(int i=1;i<=n;i++)
 {
 	for(int j=1;j<=m;j++)
 	{
 		p=gcd(i,j)+p; 
	}
 }
 cout<<p%998244353;
}
