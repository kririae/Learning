#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
freopen("bpmp.in","r", stdin);
freopen("bpmp.out","w",stdout); 
	int m,n;
	cin>>n>>m;
	if(n==1)
	{
		cout<<(m-1)%998244353;
	}
	else
	{
		cout<<(m-1 + m*(n-1))%998244353;
	}
}

