#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	unsigned long long int a,b;
	cin>>a>>b;
	cout<<(a*b-1)%998244353;
	return 0;
}
