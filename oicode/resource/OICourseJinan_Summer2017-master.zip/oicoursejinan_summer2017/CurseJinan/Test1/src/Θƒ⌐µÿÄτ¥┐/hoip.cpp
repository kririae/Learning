#include<iostream>
#include<cstdio>
#define re register
using namespace std;
const int mo=998244353;
int gcd(int a,int b){
	if(a%b==0)return b;
	return gcd(b,a%b);
}
int main(){
	re long long sum=0;
	re int n,m;
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	sum=(n+m-1)%mo;
	if(n==1||m==1){
		printf("%d",max(n,m)%mo);
		return 0;
	}
	for(re int i=2;i<=n;i++)
		for(re int j=2;j<=m;j++){
			sum+=gcd(i,j)%mo;
			sum%=mo;
		}
	printf("%lld",sum);
	return 0;
}
