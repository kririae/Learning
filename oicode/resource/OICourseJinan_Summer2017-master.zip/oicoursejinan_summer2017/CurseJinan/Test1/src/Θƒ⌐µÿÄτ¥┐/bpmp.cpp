#include<iostream>
#include<cstdio>
using namespace std;
#define re register
const int mo=998244353;
int main(){
	re long long sum=0,x,y,dx=1,dy=1;
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>x>>y;
	while(x!=1&&y!=1){
		if(x>y){
			while(x>y&&x!=1&&y!=1){
				sum+=dy%mo;
				dy++;
				x--;
			}
		}
		else{
			if(x<y){
				while(x<y&&x!=1&&y!=1){
					sum+=dx%mo;
					dx++;
					y--;
				}
			}
			else{
				if(dx<dy){
					while(dx<dy&&x!=1&&y!=1){
						sum+=dx%mo;
						dx++;
						y--;
					}
				}
				else{
					while(dx>=dy&&x!=1&&y!=1){
						sum+=dy%mo;
						dy++;
						x--;
					}
				}
			}
		}
	}
	if(x!=1)
		sum+=((x-1)%mo*dx%mo)%mo;
	else
		sum+=((y-1)%mo*dy%mo)%mo;
	cout<<sum;
	return 0;
}
