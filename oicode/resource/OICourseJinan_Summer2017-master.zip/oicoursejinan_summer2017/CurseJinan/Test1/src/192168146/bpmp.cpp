#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <ctime>
using namespace std;
int main()
{
freopen("bpmp.in","w",stdin);
freopen("bpmp.out","r",stdout);
unsigned long long n,m,a=0,maxn=1;
scanf("%lld%lld",&n,&m);
for(unsigned long long int i=1;i<=1000;i++)
{
if(n%i==0)
maxn=max(i,maxn);
}
n=n/maxn;
for(int i=1;i<=maxn;i++)
a=a+n*m;
a=a-1;
a=a%998244353;
printf("%lld",a);
return 0;
}

