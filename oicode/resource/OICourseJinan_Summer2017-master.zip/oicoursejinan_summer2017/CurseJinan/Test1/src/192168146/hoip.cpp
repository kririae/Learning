#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <ctime>
using namespace std;
bool zsn[10010000];
int gcdn[10010][10010];
bool zs(int n)
{
bool p=0;
for(int i=2;i<=sqrt(n);i++)
{if(n%i==0)
p=1;
}
return p;
}
int gcd(int n,int m)
{
if(gcdn[n][m]==0)
{
if(n%m==0)
{
	gcdn[n][m]=m;
	gcdn[m][n]=m;
	return m;
}
else
n=n%m;
gcd(m,n);
}
else
return gcdn[n][m];
}
int main()
{
freopen("hoip.in","w",stdin);
freopen("hoip.out","r",stdout);
int n,m,g=0;
int a=0;
long long int sum=0;
cin>>n>>m;
for(int i=1;i<=max(n,m);i++)
zsn[i]=zs(i);
memset(gcdn,0,sizeof(0));
for(int i=1;i<=n;i++)
	if(zsn[i]==0)
	sum+=m+m/i*(i-1);
	else
	{
	for(int j=1;j<=m;j++)
	{
	g=j;
	if(j>i)
	g=j%i;
	if(gcdn[i][g]==0)
	{
	a=gcd(i,g);	
	gcdn[i][g]=a;
	gcdn[g][i]=a;
	sum+=a;
	}
	else
	sum+=gcdn[i][g];
	}
	}	
cout<<sum<<endl;
return 0;
}
