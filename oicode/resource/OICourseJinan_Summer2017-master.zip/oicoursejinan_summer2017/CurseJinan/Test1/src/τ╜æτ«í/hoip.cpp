#include<iostream>
#include<cstdio>
using namespace std;
int gcd(long long n,long long m){
	int p=m;
	while(n%m!=0){
		p=n%m;
		n=m;
		m=p;
	}
	return p;
}
long long n,m,ans;
int main(){
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		 ans+=gcd(i,j)%998244353;
		cout<<ans;
		return 0;
}

