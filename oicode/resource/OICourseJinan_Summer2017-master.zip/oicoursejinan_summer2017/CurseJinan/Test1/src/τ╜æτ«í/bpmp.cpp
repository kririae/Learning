#include<iostream>
using namespace std;
long long m,n,ans;
int main(){
	cin>>n>>m;
	if (n>m) 
		ans=(m-1+m*(n-1))%998244353;
	else ans=(n-1+n*(m-1))%998244353;
	cout<<ans;
return 0;
}
