#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int n,m;
unsigned long long ans;
int a[100001][100001];
int ojld(int x,int y)
{
	if(x%y==0)
		return y;
	else
		ojld(y,x%y);
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",stdout);
	scanf("%d%d",&n,&m);
	/*if(n>=10000&&m>=10000)
	{
		printf("gg");
		return 0;
	}*/
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			int gys;
			int x=max(i,j);
			int y=i+j-x;
			if(i==j)
				gys=i;
			else
				gys=ojld(x,y);
			ans+=gys;
			if(ans>998244353)
				ans%=998244353;
		}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

