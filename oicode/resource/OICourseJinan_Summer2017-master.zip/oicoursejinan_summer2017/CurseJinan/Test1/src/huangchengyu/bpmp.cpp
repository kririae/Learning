#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
unsigned long long ans;
long long a,b;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	cin>>a>>b;
	ans=(a*b-1)%998244353;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
