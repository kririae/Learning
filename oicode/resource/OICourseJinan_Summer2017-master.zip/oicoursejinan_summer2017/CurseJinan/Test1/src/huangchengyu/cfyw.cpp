#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,ans;
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			int x;
			scanf("%d",&x);
			if(x>0)
				ans+=x;
		}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
