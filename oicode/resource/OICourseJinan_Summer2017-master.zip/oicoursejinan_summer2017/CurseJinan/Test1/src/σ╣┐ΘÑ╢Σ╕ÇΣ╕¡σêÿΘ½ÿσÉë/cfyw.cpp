#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<stack>
#include<cstdlib>
using namespace std;
inline void read(int &n)
{
	char c='+';int x=0;bool flag=0;
	while(c<'0'||c>'9'){c=getchar();if(c=='-')flag=1;}
	while(c>='0'&&c<='9')
	x=(x<<1)+(x<<3)+c-48,c=getchar();
	flag==1?n=-x:n=x;
}
int n,m;
struct node
{
	int a[101][101];
	int nowmaxn;
	int bgx,bgy,edx,edy;
}now,nxt;
int ans=-0x7ffff;
queue<node>q;
int tot=0;
inline void calc()
{
	/*memset(nxt.a,0,sizeof(nxt.a));
	for(int i=now.bgx;i<=now.edx;i++)
		for(int j=now.bgy;j<=now.edy;j++)
			nxt.a[i][j]=now.a[i][j];*/
	nxt=now;
}
inline void print()
{
	
	for(int i=now.bgx;i<=now.edx;i++)
	{
		for(int j=now.bgy;j<=now.edy;j++)
			printf("%d ",now.a[i][j]);
		printf("\n");
	}
	printf("*********************************\n");
}
inline void getans()
{
	for(int i=now.bgx;i<=now.edx;i++)
			for(int j=now.bgy;j<=now.edy;j++)
				ans=max(ans,now.a[i][j]);
}
void check()
{
	tot++;
	//cout<<tot<<"---"<<endl;
	if(tot>63843800)
	{
		cout<<ans;
		exit(0);
	}
	
}
inline void bfs(int hc,int lc)
{
	q.push(now);
	while(!q.empty())
	{
		now=q.front();
		q.pop();
		int num=0;
		for(int i=now.bgx;i<=now.edx;i++)
			for(int j=now.bgy;j<=now.edy;j++)
				if(now.a[i][j]>0)
					num+=now.a[i][j],check();
		if(ans>num)
			continue;
		
		getans();
		calc();
	//	print();
		for(int i=now.bgy;i<now.edy;i++)//�����۵�
		{
			for(int j=1;j<=(min((i-now.bgy),(now.edy-i))+1);j++)
			{
				for(int k=1;k<=now.edx;k++)
				{
					nxt.a[k][i+j]+=nxt.a[k][i-j+1];
					nxt.a[k][i-j+1]=0;
					check();
				}
			}
		//	cout<<now.bgy<<"&"<<i<<endl;
			nxt.bgy=i+1;
		//	cout<<nxt.bgy<<"^"<<endl;
			nxt.edy=max(now.edy,i+i-now.bgy+1);
			nxt.bgx=now.bgx;
			nxt.edx=now.edx;
			q.push(nxt);
			calc();
		}
		for(int i=now.bgx;i<now.edx;i++)
		{
			for(int j=1;j<=(min((i-now.bgx),(now.edx-i+1))+1);j++)
			{
				for(int k=1;k<=now.edy;k++)
				{
					nxt.a[i+j][k]+=nxt.a[i-j+1][k];
					nxt.a[i-j+1][k]=0;
					check();
				}
			}
			nxt.edy=now.edy;
			nxt.bgy=now.bgy;
			nxt.bgx=i+1;
			nxt.edx=max(now.edx,i+i-now.bgx+1);
			q.push(nxt);
			calc();
		}
	}
	
}
int main()
{
	freopen("cfyw.in","r",stdin);
	freopen("cfyw.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			read(now.a[i][j]);
	now.bgx=now.bgy=1;
	now.edx=n;
	now.edy=m;
	bfs(0,0);
	printf("%d",ans);
	return 0;
}
