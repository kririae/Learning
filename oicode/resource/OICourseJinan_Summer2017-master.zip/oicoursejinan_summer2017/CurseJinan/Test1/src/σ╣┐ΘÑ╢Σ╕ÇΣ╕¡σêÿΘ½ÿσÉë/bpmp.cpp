#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<stack>
#define lli long long 
using namespace std;
const int mod=998244353;
void read(int &n)
{
	char c='+';int x=0;bool flag=0;
	while(c<'0'||c>'9'){c=getchar();if(c=='-')flag=1;}
	while(c>='0'&&c<='9')
	x=(x<<1)+(x<<3)+c-48,c=getchar();
	flag==1?n=-x:n=x;
}
lli n,m;
int fastmul(int x,int p)
{
	int now=x;
	int ans=0;
	while(p)
	{
		if(p&1)
		{
			--p;
			ans=(ans+now)%mod;
		}
		p>>=1;
		now=(now+now)%mod;
	}
	return (ans-1)%mod;
}
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
	//read(n);read(m);
	cin>>n>>m;
	cout<<fastmul(n,m)%mod;
	return 0;
}
