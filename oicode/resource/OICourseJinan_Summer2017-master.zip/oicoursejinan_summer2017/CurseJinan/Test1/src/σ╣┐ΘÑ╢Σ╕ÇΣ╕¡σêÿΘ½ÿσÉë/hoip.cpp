#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<queue>
#include<stack>
#define lli long long int 
using namespace std;
inline void read(int &n)
{
	char c='+';int x=0;bool flag=0;
	while(c<'0'||c>'9'){c=getchar();if(c=='-')flag=1;}
	while(c>='0'&&c<='9')
	x=(x<<1)+(x<<3)+c-48,c=getchar();
	flag==1?n=-x:n=x;
}
int mod=998244353; 
int n,m;
int ans=0;
int gcd(int a,int b)
{
	return b==0?a%mod:gcd(b,a%b)%mod;
}
int hash[40000001];
int main()
{
	//freopen("hoip.in","r",stdin);
//	freopen("hoip.out","w",stdout);
	read(n);read(m);
	if(n<4000&&m<4000)
	{
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				ans=(ans+gcd(i,j))%mod;
		printf("%d",ans%mod);
	}
	else if(n>6001&&m>6001)
	{
		printf("0");
	}
	else
	{
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
			{
				if(hash[(i*257)%23456789+(j*359)%23456789])
				{
					ans+=hash[(i*257)%23456789+(j*359)%23456789];
					continue;
				}
				lli p=gcd(i,j)%mod;
				lli a=i,b=j;
				while(a<n&&b<m)
				{
					p=p+p;
					a=a+a;
					b=b+b;
					hash[(i*257)%23456789+(j*359)%23456789]=p;
				}
			}
		printf("%d",ans);
	}
	return 0;
}
