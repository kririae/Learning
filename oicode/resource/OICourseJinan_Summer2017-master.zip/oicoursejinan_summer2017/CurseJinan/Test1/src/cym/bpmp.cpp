#include<iostream>
#include<cstdio>
using namespace std;
long long m,n;
int main()
{
	freopen("bpmp.in","r",stdin);
	freopen("bpmp.out","w",stdout);
    cin>>m>>n;
    m%=998244353;
    n%=998244353;
    m=m*n-1;
    m%=998244353;
    cout<<m;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
