#include<iostream>
#include<cstdio>
using namespace std;
int n,m;
bool b[10000001];
int c[10000001];
long long ans;
int k,p,q;
int f,l,v;
long long t;
int e,r;
long long ddd(int x,int y)
{
	e=x;r=y;
	t=e%r;
	while(t!=0)
	{
		e=r;
		r=t;
		t=e%r;
	}
	return r;
}
int main()
{
	freopen("hoip.in","r",stdin);
	freopen("hoip.out","w",sydout)
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
    	for(int j=1;j<=m;j++)
    	{
    		ans+=ddd(i,j);
    		ans%=998244353;
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}
