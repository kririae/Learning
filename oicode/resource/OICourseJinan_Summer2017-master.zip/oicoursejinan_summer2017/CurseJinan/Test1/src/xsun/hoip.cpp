#include <cstdio>
#define maxn 10240
#define mod 998244353
using namespace std;
int n,m,ans;
int buf[maxn][maxn];
int gcd(int x,int y){
    if(y==0)return x;
    if(buf[x][y])return buf[x][y];
    else return buf[x][y] = gcd(y,x%y);
}
int main(){
    freopen("hoip.in","r",stdin);
    freopen("hoip.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++){
            ans+=gcd(i,j);
            if(ans>mod)ans-=mod;
        }
    printf("%d\n",ans);
}