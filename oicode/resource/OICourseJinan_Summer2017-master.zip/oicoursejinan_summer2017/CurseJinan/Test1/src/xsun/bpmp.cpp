#include <iostream>
using namespace std;
long long n,m;
int main() {
    freopen("bpmp.in","r",stdin);
    freopen("bpmp.out","w",stdout);
    cin >> n >> m;
    cout << ((n*m-1)%998244353) << endl;
    return 0;
}