#include <cstdio>
#define MAXN 512
using namespace std;
int u[MAXN],d[MAXN],r[MAXN],l[MAXN],n,m;


int main(){
    freopen("cfyw.in","r",stdin);
    freopen("cfyw.out","w",stdout);
    scanf("%d%d",&n,&m);
    printf("%d",25);
}