#include <cstdio>

#ifdef WIN32
#	define lld "%I64d"
#else
#	define lld "%lld"
#endif
typedef long long dint;

int main() {
	freopen("bpmp.in", "r", stdin);
	freopen("bpmp.out", "w", stdout);
	dint a, b;
	scanf(lld lld, &a, &b);
	printf(lld "\n", (a * b - 1)% 998244353);
}
