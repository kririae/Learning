#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long dint;
#define _l (long long int)

const int mod = 998244353;
const int maxn = 10000003;

int isp[maxn], pn[maxn], tp, mu[maxn], smu[maxn];

void pre(int n) {
	memset(isp, 0, sizeof(isp));
	tp = 0;
	smu[0] = 0;
	smu[1] = mu[1] = 1;
	for (int i = 2; i <= n; ++ i) {
		if (!isp[i]) {
			mu[pn[tp ++] = i] = -1;
		}
		for (int j = 0; j < tp && i * pn[j] <= n; ++ j) {
			isp[i * pn[j]] = 1;
			if (i % pn[j]) {
				mu[i * pn[j]] = -mu[i];
			} else {
				mu[i * pn[j]] = 0;
				break;
			}
		}
		smu[i] = smu[i - 1] + mu[i];
	}
}

int calc(int n, int m) {
	int s(0);
	for (int i = 1, j; i <= n; i = j + 1) {
		j = min(n / (n / i), m / (m / i));
		s = (s + _l (m / i) * (n / i)% mod * (smu[j] - smu[i - 1]))% mod;
		if (s < 0) {
			s += mod;
		}
	}
	return s;
}

inline int sumSeg(int a, int b) {
	return _l (a + b) * (b - a + 1) / 2 % mod;
}

int main(int argc, char**) {
	if (argc == 1) {
		freopen("hoip.in", "r", stdin);
		freopen("hoip.out", "w", stdout);
	}
	int n, m, s(0);
	scanf("%d%d", &n, &m);
	if (n > m) {
		swap(n, m);
	}
	pre(n);
	for (int i = 1, j; i <= n; i = j + 1) {
		j = min(n / (n / i), m / (m / i));
		s = (s + _l calc(n / i, m / i) * sumSeg(i, j))% mod;
		if (s < 0) {
			s += mod;
		}
	}
	printf("%d\n", s);
}
