#define PROC "gfge"
#include <cstdio>
#include <algorithm>
#include <memory.h>

using namespace std;

#define pow2(x) (1<<(x))

const int maxm = 22;
const int maxn = 510;
const int inf = 0x3f3f3f3f;

int a[maxm][maxn], c[maxn], s, n, m;

int dp(int z) {
	int c0, c1;
	bool an = 1;
	memset(c, 0, sizeof(c));
	for (int i = 0; i < m; i ++)
		if (z & pow2(i))
			for (int j = 0; j < n; j ++)
				c[j] += a[i][j];
	for (int j = 0; j < n; j ++)
		if (c[j] > 0) {
			an = 0;
			break;
		}
	if (an)
		return -inf;
	c0 = 0;
	c1 = 0;
	for (int i = 0; i < n; i ++)
		if (i & 1) {
			int x = c[i] + c0;
			c1 = max(x, c1);
		}
		else {
			int x = c[i] + c1;
			c0 = max(x, c0);
		}
	return max(c0, c1);
}

void dfs(int p, int l, int z) {
	if (p == m) {
		s = max(s, dp(z));
		return;
	}
	else {
		if (l == -1 || ((p - l) & 1))
			dfs(p + 1, p, z | pow2(p));
		dfs(p + 1, l, z);
	}
}

int main() {
	freopen("cfyw.in", "r", stdin);
	freopen("cfyw.out", "w", stdout);
	scanf("%d%d", &m, &n);
	s = -inf;
	for (int i = 0; i < m; i ++)
		for (int j = 0; j < n; j ++)
			scanf("%d", a[i] + j), s = max(s, a[i][j]);
	if (s > 0)
		dfs(0, -1, 0);
	printf("%d\n", s);
}
