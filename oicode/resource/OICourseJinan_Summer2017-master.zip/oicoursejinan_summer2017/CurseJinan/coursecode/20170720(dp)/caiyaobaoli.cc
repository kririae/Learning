int n, m, v[maxn], w[maxn], ans;
// v: ti ji
// w: jia zhi

int DFS(int i, int m) {
	if (i == n) {
		return 0;
	}
	if (v[i] <= m) {
		return max(DFS(i + 1, m - v[i]) + w[i], DFS(i + 1, m));
	} else {
		return DFS(i + 1, m);
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; ++ i) {
		cin >> v[i] >> w[i];
	}
	ans = 0;
	cout << DFS(0, m) << endl;
}
