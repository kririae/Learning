#include <bits/stdc++.h>

using namespace std;

const int maxn = 1003;

int n, m, mx, my;
int f[maxn][maxn];

bool bunengzou(int x, int y) {
	int a = x - mx;
	int b = y - my;
	int dissqr = a * a + b * b;
	return dissqr != 0 && dissqr != 5;
}

int main() {
	cin >> n >> m >> mx >> my;
	f[1][1] = 1;
	for (int i = 1; i <= n; ++ i) {
		for (int j = 1; j <= m; ++ j) {
			if (bunengzou(i, j)) {
				f[i][j] = 0;
			} else {
				f[i][j] = f[i - 1][j] + f[i][j - 1];
			}
		}
	}
	cout << f[n][m] << endl;
}
