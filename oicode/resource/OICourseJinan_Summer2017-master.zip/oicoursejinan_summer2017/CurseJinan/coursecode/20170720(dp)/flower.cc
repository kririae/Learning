#include <bits/stdc++.h>

using namespace std;

const int maxn = 1003;

int n, m, answer;
int f[maxn][maxn], a[maxn];

int DFS(int x, int y) {
	if (x == n && y == m) {
		return 1;
	}
	int answer = 0;
	for (int i = 0; i <= a[x] && i + y <= m; ++ i) {
		answer += DFS(x + 1, y + i);
	}
	return answer;
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; ++ i) {
		cin >> a[i];
	}
	f[0][0] = 1;
	for (int i = 0; i < n; ++ i) {
		for (int j = 0; j <= m; ++ j) {
			for (int k = 0; k + j <= m && k <= a[i]; ++ k) {
				f[i + 1][j + k] += f[i][j];
			}
		}
	}
	cout << f[n][m] << endl;
}
