#include <bits/stdc++.h>

using namespace std;

const int maxn = 1003;

int n, m, v[maxn], w[maxn], ans, f[maxn];
// v: ti ji
// w: jia zhi

int main() {
	cin >> m >> n;
	for (int i = 1; i <= n; ++ i) {
		cin >> v[i] >> w[i];
	}
	memset(f, 0, sizeof(f));
	for (int i = 1; i <= n; ++ i) {
		for (int j = m - v[i]; j >= 0; -- j) {
			f[j] = max(f[j], f[j + v[i]] + w[i]);
		}
	}
	cout << f[0] << endl;
}
