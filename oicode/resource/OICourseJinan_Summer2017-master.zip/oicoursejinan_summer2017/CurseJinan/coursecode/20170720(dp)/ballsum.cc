const int maxn = 5003;
const int mod = 998244353;
int n, m, ans, f[2][maxn];
long long s[maxn * 3];

#define modAdd(_x_,_y_) (((_x_)+(_y_)>=mod)?((_x_)+(_y_)-mod):(_x_)+(_y_))

int main() {
	cin >> n >> m;
	int dangqian = 0, shangyige = 1;
	memset(f, 0, sizeof(f));
	f[dangqian][1] = 1;
	for (int i = 1; i <= m; ++ i) {
		swap(dangqian, shangyige);
		s[0] = 0;
		for (int j = 1; j <= n; ++ j) {
			s[j] = s[j - 1] + f[shangyige][j];
		}
		for (int j = n + 1; j <= n * 2; ++ j) {
			s[j] = s[j - 1] + f[shangyige][j - n];
		}
		for (int j = n * 2 + 1; j <= n * 3; ++ j) {
			s[j] = s[j - 1] + f[shangyige][j - n * 2];
		}
		for (int j = 1; j <= n; ++ j) {
			f[dangqian][j] = s[j + n + r[j]] - s[j + n - r[j] - 1] - f[shangyige][j];
		}
	}
	cout << f[dangqian][1] << endl;
}
