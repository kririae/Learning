int n, m, a[maxn][maxn], f[maxn][maxn];

int main() {
	cin >> n;
	for (int i = 0; i < n; ++ i) {
		for (int j = 0; j <= i; ++ j) {
			cin >> a[i][j];
		}
	}
	f[0][0] = a[0][0];
	for (int i = 1; i < n; ++ i) {
		f[i][0] = f[i - 1][0] + a[i][0];
		f[i][i] = f[i - 1][i - 1] + a[i][i];
		for (int j = 1; j < i; ++ j) {
			f[i][j] = max(f[i - 1][j], f[i - 1][j - 1]) + a[i][j];
		}
	}
	int answer = f[n - 1][0];
	for (int i = 1; i < n; ++ i) {
		answer = max(answer, f[n - 1][i];
	}
	cout << answer << endl;
}
