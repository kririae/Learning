int n, m, a[maxn][maxn];
bool f[maxn][maxn][103];

int main() {
	cin >> n;
	for (int i = 0; i < n; ++ i) {
		for (int j = 0; j <= i; ++ j) {
			cin >> a[i][j];
		}
	}
	memset(f, 0, sizeof(f));
	f[0][0][a[0][0] % 100] = 0;
	for (int i = 1; i < n; ++ i) {
		for (int k = 0; k < 100; ++ k) {
			f[i][0][(k + a[i][0])% 100] |= f[i - 1][0][k];
			f[i][i][(k + a[i][i])% 100] |= f[i - 1][i - 1][k];
			for (int j = 1; j < i; ++ j) {
				f[i][j][(k + a[i][j])% 100] |= (f[i - 1][j][k] || f[i - 1][j - 1][k]);
			}
		}
	}
	int answer = 0;
	for (int i = 1; i < n; ++ i) {
		for (int k = 0; k < 100; ++ k) {
			if (f[n - 1][i][k]) {
				answer = max(answer, k);
			}
		}
	}
	cout << answer << endl;
}
