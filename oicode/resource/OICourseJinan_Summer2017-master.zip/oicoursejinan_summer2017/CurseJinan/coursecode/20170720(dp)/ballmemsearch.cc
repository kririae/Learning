int n, m, ans, f[maxn][maxn];
int DFS(int pos, int m) {
	// qiu zai pos shou li
	// hai yao chuan m lun
	if (m == 0) {
		if (pos == 1) {
			return 1;
		}
		return 0;
	}
	if (f[pos][m] != -1) {
		return f[pos][m];
	}
	int answer = 0;
	if (pos == 1) {
		answer += DFS(n, m - 1);
	} else {
		answer += DFS(pos - 1, m - 1);
	}
	if (pos == n) {
		answer += DFS(1, m - 1);
	} else {
		answer += DFS(pos + 1, m - 1);
	}
	return f[pos][m] = answer;
}
int main() {
	memset(f, -1, sizeof(f));
	cin >> n >> m;
	ans = 0;
	cout << DFS(1, m) << endl;
}
