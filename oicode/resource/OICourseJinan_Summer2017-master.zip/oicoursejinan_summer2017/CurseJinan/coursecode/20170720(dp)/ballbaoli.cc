int n, m, ans;
int DFS(int pos, int m) {
	// qiu zai pos shou li
	// hai yao chuan m lun
	if (m == 0) {
		if (pos == 1) {
			return 1;
		}
		return 0;
	}
	int answer = 0;
	if (pos == 1) {
		answer += DFS(n, m - 1);
	} else {
		answer += DFS(pos - 1, m - 1);
	}
	if (pos == n) {
		answer += DFS(1, m - 1);
	} else {
		answer += DFS(pos + 1, m - 1);
	}
	return answer;
}
int main() {
	cin >> n >> m;
	ans = 0;
	cout << DFS(1, m) << endl;
}
