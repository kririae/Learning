#include <bits/stdc++.h>

using namespace std;

const int maxn = 1003;

int n, m;
int f[maxn], a[maxn];

int main() {
	cin >> n;
	for (int i = 0; i < n; ++ i) {
		cin >> a[i];
	}
	for (int i = 0; i < n; ++ i) {
		f[i] = 1;
		for (int j = 0; j < i; ++ j) {
			if (a[j] <= a[i]) {
				f[i] = max(f[i], f[j] + 1);
			}
		}
	}
}
