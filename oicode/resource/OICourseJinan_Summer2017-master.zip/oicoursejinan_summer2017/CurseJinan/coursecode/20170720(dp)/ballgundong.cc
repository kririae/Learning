const int maxn = 5003;
int n, m, ans, f[2][maxn];

int main() {
	cin >> n >> m;
	int dangqian = 0, shangyige = 1;
	memset(f, 0, sizeof(f));
	f[dangqian][1] = 1;
	for (int i = 1; i <= m; ++ i) {
		swap(dangqian, shangyige);
		f[dangqian][1] = f[shangyige][n] + f[shangyige][2];
		f[dangqian][n] = f[shangyige][n - 1] + f[shangyige][1];
		for (int j = 2; j < n; ++ j) {
			f[dangqian][j] = f[shangyige][j - 1] + f[shangyige][j + 1];
		}
	}
	cout << f[dangqian][1] << endl;
}
