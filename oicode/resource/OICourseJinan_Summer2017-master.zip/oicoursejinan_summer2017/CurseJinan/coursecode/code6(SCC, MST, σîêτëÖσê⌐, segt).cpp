void kruskal() {
	struct edge {
		int s,e,d;
		bool operator<(const edge &a)const{
			return d<a.d;
		}
	}ed[maxm];

	sort(ed+1,ed+m+1);
	for (int a=1;a<=n;a++)
		f[a]=a;
	for (int a=1;a<=m;a++){
		int f1=getf(ed[a].s);
		int f2=getf(ed[a].e);
		if (f1!=f2) {
			f[f1]=f2;
		}
	}
}


f[i][j]=f[f[i][j-1]][j-1];
g[i][j]=max(g[i][j-1],g[f[i][j-1]][j-1]);






void dfs(int now) {
	t++;
	dfn[now]=low[now]=t;
	instack[now]=true;
	s[++size]=now;
	for (edge *e=v[now];e;e=e->next)
		if (!dfn[e->e]) {
			dfs(e->e);
			low[now]=min(low[now],low[e->e]);
		}
		else {
			if (instack[e->e]) low[now]=min(low[now],dfn[e->e]);
		}
	if (dfn[now]==low[now]) {
		cnt++;
		while (s[size]!=now) {
			belong[s[size]]=cnt;
			instack[s[size]]=false;
			size--;
		}
		belong[now]=cnt;
		instack[now]=false;
		size--;
	}
}

for (int a=1;a<=n;a++)
	for (edge *e=v[a];e;e=e->next)
		if (belong[a]!=belong[e->e]) add_edge(belong[a],belong[e->e]);


void top_sort() {
	for (int a=1;a<=n;a++)
		for (edge *e=v[a];e;e=e->next)
			in[e->e]++;
	int size=0;
	for (int a=1;a<=n;a++)
		if (!in[a]) q[++size]=a;
	for (int a=1;a<=n;a++) {
		int now=q[a];
		for (edge *e=v[now];e;e=e->next) {
			in[e->e]--;
			if (!in[e->e]) q[++size]=e->e;
		}
	}
}


for (int a=1;a<=n;a++) {
	f[a]=max(f[a],w[p[a]]);
	for (edge *e=v[p[a]];e;e=e->next)
		f[e->e]=max(f[e->e],f[a]+w[p[e->e]]);
}


bool dfs(int now) {
	for (int a=1;a<=m;a++)
		if (!use[a] && match[now][a]) {
			use[a]=true;
			if (!result[a] || dfs(result[a])) {
				result[a]=now;
				return true;
			}
		}
	return false;
}

void xiongyali() {
	//n m
	int ans=0;
	for (int a=1;a<=n;a++) {
		memset(use,false,sizeof(use));
		if (dfs(a)) ans++;
	}	
}


for (int a=1;a<=n;a++)
	w[belong[a]] += value[a];


int build(int l,int r) {
	int rt=newnode();
	if (l==r) {
		return rt;
	}
	int m=(l+r)>>1;
	z[rt].l=build(lson);
	z[rt].r=build(rson);
}


ans[rt]=ans[rt<<1]+ans[rt<<1|1]+R[rt<<1]*L[rt<<1|1]
L[rt]=L[rt<<1]
R[rt]=R[rt<<1|1]




#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>

using namespace std;

#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define wmt 1,n,1

const int maxn=100010;

int n,m,mh[maxn<<2|1],cnt[maxn<<2|1];

int solve(int h,int l,int r,int rt)
{
	if (l==r) return mh[rt]>h;
	int m=(l+r)>>1;
	if (mh[rt<<1]>=h) return solve(h,lson)+cnt[rt]-cnt[rt<<1];
	else return solve(h,rson);
}

void update(int l,int r,int rt)
{
	int m=(l+r)>>1;
	mh[rt]=max(mh[rt<<1],mh[rt<<1|1]);
	cnt[rt]=cnt[rt<<1]+solve(mh[rt<<1],rson);
}

void modify(int l,int r,int rt,int x,int y)
{
	if (l==r)
	{
		mh[rt]=y;
		return;
	}
	int m=(l+r)>>1;
	if (x<=m) modify(lson,x,y);
	else modify(rson,x,y);
	update(l,r,rt);
}

void build(int l,int r,int rt)
{
	if (l==r)
	{
		cnt[rt]=1;
		scanf("%d",&mh[rt]);
		return;
	}
	int m=(l+r)>>1;
	build(lson);
	build(rson);
	update(l,r,rt);
}

int main()
{
	scanf("%d%d",&n,&m);
	build(wmt);
	char s[5];
	for (int a=1;a<=m;a++)
	{
		scanf("%s",s);
		if (s[0]=='Q') printf("%d\n",cnt[1]);
		else 
		{
			int x,y;
			scanf("%d%d",&x,&y);
			modify(wmt,x,y);
		}
	}

	return 0;
}



