void dandiao() {
	int front=1,tail=0;
	for (int a=1;a<=k;a++)
	{
		while (tail>=front && z[a]<q[tail][0])
			tail--;
		tail++;
		q[tail][0]=z[a];q[tail][1]=a;
	}

	for (int a=k+1;a<=n;a++)
	{
		while (tail>=front && z[a]<q[tail][0])
			tail--;
		tail++;
		q[tail][0]=z[a];q[tail][1]=a;
		if (q[front][1]==a-k) front++;
	}
}


class queue {
	int front=1,tail=0,q[10000];
	void enque(int x) { q[++tail]=x;}
	void deque() { front++;}
	bool empty() { return front>tail;}
	int front1() { return q[front];
}
class stack {
	int size=0,s[10000];
	void enque(int x) { s[++size]=x;}
	void deque() { size--;}
	bool empty() { return size!=0;}
	int front() { return s[size];
}


#include<queue>

using namespace std;

priority_queue<int> heap;

heap.push(-x);//logn
heap.pop();//logn
heap.top();//1
heap.size();//1
heap.empty();//1

struct rec {
	int a;
	bool operator<(const rec &not_gg)const {
		return a<not_gg.a;
	}
}a,b,z[1000];

sort(z,z+n);

bool operator<(const rec &gg1,const rec &gg2){
	return gg1.a<gg2.a;
}

priority_queue<rec> heap;

int getf(int p) {
	if (f[p]==p) return p;
	else return f[p]=getf(f[p]);
}

void merge(int p1,int p2) {
	int f1=getf(p1);
	int f2=getf(p2);
	if (f1!=f2) {
		if (size[f1]>size[f2]) swap(f1,f2);
		f[f1]=f2;
		size[f2]+=size[f1];
	}
}

west14.openjudge.cn/20170718

const int maxn=23333;
int z[maxn],sum[maxn<<2];//maxn*4

//rt <<1 =rt*2
//rt<<1|1=rt*2+1

#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1

void update(int rt) {
	sum[rt]= sum[rt<<1] + sum[rt<<1|1];
}

void build(int l,int r,int rt) {
	if (l==r) {
		sum[rt]=z[l];
		return;
	}
	int m=(l+r)>>1;//(l+r)/2 [l,m] [m+1,r]
	build(lson);
	build(rson);
	update(rt);
}
build(1,n,1);

int query(int l,int r,int rt,int nowl,int nowr) {
	if (nowl<=l && r<=nowr) return sum[rt];
	int m=(l+r)>>1;
	int ans=0;
	if (nowl<=m) ans+=query(lson,nowl,nowr);
	if (m<nowr) ans+=query(rson,nowl,nowr);
	return ans;
}
query(1,n,1,l,r);

void modify(int l,int r,int rt,int p,int v) {
	if (l==r) {
		sum[rt]=v;
		return;
	}
	int m=(l+r)>>1;
	if (p<=m) modify(lson,p,v);
	else modify(rson,p,v);
	update(rt);
}
modify(1,n,1,p,v);
�ҳ�



const int maxn=23333;
int z[maxn],sum[maxn<<2];//maxn*4

//rt <<1 =rt*2
//rt<<1|1=rt*2+1

#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1

void update(int rt) {
	sum[rt]= sum[rt<<1] + sum[rt<<1|1];
}

void color(int l,int r,int rt,int c) {
	col[rt] = c;
	sum[rt] = c*(r-l+1);
}

void push_col(int l,int r,int rt) {
	if (col[rt]) {
		int m=(l+r)>>1;
		color(lson,col[rt]);
		color(rson,col[rt]);
		col[rt]=0;
	}
}

void build(int l,int r,int rt) {
	col[rt]=0;
	if (l==r) {
		sum[rt]=z[l];
		return;
	}
	int m=(l+r)>>1;//(l+r)/2 [l,m] [m+1,r]
	build(lson);
	build(rson);
	update(rt);
}
build(1,n,1);

int query(int l,int r,int rt,int nowl,int nowr) {
	if (nowl<=l && r<=nowr) return sum[rt];
	push_col(l,r,rt);
	int m=(l+r)>>1;
	int ans=0;
	if (nowl<=m) ans+=query(lson,nowl,nowr);
	if (m<nowr) ans+=query(rson,nowl,nowr);
	return ans;
}
query(1,n,1,l,r);

void modify(int l,int r,int rt,int nowl,int nowr,int v) {
	if (nowl<=l && r<=nowr) {
		color(l,r,rt,v);
		return;
	}
	push_col(l,r,rt);
	int m=(l+r)>>1;
	if (nowl<=m) modify(lson,nowl,nowr,v);
	if (m<nowr) modify(rson,nowl,nowr,v);
	update(rt);
}
modify(1,n,1,l,r,v);

notonlysuccess.com
notonlysuccess

while (~scanf("%s%s",gg1,gg2)) {
}


while (scanf("%s%s",gg1,gg2) != EOF) {
}


scanf("%dgg%d",&a,&b);
scanf("%d-%d-%d %d:%d:%d",&year,&month,&day,&hour,&minute,&second);

#ifdef WIN32
#define LL "%I64d"
#else
#define LL "%lld"
#endif

int x;scanf("%d",&x);
long long x;scanf(LL,&x);
double x;scanf("%lf",&x);
char x[1000];scanf("%s",x);
scanf("%s",x+1);
char x;scanf("%c",&x);

scanf("%d" LL,&x,&y);

printf("%.8lf\n",x);
printf("% 8d\n",x);
scanf("%d\n%d",&x,&y);

string;

int y[10000];
int *z=y+5000;
z[-100] y[4900];









