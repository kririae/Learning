bool isPrime[maxn] = { 1 };
void getPrimes() {
	for (int i = 2; i <= n; ++ i) {
		if (!isPrime[i]) { // i bu yong mei ju le
			continue;
		}
		for (int j = i * 2; j <= n; j += i) {
			isPrime[j] = 0;
		}
	}
}
