#include <iostream>
#include <cstring>

using namespace std;

const int maxn = 4000003;

typedef long long dint;
#define _l (long long int)

int n, m, k;
int isPrime[maxn], tp, pm[maxn], f[maxn], mu[maxn], smu[maxn];
dint ans[maxn];

void pre(int n) {
	memset(isPrime, 0, sizeof(isPrime));
	tp = 0;
	smu[0] = 0;
	mu[1] = smu[1] = 1;
	f[1] = 0;
	for (int i = 2; i <= n; ++ i) {
		if (!isPrime[i]) {
			pm[tp ++] = i;
			mu[i] = -1;
			f[i] = 1;
		}
		smu[i] = smu[i - 1] + mu[i];
		for (int j = 0; j < tp && i * pm[j] <= m; ++ j) {
			int k(i * pm[j]);
			isPrime[k] = 1;
			f[k] = f[i] + 1;
			if (i % pm[j] == 0) {
				mu[k] = 0;
				break;
			} else {
				mu[k] = - mu[i];
			}
		}
	}
}

dint calc(int n, int m) {
	dint s(0);
	for (int i = 1, j; i <= n; i = j + 1) {
		j = min(n / (n / i), m / (m / i));
		s += (long long)(n / i) * (m / i) * (smu[j] - smu[i - 1]);
	}
	return s;
}

int main() {
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	if (n > m) {
		swap(n, m);
	}
	pre(m);
	memset(ans, 0, sizeof(ans));
	for (int i = 1, j; i <= n; i = j + 1) {
		j = min(n / (n / i), m / (m / i));
		dint s(calc(n / i, m / i));
		for (int k = i; k <= j; ++ k) {
			ans[f[k]] += s;
		}
	}
	for (int i = 0; i <= k; ++ i) {
		cout << ans[i] << endl;
	}
}

