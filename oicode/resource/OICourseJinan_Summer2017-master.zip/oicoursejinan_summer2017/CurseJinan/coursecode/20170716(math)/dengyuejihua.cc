#include <iostream>
#include <map>

using namespace std;

typedef long long dint;

dint a, b, p, k;

dint modMul(dint a, dint b) {
	dint s(0);
	for (; b; b >>= 1, a = (a + a)% p) {
		if (b & 1) {
			s = (s + a)% p;
		}
	}
	return s;
}
dint modPow(dint a, dint b) {
	dint s(1);
	for (; b; b >>= 1, a = modMul(a, a)) {
		if (b & 1) {
			s = modMul(s, a);
		}
	}
	return s;
}

map<dint, dint> pp;

int main() {
	cin >> a >> b >> p;
	k = min(1000000ll, p / 100 + 10ll);
	dint akinv = modPow(modPow(a, k), p - 2);
	for (dint i = 0, x = 1; i < k; ++ i, x = modMul(x, a)) {
		if (pp.find(x) == pp.end()) {
			pp[x] = i;
		}
	}
	dint bmulak = b;
	dint ans = -1;
	for (dint l = 0; l < p; l += k) {
		if (pp.find(bmulak) != pp.end()) {
			ans = l + pp[bmulak];
			break;
		}
		bmulak = modMul(bmulak, akinv);
	}
	cout << ans << endl;
}

