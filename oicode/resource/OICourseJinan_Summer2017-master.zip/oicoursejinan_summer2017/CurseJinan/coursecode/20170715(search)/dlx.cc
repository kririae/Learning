int l[maxn], r[maxn], u[maxn], d[maxn], tn, ren[maxn], cai[maxn];

void shanchu(int x) {
	for (int p = r[x]; p != x; p = r[p]) {
		for (int q = u[p]; q != p; q = u[q]) {
			for (int s = r[q]; s != q; s = r[s]) {
				if (d[s] != s) {
					d[u[s]] = d[s];
					u[d[s]] = u[s];
				}
			}
		}
	}
}

void huifu(int x) {
	for (int p = l[x]; p != x; p = l[p]) {
		for (int q = d[p]; q != p; q = d[q]) {
			for (int s = l[q]; s != q; s = l[s]) {
				u[d[s]] = d[u[s]] = s;
			}
		}
	}
}

void DFS(int shengcai, int baolederen) {
	if (shengcai == 0) {
		answer = max(answer, baolederen);
		return;
	}
	for (int p = d[1]; p != 1; p = d[p]) {
		u[d[p]] = d[p];
		d[u[p]] = u[p];
		shanchu(p);
		DFS(shengcai - totcai[p], baolederen + 1);
		huifu(p);
		d[u[p]] = u[d[p]] = p;
	}
}

int main() {
	memset(cai, 0, sizeof(cai));
	scanf("%d%d", &n, &m);
	ren[0] = tn = 1;
	l[1] = r[1] = 1;
	d[1] = u[1] = 1;
	for (int i = 1; i <= n; ++ i) {
		ren[i] = ++ tn;
		l[tn] = r[tn] = tn;
		u[tn] = ren[i - 1];
		d[ren[i - 1]] = tn;
		d[tn] = 1;
		u[1] = tn;
		int caii, lastcai = tn;
		scanf("%d", totcai + tn);
		for (int j = 0; j < totcai[tn]; ++ j) {
			scanf("%d", &caii);
			++ tn;
			r[lastcai] = tn;
			l[tn] = lastcai;
			r[tn] = ren[i];
			l[ren[i]] = tn;
			lastcai = tn;
			if (!cai[caii]) {
				cai[caii] = u[tn] = d[tn] = tn;
			} else {
				u[tn] = cai[caii];
				d[tn] = d[cai[caii]];
				u[d[tn]] = tn;
				d[u[tn]] = tn;
				cai[caii] = tn;
			}
		}
	}
}
