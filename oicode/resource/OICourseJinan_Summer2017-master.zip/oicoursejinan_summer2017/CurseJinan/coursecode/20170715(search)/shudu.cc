int a[81], hang[9], lie[9], ge[3][3];

void DFS(int pos) {
	if (pos == 81) {
		puts("Zhao dao le!!! : ");
		return;
	}
	if (a[pos]) {
		DFS(pos + 1);
	} else {
		int x(pos / 9), y(pos % 9);
		int gx(x / 3), gy(y / 3);
		for (int i = 1; i < 10; ++ i) {
			if ((hang[x] & (1 << i)) == 0 && (lie[y] & (1 << i)) == 0 && (ge[gx][gy] & (1 << i))) {
				hang[x] |= 1 << i;
				lie[y] |= 1 << i;
				ge[gx][gy] |= 1 << i;
				DFS(pos + 1);
				hang[x] &= ~(1 << i);
				lie[y] &= ~(1 << i);
				ge[gx][gy] &= ~(1 << i);
			}
		}
	}
}
