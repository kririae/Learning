int n, a[maxn][maxn], deg[maxn], dego[maxn];

inline int cmpDeg(const int& a, const int& b) {
	return deg[a] > deg[b];
}

int kexuan[maxn][maxn], cntkx[maxn];

void DFS(int p) {
	if (p > answer) {
		answer = p;
	} else if (p + cntkx[p] <= answer) {
		return;
	}
	for (int i = 1; i <= cntkx[p]; ++ i) {
		cntkx[p + 1] = 0;
		for (int j = 1; j <= cntkx[p]; ++ j) {
			if (a[kexuan[p][i]][kexuan[p][j]]) {
				kexuan[p + 1][++ cntkx[p + 1]] = kexuan[p][j];
			}
		}
		DFS(p + 1);
	}
}

int main() {
	// shu ru ...;
	sort(dego, dego + n, cmpDeg);
	for (int i = 1; i <= n; ++ i) {
		cntkx[1] = 0;
		for (int j = i + 1; j <= n; ++ j) {
			if (a[i][j]) {
				kexuan[1][++ cntkx[1]] = j;
			}
		}
		DFS(1);
	}
}

