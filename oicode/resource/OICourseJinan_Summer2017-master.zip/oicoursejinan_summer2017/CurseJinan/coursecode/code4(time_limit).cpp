#include<ctime>
int t;
void dfs() {
	if (clock()-t>=900) {
		printf("Da an\n");
		exit(0);
	}
}
int main() {
	t=clock();
}
