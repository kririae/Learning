int to[maxm], wei[maxm], next[maxm], total;
bool vis[maxn];
int head[maxn];

void addEdge(int u, int v, int w) {
	/* ��һ����u��v��ȨֵΪw�ĵ���� */
	++ total;
	to[total] = v;
	wei[total] = w;
	next[total] = head[u];
	head[u] = total;
}

void DFS(int u) {
	vis[u] = true;
	for (int e = head[u]; e; e = next[e]) {
		if (!vis[to[e]]) {
			DFS(to[e]);
		}
	}
}

int main() {
	cin >> n >> m;
	memset(head, 0, sizeof(head));
	for (int i = 0; i < m; ++ i) {
		int a, u, v, w;
		cin >> a >> u >> v >> w;
		if (a == 1) {
			addEdge(u, v, w);
			addEdge(v, u, w);
		} else {
			addEdge(u, v, w);
		}
	}
	memset(vis, 0, sizeof(vis));
	DFS(1);

