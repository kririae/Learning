int to[maxm], wei[maxm], next[maxm], total;
int head[maxn];

void addEdge(int u, int v, int w) {
	/* ��һ����u��v��ȨֵΪw�ĵ���� */
	++ total;
	to[total] = v;
	wei[total] = w;
	next[total] = head[u];
	head[u] = total;
}

void BellmanFord(int u0) {
	memset(dis, 0x3f, sizeof(dis));
	dis[u0] = 0;
	for (int ti = 0; ti < n; ++ ti) {
		for (int u = 1; u <= n; ++ u) {
			for (int e = head[u]; e; e = next[e]) {
				dis[to[e]] = min(dis[to[e]], dis[u] + wei[e]);
			}
		}
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < m; ++ i) {
		int a, u, v, w;
		cin >> a >> u >> v >> w;
		if (a == 1) {
			addEdge(u, v, w);
			addEdge(v, u, w);
		} else {
			addEdge(u, v, w);
		}
	}
}
