int to[maxm], wei[maxm], next[maxm], total;
int head[maxn], dis[maxn], zhidaole[maxn];

inline int cmpVertex(int u, int v) {
	return dis[u] > dis[v];
}

void addEdge(int u, int v, int w) {
	/* ��һ����u��v��ȨֵΪw�ĵ���� */
	++ total;
	to[total] = v;
	wei[total] = w;
	next[total] = head[u];
	head[u] = total;
}

void dijkstra(int u0) {
	static int heap[maxn];
	int totheap = 1;
	memset(dis, 0x3f, sizeof(dis));
	memset(zhidaole, 0, sizeof(zhidaole));
	dis[u0] = 0;
	heap[0] = u0;
	while (totheap) {
		int u = heap[0];
		pop_heap(heap, heap + (totheap --), cmpVertex);
		if (zhidaole[u]) {
			continue;
		}
		zhidaole[u] = true;
		for (int e = head[u]; e; e = next[e]) {
			if (!zhidaole[to[e]] && dis[to[e]] > dis[u] + wei[e]) {
				dis[to[e]] = dis[u] + wei[e];
				heap[totheap ++] = u;
				push_heap(heap, heap + totheap, cmpVertex);
			}
		}
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < m; ++ i) {
		int a, u, v, w;
		cin >> a >> u >> v >> w;
		if (a == 1) {
			addEdge(u, v, w);
			addEdge(v, u, w);
		} else {
			addEdge(u, v, w);
		}
	}
}
