struct Edge {
	int u, v, w;
};

int r[maxn];

int getRoot(int x) { // ���ҵĸ���˭
	int p = x, q;
	while (p != r[p]) {
		p = r[p];
	}
	while (p != x) {
		q = r[x];
		r[x] = p;
		x = q;
	}
	return p;
}

bool sameSet(int x, int y) { // �ж��������ǲ���ͬһ�����ϵ�
	return getRoot(x) == getRoot(y);
}

void joinSets(int x, int y) { // �ϲ�������
	x = getRoot(x), y = getRoot(y);
	r[y] = x;
}

void init() { // ��ʼ��
	for (int i = 1; i <= n; ++ i) {
		r[i] = i;
	}
}

inline bool cmpEdge(const Edge& a, const Edge& b) {
	return a.w < b.w;
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < m; ++ i) {
		cin >> e[i].u >> e[i].v >> e[i].w;
	}
	sort(e, e + m, cmpEdge);
	init();
	int totLength = 0;
	for (int i = 0; i < m; ++ i) {
		if (!sameSet(e[i].u, e[i].v)) {
			totLength += e[i].w;
			joinSets(e[i].u, e[i].v);
		}
	}
}
