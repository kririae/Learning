int to[maxm], wei[maxm], next[maxm], total;
int head[maxn];

void addEdge(int u, int v, int w) {
	/* ��һ����u��v��ȨֵΪw�ĵ���� */
	++ total;
	to[total] = v;
	wei[total] = w;
	next[total] = head[u];
	head[u] = total;
}

void SPFA(int u0) {
	int que[maxn], qhead = 0, qtail = 1, inq[maxn];
	memset(dis, 0x3f, sizeof(dis));
	dis[que[0] = u0] = 0; 
	while (qhead != qtail) {
		int u = que[qhead ++];
		inq[u] = false;
		if (qhead == maxn) {
			qhead = 0;
		}
		for (int e = head[u]; e; e = next[e]) {
			if (dis[u] + wei[e] < dis[to[e]]) {
				dis[to[e]] = dis[u] + wei[e];
				if (!inq[to[e]]) {
					inq[to[e]] = true;
					que[qtail ++] = to[e];
					if (qtail == maxn) {
						qtail = 0;
					}
				}
			}
		}
	}
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < m; ++ i) {
		int a, u, v, w;
		cin >> a >> u >> v >> w;
		if (a == 1) {
			addEdge(u, v, w);
			addEdge(v, u, w);
		} else {
			addEdge(u, v, w);
		}
	}
}
