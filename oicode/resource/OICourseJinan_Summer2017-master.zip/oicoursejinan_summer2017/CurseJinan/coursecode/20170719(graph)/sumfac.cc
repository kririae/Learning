int calc(int n) {
	// O(n) de zuo fa
	int ans = 0;
	for (int i = 1; i <= n; ++ i) {
		ans = (ans + n / i * i)% mod;
	}
	return ans;
}

int calc2(int n) {
	// O(sqrt(n)) de zuo fa
	int ans = 0;
	for (int i = 1, j; i <= n; i = j + 1) {
		j = n / (n / i);
		ans = (ans + n / i * dengchashulieqiuhe(i, j))% mod;
	}
	return ans;

