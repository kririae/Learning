struct Edge {
	int from, to, wei;
};

inline bool cmpEdge(const Edge& a, const Edge& b) {
	return a.from < b.from;
}

Edge edges[maxm];
int startPos[maxn];

int main() {
	cin >> n >> m;
	for (int i = 0; i < n; ++ i) {
		cin >> edges[i].from >> edges[i].to >> edges[i].wei;
	}
	std::sort(edges, edges + m, cmpEdge);
	for (int u = 1, e = 0; u <= n; ++ u) {
		startPos[u] = e;
		while (e < m && edges[e].from == u) ++ e;
	}
	startPos[n + 1] = m;
}
