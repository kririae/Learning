struct Edge {
	int from, to, wei;
};

inline bool cmpEdge(const Edge& a, const Edge& b) {
	return a.from < b.from;
}

Edge edges[maxm];
int startPos[maxn], dis[maxn], degreeLeft[maxn];

void topoSort() {
	int que[maxn], qhead = 0, qtail = 0;
	for (int i = 1; i <= n; ++ i) {
		if (degreeLeft[i] == 0) {
			que[qtail ++] = i;
		}
	}
	while (qhead < qtail) {
		int u = que[qhead ++];
		for (int e = startPos[u]; e < startPos[u + 1]; ++ e) {
			-- degreeLeft[to[e]];
			if (degreeLeft[to[e]] == 0) {
				que[qtail ++] = edges[e].to;
			}
		}
	}
}

void DFS(int u) {
	for (int e = startPos[u]; e < startPos[u + 1]; ++ e) {
		-- degreeLeft[edges[e].to];
		if (degreeLeft[edges[e].to] == 0) {
			DFS(edges[e].to);
		}
	}
}

int main() {
	cin >> n >> m;
	memset(degreeLeft, 0, sizeof(degreeLeft));
	for (int i = 0; i < m; ++ i) {
		cin >> edges[i].from >> edges[i].to >> edges[i].wei;
		++ degreeLeft[edges[i].to];
	}
	std::sort(edges, edges + m, cmpEdge);
	for (int u = 1, e = 0; u <= n; ++ u) {
		startPos[u] = e;
		while (e < m && edges[e].from == u) ++ e;
	}
	startPos[n + 1] = m;
	for (int i= 1; i <= n; ++ i) {
		if (!vis[i]) {
			BFS(i);
		}
	}
}
