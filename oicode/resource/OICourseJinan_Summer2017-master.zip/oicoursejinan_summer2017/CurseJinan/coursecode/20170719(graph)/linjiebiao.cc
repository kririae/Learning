int to[maxm], wei[maxm], next[maxm], total;
int head[maxn];

void addEdge(int u, int v, int w) {
	/* ��һ����u��v��ȨֵΪw�ĵ���� */
	++ total;
	to[total] = v;
	wei[total] = w;
	next[total] = head[u];
	head[u] = total;
}

int main() {
	cin >> n >> m;
	for (int i = 0; i < m; ++ i) {
		int a, u, v, w;
		cin >> a >> u >> v >> w;
		if (a == 1) {
			addEdge(u, v, w);
			addEdge(v, u, w);
		} else {
			addEdge(u, v, w);
		}
	}
}
