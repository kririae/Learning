#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 105;
const int M = 61;
const int S = 1 << 17;

int n, a[N], b[N];
int p[N], fg[N];

int g[M];
int f[N][S], opt[N][S];

int absp(int x)
{
	return x > 0 ? x : -x;
}

int main()
{
	freopen("T35.in", "r", stdin);

	cin >> n;
	for(int i = 1; i <= n; ++ i) cin >> a[i];

	for(int i = 2; i < M; ++ i)
	{
		if(!fg[i]) p[++p[0]] = i;
		for(int j = 1; j <= p[0] && i * p[j] < M; ++ j)
			fg[i * p[j]] = 1;
	}

	for(int i = 1; i < M; ++ i)
	{
		g[i] = 0;
		for(int j = 1; j <= p[0]; ++ j)
			if(i % p[j] == 0) g[i] |= 1 << (j-1);
	}

	int ns = 1 << p[0];

	for(int i = 1; i <= n + 1; ++ i)
		for(int j = 0; j < ns; ++ j) f[i][j] = S;

	f[1][0] = 0;

	for(int i = 1; i <= n; ++ i)
		for(int j = 0; j < ns; ++ j) if(f[i][j] < S)
			for(int k = 1; k < M; ++ k)
				if((g[k] & j) == 0)
				{
					int t = f[i][j] + absp(k - a[i]);
					if(t < f[i+1][g[k] | j])
						f[i+1][g[k] | j] = t,
						opt[i+1][g[k] | j] = k;
				}

	int ansp = S;
	int ansm = 0;

	for(int j = 0;  j < ns; ++ j)
		if(f[n+1][j] < ansp) ansp = f[n+1][j], ansm = j;

	for(int i = n+1; i > 1; -- i)
	{
		b[i-1] = opt[i][ansm];
		ansm ^= g[b[i-1]];
	}

	for(int i = 1; i <= n; ++ i) cout << b[i] << " ";
	cout << endl;

	return 0;
}
