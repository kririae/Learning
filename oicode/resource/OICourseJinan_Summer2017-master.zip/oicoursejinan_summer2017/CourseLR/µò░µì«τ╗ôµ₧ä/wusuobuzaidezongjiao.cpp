#include <iostream>
#define maxn 10003
using namespace std;
int fa[maxn];
int find(int x)
{
    return x==father[x]?x:father[x]=find(father[x]);
}
void hebin(int x,int y)
{
    int X=find(x);
    int Y=find(y);
    if(X==Y)    return;
    else
    {
        father[x]=father[y];
    }
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;++i)
        fa[i]=i;
    for(int i=1;i<=m;++i)
    {
        int p,q,r;
        cin>>p>>q>>r;
        if(p==1)    hebin(q,r);
        if(p==2)
        {
            int X=find(q);
            int Y=find(r);
            if(X==Y)    cout<<"Y";
            else        cout<<"N";
        }
    }
}
