//树状数组模板
//解释：http://blog.csdn.net/int64ago/article/details/7429868
/*c[x]=a[x-lowbit[x]+1]+......+a[x]
其中lowbit[x]=x&-x，求出二进制下
从右往左第一个1开始的一串数字
*/
void add(int x,int y)	//添加a[x]并修改前缀和
{
	for(;x<=n;x+=x&-x)
		c[x]+=y;
}
//ask(r)-ask(l-1)表示[l,r]前缀和
int ask(int x) //询问前x个数的和
{
	int y=0;
	for(;x;x-=x&-x)
		y+=c[x];
	return y;
}