//�ҷ��� ջʵ��
for(int i=1;i<=n;++i)
{
    for(;a[i]>a[stack[top]&&top;--top);
    c[i]=i-stack[top]-1;
    ans+=c[i];
    stack[++top]=i;
}
