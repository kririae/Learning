//trie树/单词查找树
/*
根节点不包含字符，除根节点每一个节点都只包含一个字符
路径上的字符连接起来是节点对应字符串
互异性
 */
#include <bits/c++.h>
using namespace std;
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%s",s[i]+1);
		m=strlrn(s[i]+1);
		for(int j=1,cur=root;j<=m;++j)
		{
			if(son[cur][s[i][j]-'a'])		//节点已经新建
				cur=son[cur][s[i][j]-'a'];
			else
				cur=son[cur][s[i][j]-'a']=++cnt;
			tot[cur]++;						
		}
	}
}