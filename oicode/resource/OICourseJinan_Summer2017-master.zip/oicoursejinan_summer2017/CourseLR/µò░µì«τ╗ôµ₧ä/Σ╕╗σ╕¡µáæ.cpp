/*
主席树(函数式线段树/可持久化线段树)
每次操作只修改logn个节点
由于线段树下标，用ls[]rs[]记录前一时刻的左儿子右儿子
 */
void add(int l,int r,int x,int y,int &cur,int cur1)
{
	cur=++cnt;
	sum[cur]=sum[cur1]+y;
	ls[cur]=ls[cur1];
	rs[cur]=rs[cur1];
	if(l==r)
		return;
	int mid=r+l>>1;
	if(x<=mid)
		add(l,mid,x,y,ls[cur],ls[cur1]);//引用传递修改
	else
		add(mid+1,r,x,y,rs[cur],rs[cur1]);

}
//区间第k大
int ask(int l,int r,int k,int cur,int cur1)//cur新节点，cur1旧节点
{
	if(l==r)
		return 1;
	int mid=l+r>>1;
	if(sum[ls[cur]]-sum[ls[cur1]]>=k)
		return ask(l,mid,k,ls[cur],ls[cur1]);
	else
		return ask(mid+1,r,k,k-sum[ls[cur]]+sum[ls[cur1]],rs[cur],rs[cur1]);

}
int main()
{
	for(int i=1;i<=n;++i)
	{
		scanf("%d%d",&x,&y);
		add(1,n,x,y,root[i],root[i-1]);
	}
	ask(1,n,k,root[r],root[l-1]);
}
