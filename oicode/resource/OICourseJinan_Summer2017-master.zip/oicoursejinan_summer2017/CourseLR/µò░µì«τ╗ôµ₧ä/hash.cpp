//hash
/*
字符串hash
大质数取模结果，一般需要两个
如 ABCDE->12345 %P
也可以用unsigned_int自然溢出，但可能出问题
超大数hash
 */
 //01串翻转(即0->1,1->0)
 //线段树维护01串记录hash值
 /*
 1 1 1 1 1 1 1 1 1
-1 0 1 1 0 1 0 1 0
=0 1 0 0 1 0 1 0 1*/
#include<bits/stdc++.h>
using namespace std;
bitset<30000>,b[30000],f[30000];
int main(){
	scanf("%d",&n);
	for(i=0;i<n;i++)scanf("%d",&x),a[i]=x;//读入
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		scanf("%d",&L[i]);
		for(j=0;j<L[i];j++)scanf("%d",&x),b[i][j]=x;
	}
	scanf("%d",&m);
	f[0][0]=1;
	for(i=1;i<n;i++)
		f[i]=f[i-1],f[i][i]=1;
	while(m--){
		scanf("%d%d%d",&s,&l,&r);
		if(s==1){
			a^=f[r-1];
			if(l-1)a^=f[l-2];
		}else
		{
			scanf("%d",&p);
			c=a;
			if(l-1)c>>=l-2;
			c&=f[L[i]-1];
			if((c^b[p]).count())puts("NO");
			else puts("YES");
		}
	}
}