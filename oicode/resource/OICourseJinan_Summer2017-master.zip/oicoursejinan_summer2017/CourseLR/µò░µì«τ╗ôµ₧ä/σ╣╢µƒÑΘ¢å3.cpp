//P2170 ѡѧ��
X=find(x);
Y=find(y);
dad[X]=Y;
size[Y]+=size[X];

for(int i=0;i<=n;++i)
{
    f=f|f<<a[i];            //fΪbitset
    /*�ȼۣ�
    for(int j=m;j>=a[i];--j)
        if(f[j-a[i]])
            f[j]=1;
    */
    }
