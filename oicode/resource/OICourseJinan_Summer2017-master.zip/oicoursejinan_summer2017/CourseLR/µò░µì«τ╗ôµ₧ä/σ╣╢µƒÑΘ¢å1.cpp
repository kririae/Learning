//模板
int find(int x)
{
    return dad[x]==x?x:dad[x]=find(dad[x]); //°´ÖÈºÏ²¢
}
dad[find(x)]=find(y);
void move()
{
    X=find(x);
    Y=find(y);
    if(deep[x]>deep[y])
        swap(s,y);
    dad[x]=y;
    deep[y]=max(deep[y],deep[x]+1);
}
