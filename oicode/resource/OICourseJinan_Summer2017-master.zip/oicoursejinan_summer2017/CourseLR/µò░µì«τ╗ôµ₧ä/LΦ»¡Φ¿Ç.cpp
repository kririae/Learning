/*首先建trie树
DP:
f[0]=1;
f[i][j]=f[dad[i]][j-1];
*/
*#include <bits/c++.h>
using namespace std;
int main()
{
	scanf("%d",&n);
	root=1;
	for(int i=1;i<=n;++i)
	{
		scanf("%s",s+1);
		m=strlrn(s+1);
		for(int j=1,cur=root;j<=m;++j)
		{
			if(son[cur][s[j]-'a'])		//节点已经新建
				cur=son[cur][s[j]-'a'];
			else
				cur=son[cur][s[j]-'a']=++cnt;
			tot[cur]=1;						
		}
	}
	gets(s+1);
	n=strlen(s+1);
	f[0]=1;
	for(int i=0;i<n;++i)
	{
		if(f[i])
		{
			for(int j=i+1,cur=root;j<=n&&cur;++j)
			{
				if(tot[cur])	//结尾
					f[j]=1;
				cur=son[cur][s[j]-'a'];
			}
			ans=max(ans,i);
		}
	}
	
}