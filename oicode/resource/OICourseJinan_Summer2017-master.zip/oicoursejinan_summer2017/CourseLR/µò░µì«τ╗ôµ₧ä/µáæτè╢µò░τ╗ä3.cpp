//野鸡题
/*可以差分数组，差分表示每一项减前一项
例如1 3 2 4 5，差分为1 2 -1 2 1
修改区间时，原数组每项都要变化
但差分数组只在l处权值x,在r+1处权值-x
在上例中，[3,4]+2，原数组变为1 5 4 6 5
但差分数组变为1 4 -1 2 3
*/
void add(int x,int y)	//添加a[x]并修改前缀和
{
	for(;x<=n;x+=x&-x)
		c[x]+=y;
}
//ask(r)-ask(l-1)表示[l,r]前缀和
int ask(int x) //询问前x个数的和
{
	int y=0;
	for(;x;x-=x&-x)
		y+=c[x];
	return y;
}
while(q--)
{
	int t,l,r,x;
	scanf("d%",&t);
	if(t==1)
	{
		scanf("d%d%d%",&l,&r,&x);
		add(l,x);
		add(r+1,-x);	//[l,r]增加x权值
	}
	else
		scanf("d",&x),ask(x);//查询x权值

}

/*用两个树状数组实现,例：
如1 2 3 4 5//下标
  0 0 0 0 0//初值
改0 3 3 3 0//改后
  0 3 6 9 9//前缀和
第一个树状数组 -3 0 0 12 0
前缀和：-3 -3 -3 9 9
我们发现此时只有[l-1][r-1]是错误的，其余前缀和不变
第二个用来修正，而其前缀和与原前缀和差为3 6 9，成等差数列
故开另一个树状数组 3 0 0 -3 0
前缀和 3 3 3 0 0 
前缀和每一项乘以下标 3 6 9 0 0
加上上一个树状数组的前缀和 0 3 6 9 9
(上例中l=2,x=3)
实现：*/
void add1(int x,int y)	//添加a[x]并修改前缀和
{
	for(;x<=n;x+=x&-x)
		c[x]+=y;
}
void add2(int x,int y)	//添加a[x]并修改前缀和
{
	for(;x<=n;x+=x&-x)
		d[x]+=y;
}
int ask1(int x) //询问前x个数的和
{
	int y=0;
	for(;x;x-=x&-x)
		y+=c[x];
	return y;
}
int ask2(int x) //询问前x个数的和
{
	int y=0;
	for(;x;x-=x&-x)
		y+=d[x];
	return y;
}
add1(l-1,-x*(l-1));
add1(r,x*r);
add2(l-1,x);
add2(r,-x);
ask1(r)+ask2(r)*r-(ask1(l-1)+ask2(l-1)*(l-1))