//P1552 伪代码
void dfs(int x)
{
    sum[x]=v[x];    //子树中权值和
    root[x]=x;      //初始化x个只有一个节点的树，表示子树左偏树的根
    num[x]=1;       //子树左偏树元素个数
    foreach(i=x的儿子)
    {
        dfs(i);     //访问
        root[x]=merge(root[i],root[x]);//合并子树
        sum[x]+=sum[i]; //对子树的sumnum进行合并
        num[x]+=num[i];
    }
    for(;sum[x]>m;)//处理当前节点，删除根节点
    {
        sum[x]-=v[root[x]];//把最大的删掉
        root[x]=merge(ls[root[x]],rs[root[x]]);
        num[x]--;//可并堆元素数量减少1
    }
    ans=max(ans,num[x]*L[x]);//寻找最大

}
