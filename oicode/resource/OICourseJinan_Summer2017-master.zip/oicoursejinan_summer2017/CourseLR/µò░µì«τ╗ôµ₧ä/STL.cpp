//STL
//pair
#include <bits/stdc++.h>
using namespace std;
pair<int,int>a[100003];
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("d%d%",a[i].first,a[i].second);
	//或：makepair(x,y);
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i)
		scanf("d% d%\n",a[i].first,a[i].second);

}
//priotity_queue,默认大根堆
#include <queue>
using namespace std;
priotity_queue<pair <int,vector> > qp;//加好空格，可能当成>>
priotity_queue<int> q;
priotity_queue<int,vector<int>,greater<int> >q;
//当然加的时候取负数可以当做小根堆使用
int main()
{
	q.push(3);
	q.push(5);
	cout<<q.top();
} 
//map,没有上界有顺序
#include <map>
using namespace std;
map<int,int> mp;
map<double,int>mmp;
map<pair<int,int>,int>mmmp;
map<string,int>ksdg;
map<long long,int> mapu;
int main()
{
	mp[123331223]=456676;
	mmp[3465.675]=23423;
	mmmp[make_pair(34,34)]=2342;
	ksdg["sfsd"]=124234;//重要作用：hash，但较慢
}
//n个球,每个球有一个权值,10^18,排序/
for(int i=1;i<=n;++i)
	scanf("lld%",&x),mapu[x]++;
for(int i=1;i<=m;++i)
	scanf("lld%",&x),printf("%d\n",mapu[x]);

//set，内部为平衡树，是有序的
#include <map>
using namespace std;
set<int> st;
int main()
{
	st.insert(5);st.insert(3);st.insert(10);
	printf("d%\n",*st.lower_bound(7));
	set<int>::iterator it;
	for(it=st.begin();it!=st.end();++it)//迭代器
		cout<<*it;
	cout<<*(--st.end());//最大数
	st.erase(5);
	st.erase(it);
}
multiset<int> sst;//可重复，但删会全删
multiset<int>::iterator iit;
sst.erase(sst.find(5));//find返回迭代器
sst.erase(*sst.find(5));//只删除一个
//bitset
bitset<2000>Bit;
int main()
{
	Bit[123]=1;
	Bit>>=100;
	printf("d%\n",(int)Bit[23]);//output:1
	Bit<<=100;
	printf("d%\n",(int)Bit[223]);//output:1
	printf("%d\n",Bit.count());
	Bit=~Bit;//等价于Bit=flip(Bit);
}