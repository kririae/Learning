//对拍
//熟练后20分钟 
//makedate.cpp
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>
using namespace std;
int main(){
	freopen("a.in","w",stdout);
	srand((unsigned)time(NULL));
	int n=rand()%1000+1;
	cout<<n<<endl;
	for(int i=1;i<=n;++i)
		cout<<rand()<<" ";
	//随机一颗树
	for(int i=2;i<=n;++i)
		cout<<rand()%(i-1)+1<<" "<<i<<endl;
	//随机一颗长毛的链 1->n/2
	for(int i=2;i<=n/2;++i)
		cout<<i-1<<"　"<<i<<endl;
	for(int i=n/2+1;i<=n;++i)
		cout<<rand()%(i-1)+1<<" "<<i<<endl;
	//生成一个图
	map<long long,int>mp;
	for(int i=1;i<=200000;++i)
	{
		A=rand()%n+1;B=rand()%n+1;
		while(A==B||mp[1ll*A*100005+B])
			A=rand()%n+1,B=rand()%n+1;
		mp[1ll*A*100005+B]=1;
		cout<<A<<" "<<B<<ensl;
		 
	}
	return 0;
	//连通图：随机树再随机边 
} 



//a.bat
/*
先写一个暴力，再写一个奇怪的程序 
:loop
	makedate.exe
	bubblesort.exe
	quicksort.exe
	fc bubblesort,out quicksort.out
	if %errorlevel%==0 goto loop
pause

