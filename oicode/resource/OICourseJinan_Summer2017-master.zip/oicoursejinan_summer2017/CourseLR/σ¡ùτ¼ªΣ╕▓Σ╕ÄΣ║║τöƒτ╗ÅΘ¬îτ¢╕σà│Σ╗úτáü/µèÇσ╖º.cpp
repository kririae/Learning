//数据范围预判 
/*N=100w  O（N） 
n=10W  O(nlgn)  O(nlg2n)
n=30W  O(nlgn)
n=5W  nsqrt(n)
n=5000  n^2
n=300  n^3
n=1000  n^2lgn
n=100  n^4
n=40   2^(n/2)*n
n=35   2^(n/2)*n*lg
n=20   2^n*n
n=10   n!

n=1000 m=100   m^2n
n=1000 m=1000  nm

n=100W p=50    O(np)*/ 
//比赛经验
//平时多打比赛
//文件名 内存 100->0
/*
128Mb 128*1024*1024/4 int
				   /8 long long
				   /2 short
				   /2 bool / char
*/ 
//抄代码不copy代码 
//试一下大数据/刁钻数据
//树立自信 	  
//洛谷 tyvj			    
