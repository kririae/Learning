#include <iostream>
#include <set>
using namespace std;
set<string> st;
int main(){
	st.insert("ab");
	st.insert("abc");
	st.insert("ac");
	set<string>::iterator it;
	for(it=st.begin();it!=st.end();++it)
		cout<<*it<<" ";
}
