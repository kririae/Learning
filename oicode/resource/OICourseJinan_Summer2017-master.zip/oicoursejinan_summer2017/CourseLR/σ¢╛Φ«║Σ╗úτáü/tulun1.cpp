/*图的存储
 * 邻接矩阵存储法（内存开销大）
 * 邻接链表存储法
 * point起始，next下一个，to值，cc计数器
 * 如图“邻接链表”中
 * point  下标 1 2 3 4
 *        值   0 0 0 0
 * 加入2-4时,cc=1
 * to     下标 1      point  下标  2    next 下标 1
 *        值   4             值    1         值  0
 * 加入2-3时,cc=2
 *  to     下标 1      point  下标  2    next 下标 1
 *        值   4             值    3         值  1
 * */
 const int N=1005;
 const int M=10050;
 int point[N],to[M],nect[M],cc;

 void addEdge(int x,int y)
 {
     ++cc;
     to[cc]=y;
     nect[cc]=point[x];
     point[x]=cc;
 }
 void find(int x)//输出x能到的所有点
 {
     int now=point[x];
     while(now)
     {
         printf("%d\n",to[now]);
         now=next[now];
     }
 }

 int main()
 {

 }
