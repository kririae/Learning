#include <bits/stdc++.h>
using namespace std;
int a[]
int work(int x,int y)
{
    if(x==y)    return 0;
    if(((x&1)&&(!(y&1)))||((!(x&1))&&(y&1)))
        return 1;
    int ans=1;
    for(;!((x&1)&&(!(y&1)))||((!(x&1))&&(y&1));x>>=1,y>>=1)
        ans<<=1;
    return ans; 
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;++i)
        cin>>a[i];
    long long ans;
    for(int i=0;i<n;++i)
        for(int j=i;j<n;++j)
            ans+=work(i+1,j+1);
    cout<<ans;

}