#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int i=1;
    cin>>i;
    cout<<i;
    priority_queue<pair<int,int>> a;
}