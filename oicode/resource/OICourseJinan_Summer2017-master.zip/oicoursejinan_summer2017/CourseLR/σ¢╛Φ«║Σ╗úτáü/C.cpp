#include <bits/stdc++.h>
using namespace std;
int l,r,ans,p,count;
bool put[100005];
void work(int x,int y)
{
    put[x]=1;
    if(x>r)
        return;
    work(x,y+1);
    work(x*y,y);
}
int main()
{
    cin>>l>>r>>p;
    work(0,1);
    for(int i=l;i<=r;++i)
        if(put[i])
            ++count;
    cout<<count<<endl;
}
