#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace std;

int n;

inline void work() {	
	printf("%d\n", n);
	for (int i = 1; i <= n; i++) printf("%d ", rand() % 1000 + 1);
}

int main() {
	n = 10;
	freopen("prime0.in", "w", stdout); work();
	n = 10;
	freopen("prime1.in", "w", stdout); work();
	n = 10;
	freopen("prime2.in", "w", stdout); work();
	n = 10;
	freopen("prime3.in", "w", stdout); work();
	n = 10;
	freopen("prime4.in", "w", stdout); work();
	n = 10;
	freopen("prime5.in", "w", stdout); work();
	n = 1000;
	freopen("prime6.in", "w", stdout); work();
	n = 1000;
	freopen("prime7.in", "w", stdout); work();
	n = 1000;
	freopen("prime8.in", "w", stdout); work();
	n = 1000;
	freopen("prime9.in", "w", stdout); work();
	n = 1000;
	freopen("prime10.in", "w", stdout); work();
	n = 1000;
	freopen("prime11.in", "w", stdout); work();
	n = 1000;
	freopen("prime12.in", "w", stdout); work();
	n = 1000;
	freopen("prime13.in", "w", stdout); work();
	n = 1000;
	freopen("prime14.in", "w", stdout); work();
	n = 1000;
	freopen("prime15.in", "w", stdout); work();
	n = 1000;
	freopen("prime16.in", "w", stdout); work();
	n = 1000;
	freopen("prime17.in", "w", stdout); work();
	n = 1000;
	freopen("prime18.in", "w", stdout); work();
	n = 1000;
	freopen("prime19.in", "w", stdout); work();
} 
